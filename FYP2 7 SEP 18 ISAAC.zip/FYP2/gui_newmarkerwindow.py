# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'newmarkerwindow.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_activeMarkersWindow(object):
    def setupUi(self, activeMarkersWindow):
        activeMarkersWindow.setObjectName("activeMarkersWindow")
        activeMarkersWindow.resize(176, 123)
        self.verticalLayout = QtWidgets.QVBoxLayout(activeMarkersWindow)
        self.verticalLayout.setObjectName("verticalLayout")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label = QtWidgets.QLabel(activeMarkersWindow)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.verticalLayout_2.addWidget(self.label)
        self.buttonMkrSel = QtWidgets.QPushButton(activeMarkersWindow)
        self.buttonMkrSel.setObjectName("buttonMkrSel")
        self.verticalLayout_2.addWidget(self.buttonMkrSel)
        self.verticalLayout.addLayout(self.verticalLayout_2)
        self.buttonBox = QtWidgets.QDialogButtonBox(activeMarkersWindow)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(activeMarkersWindow)
        self.buttonBox.accepted.connect(activeMarkersWindow.accept)
        self.buttonBox.rejected.connect(activeMarkersWindow.reject)
        QtCore.QMetaObject.connectSlotsByName(activeMarkersWindow)

    def retranslateUi(self, activeMarkersWindow):
        _translate = QtCore.QCoreApplication.translate
        activeMarkersWindow.setWindowTitle(_translate("activeMarkersWindow", "Markers"))
        self.label.setText(_translate("activeMarkersWindow", "TextLabel"))
        self.buttonMkrSel.setText(_translate("activeMarkersWindow", "PushButton"))

