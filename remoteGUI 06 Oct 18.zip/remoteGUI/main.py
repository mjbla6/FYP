# Remote Interface FYP 2018
# Mitch Blair & Isaac Naylor
#
# Last edit: 05/10/18

# GUI TESTING
# TURN THE THREAD ON AND OFF WITH THE REPEAT SWEEP BUTTON

from PyQt5 import QtCore, QtGui, QtWidgets
import sys
import pyqtgraph as pg
import numpy as np

from gui_mainwindow import Ui_MainWindow
from gui_instrumentselect import Ui_instrumentSelect
from gui_inputdialog import Ui_inputDialog
from gui_hp8157a import Ui_HP8157A
from gui_agilent86142b import Ui_Agilent86142B
from gui_amplitudesetupwindow import Ui_amplitudeSetupWindow
from gui_wavelengthsetupwindow import Ui_wavelengthSetupWindow
from gui_activemarkerswindow import Ui_activeMarkersWindow
from gui_markersetupwindow import Ui_markerSetupWindow
from gui_advancedlinemarkerwindow import Ui_advancedLineMarkerWindow
from gui_systemwindow import Ui_systemWindow
from gui_newmarkerwindow import Ui_newMarkerWindow 

global number
number = 0

class InstrumentSelect(QtWidgets.QDialog, Ui_instrumentSelect):
    def __init__(self, parent=None):
        super(InstrumentSelect, self).__init__(parent)
        self.setupUi(self)
        self.listWidget.addItem("Agilent 86142B")
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def onAccept(self):
        self.selection = self.listWidget.currentItem().text()
        return self.selection

    def onReject(self):
        self.selection = ""
        return self.selection


# Class for threadding
class Threading(QtCore.QThread):
    sig = QtCore.pyqtSignal(int)
    def __init__(self, parent=None):
        super(Threading, self).__init__(parent)

    def __del__(self):
        self.wait()

    def run(self):
        for i in range(0,100):
            global number
            number = number + 1
            print(number)
            self.sig.emit(number)
            self.sleep(2)

# Agilent 86142B instrument
class Agilent86142B(QtWidgets.QWidget, Ui_Agilent86142B):
    def __init__(self, parent=None):
        super(Agilent86142B, self).__init__(parent)
        self.setupUi(self)

        # Setup graph variables
        global y
        y = np.array([2,4,6,8,10,12,14,16,18,20])
        global y2
        y2 = np.array([0,1,2,4,12,14,16,17,14,22])
        global x
        x = np.array([1,2,3,4,5,6,7,8,9,10])

        # Setup graph
        #self.plot = pg.GraphicsWindow()
        #self.p1 = self.plot.addPlot()
        self.p1 = pg.PlotWidget()
        self.p1.addLegend()
        self.p1.showGrid(x=True, y=True)
        self.p1.setLabel('left', 'Amplitude', units='dBm')
        self.p1.setLabel('bottom', 'Wavelength', units='nm')
        c1 = self.p1.plot(x, y, pen='y', name='plot 1')
        c2 = self.p1.plot(x, y2, pen='r', name='plot 2')
        self.p1.plotItem.legend.removeItem('plot 1')
        self.p1.plotItem.legend.removeItem('plot 2')
        #self.p1.removeItem(c1)
        #self.graphLayout.addWidget(self.plot)
        self.graphLayout.addWidget(self.p1)

        # Setup mouse events on graph
        mypen = pg.mkPen('y', width=1)
        self.curve = self.p1.plot(x=[], y=[], pen=mypen)
        self.curve.scene().sigMouseMoved.connect(self.onMouseMoved)
        self.p1.scene().sigMouseClicked.connect(self.onMouseClicked)

        # Top menu buttons clicked
        self.buttonWavelength.clicked.connect(self.wavelengthMenu)
        self.buttonAmplitude.clicked.connect(self.amplitudeMenu)
        self.buttonMarkers.clicked.connect(self.markersMenu)
        self.buttonTraces.clicked.connect(self.tracesMenu)
        self.buttonBW.clicked.connect(self.bwMenu)
        self.buttonSystem.clicked.connect(self.systemMenu)

    # Threading returns here to add the dot on plot
    def addPlot(self, item):
        c3 = self.p1.plot([item], [item], pen='g', symbol='d')

    def onMouseMoved(self, point):
        global p
        p = self.p1.plotItem.vb.mapSceneToView(point)
        #self.statusBar().showMessage("{}-{}".format(p.x(), p.y()))
    
    def onMouseClicked(self, event):
        buttons = event.button()
        if buttons == 1:
            widget = NewMarkerWindow()
            widget.exec_()
            if widget.selection != 0:
                print("{}-{}".format(p.x(), p.y()))
                self.px = p.x()
                self.py = p.y()
                global x
                global y
                global y2
                self.checkx = x-self.px
                self.checkx = abs(self.checkx)
                self.xi = np.argmin(self.checkx)
                self.px = x[self.xi]
                self.py = y2[self.xi]
                print("{}-{}".format(self.px, self.py))
                self.dot = self.p1.plot([self.px], [self.py], symbol='o')
                #self.dot = self.p1.plot([p.x()], [p.y()], symbol='o')
                self.p1.plotItem.legend.addItem(self.dot, '%s' %widget.marker)

    # Function to clear sub-menu ready to add next menu
    def clearLayout(self, layout):
        if layout != None:
            while layout.count():
                child = layout.takeAt(0)
                if child.widget() is not None:
                    child.widget().deleteLater()
                elif child.layout() is not None:
                    clearLayout(child.layout())

    # Wavelength sub-menu
    def wavelengthMenu(self):
        self.clearLayout(self.subButtonLayout)  

        self.buttonCenterWL = QtWidgets.QPushButton("Center WL", self)
        self.subButtonLayout.addWidget(self.buttonCenterWL)
        self.buttonSpan = QtWidgets.QPushButton("Span", self)
        self.subButtonLayout.addWidget(self.buttonSpan)
        self.buttonStartWL = QtWidgets.QPushButton("Start WL", self)
        self.subButtonLayout.addWidget(self.buttonStartWL)
        self.buttonStopWL = QtWidgets.QPushButton("Stop WL", self)
        self.subButtonLayout.addWidget(self.buttonStopWL)
        self.buttonPeakToCenter = QtWidgets.QPushButton("Peak To Center", self)
        self.subButtonLayout.addWidget(self.buttonPeakToCenter)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonWavelengthSetup = QtWidgets.QPushButton("Wavelength Setup", self)
        self.subButtonLayout.addWidget(self.buttonWavelengthSetup)

        self.buttonCenterWL.clicked.connect(self.centerWL)
        self.buttonSpan.clicked.connect(self.span)
        self.buttonStartWL.clicked.connect(self.startWL)
        self.buttonStopWL.clicked.connect(self.stopWL)
        self.buttonWavelengthSetup.clicked.connect(self.wavelengthSetupWindow)

    def centerWL(self):
        widget = InputDialog("Center WL", "nm")
        widget.exec_()

    def span(self):
        widget = InputDialog("Span", "nm")
        widget.exec_()

    def startWL(self):
        widget = InputDialog("Start WL", "nm")
        widget.exec_()

    def stopWL(self):
        widget = InputDialog("Stop WL", "nm")
        widget.exec_()

    def wavelengthSetupWindow(self):
        widget = WavelengthSetup()
        widget.exec_()

    # Amplitude sub-menu
    def amplitudeMenu(self):
        self.clearLayout(self.subButtonLayout)  

        self.buttonRefLvl = QtWidgets.QPushButton("Reference Level", self)
        self.subButtonLayout.addWidget(self.buttonRefLvl)
        self.buttonScaleDiv = QtWidgets.QPushButton("Scale/Div", self)
        self.subButtonLayout.addWidget(self.buttonScaleDiv)
        self.buttonDispMode = QtWidgets.QPushButton("Display Mode [Log]", self)
        self.buttonDispMode.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonDispMode)
        self.buttonSensitivity = QtWidgets.QPushButton("Sensitivity [Auto]", self)
        self.buttonSensitivity.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonSensitivity)
        self.buttonPeakToRefLvl = QtWidgets.QPushButton("Peak To Ref Level", self)
        self.subButtonLayout.addWidget(self.buttonPeakToRefLvl)
        self.buttonTraceInteg = QtWidgets.QPushButton("Trace Integ [Off]", self)
        self.buttonTraceInteg.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonTraceInteg)
        self.buttonAmplitudeSetup = QtWidgets.QPushButton("Amplitude Setup", self)
        self.subButtonLayout.addWidget(self.buttonAmplitudeSetup)

        self.buttonRefLvl.clicked.connect(self.refLVL)
        self.buttonScaleDiv.clicked.connect(self.scaleDiv)
        self.buttonDispMode.clicked.connect(self.dispMode)
        self.buttonSensitivity.clicked.connect(self.sensitivity)
        self.buttonPeakToRefLvl.clicked.connect(self.peakToRefLvl)
        self.buttonTraceInteg.clicked.connect(self.traceInteg)
        self.buttonAmplitudeSetup.clicked.connect(self.amplitudeSetupWindow)

    def refLVL(self):
        widget = InputDialog("Reference Level", "dBm")
        widget.exec_()

    def scaleDiv(self):
        widget = InputDialog("Scale/Div", "dB")
        widget.exec_()

    def dispMode(self):
        if self.buttonDispMode.isChecked():
            self.buttonDispMode.setText("Display Mode [Lin]")
        else:
            self.buttonDispMode.setText("Display Mode [Log]")

    def sensitivity(self):
        if self.buttonSensitivity.isChecked():
            self.buttonSensitivity.setText("Sensitivity [Man]")
        else:
            self.buttonSensitivity.setText("Sensitivity [Auto]")

    def peakToRefLvl(self):
        widget = InputDialog("Peak to Reference Level", "dBm")
        widget.exec_()

    def traceInteg(self):
        if self.buttonTraceInteg.isChecked():
            self.buttonTraceInteg.setText("Trace Integ [On]")
        else:
            self.buttonTraceInteg.setText("Trace Integ [Off]")

    def amplitudeSetupWindow(self):
        widget = AmplitudeSetup()
        widget.exec_()


    # Markers sub-menu
    def markersMenu(self):
        self.clearLayout(self.subButtonLayout)  

        self.buttonActMrks = QtWidgets.QPushButton("Active Markers", self)
        self.subButtonLayout.addWidget(self.buttonActMrks)
        self.buttonActTrce = QtWidgets.QPushButton("Trace A", self)
        self.subButtonLayout.addWidget(self.buttonActTrce)
        self.menuActTrce = QtWidgets.QMenu()
        self.menuActTrce.addAction("Trace A", self.ActTrceAction1)
        self.menuActTrce.addAction("Trace B", self.ActTrceAction2)
        self.menuActTrce.addAction("Trace C", self.ActTrceAction3)
        self.menuActTrce.addAction("Trace D", self.ActTrceAction4)
        self.menuActTrce.addAction("Trace E", self.ActTrceAction5)
        self.menuActTrce.addAction("Trace F", self.ActTrceAction6)
        self.buttonActTrce.setMenu(self.menuActTrce)
        self.buttonPeakSrch = QtWidgets.QPushButton("Peak Search", self)
        self.subButtonLayout.addWidget(self.buttonPeakSrch)
        self.buttonMkrToCen = QtWidgets.QPushButton("Marker to Center", self)
        self.subButtonLayout.addWidget(self.buttonMkrToCen)
        self.buttonMkrToRefLvl = QtWidgets.QPushButton("Marker To Ref Level", self)
        self.subButtonLayout.addWidget(self.buttonMkrToRefLvl)
        self.buttonMkrSetup = QtWidgets.QPushButton("Marker Setup", self)
        self.subButtonLayout.addWidget(self.buttonMkrSetup)
        self.menuMkrSetup = QtWidgets.QMenu()
        self.menuMkrSetup.addAction("Mkr 1", self.MkrSetupAction1)
        self.menuMkrSetup.addAction("Mkr 2", self.MkrSetupAction2)
        self.menuMkrSetup.addAction("Mkr 3", self.MkrSetupAction3)
        self.menuMkrSetup.addAction("Mkr 4", self.MkrSetupAction4)
        self.buttonMkrSetup.setMenu(self.menuMkrSetup)
        self.buttonMoreMkrFunc = QtWidgets.QPushButton("More Marker Functons", self)
        self.subButtonLayout.addWidget(self.buttonMoreMkrFunc)

        self.buttonActMrks.clicked.connect(self.actMrks)
        self.buttonPeakSrch.clicked.connect(self.peakSrch)
        self.buttonMkrToCen.clicked.connect(self.mrkToCen)
        self.buttonMkrToRefLvl.clicked.connect(self.mkrToRefLvl)
        self.buttonMoreMkrFunc.clicked.connect(self.moreMkrFunc)

    def actMrks(self):
        widget = ActiveMarkersWindow("Active Markers")
        widget.exec_()

    def ActTrceAction1(self):
        self.buttonActTrce.setText("Trace A")

    def ActTrceAction2(self):
        self.buttonActTrce.setText("Trace B")

    def ActTrceAction3(self):
        self.buttonActTrce.setText("Trace C")

    def ActTrceAction4(self):
        self.buttonActTrce.setText("Trace D")

    def ActTrceAction5(self):
        self.buttonActTrce.setText("Trace E")

    def ActTrceAction6(self):
        self.buttonActTrce.setText("Trace F")

    def peakSrch(self):
        widget = InputDialog("Peak Search", "nm")
        widget.exec_()

    def mrkToCen(self):
        widget = InputDialog("Marker To Center", "nm")
        widget.exec_()

    def mkrToRefLvl(self):
        widget = InputDialog("Marker To Ref Lvl", "dBm")
        widget.exec_()

    def MkrSetupAction1(self):
        widget = MarkerSetup("1")
        widget.exec_()

    def MkrSetupAction2(self):
        widget = MarkerSetup("2")
        widget.exec_()

    def MkrSetupAction3(self):
        widget = MarkerSetup("3")
        widget.exec_()

    def MkrSetupAction4(self):
        widget = MarkerSetup("4")
        widget.exec_()

    def moreMkrFunc(self):
        self.clearLayout(self.subButtonLayout)  

        self.buttonMkrSrchMenu = QtWidgets.QPushButton("Marker Search Menu", self)
        self.subButtonLayout.addWidget(self.buttonMkrSrchMenu)
        self.buttonMkrBW = QtWidgets.QPushButton("Marker Bandwidth", self)
        self.subButtonLayout.addWidget(self.buttonMkrBW)
        self.buttonNoiseMkr = QtWidgets.QPushButton("Noise Marker [Off]", self)
        self.buttonNoiseMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonNoiseMkr)
        self.buttonDeltaMkr = QtWidgets.QPushButton("Delta Marker [Off]", self)
        self.buttonDeltaMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonDeltaMkr)
        self.buttonOSNRMkr = QtWidgets.QPushButton("OSNR Marker [Off]", self)
        self.buttonOSNRMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonOSNRMkr)
        self.buttonLineMkrMenu = QtWidgets.QPushButton("Line Marker Menu", self)
        self.subButtonLayout.addWidget(self.buttonLineMkrMenu)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonMkrSrchMenu.clicked.connect(self.mkrSrchMenu)
        self.buttonNoiseMkr.clicked.connect(self.noiseMkr)
        self.buttonDeltaMkr.clicked.connect(self.deltaMkr)
        self.buttonOSNRMkr.clicked.connect(self.OSNRMkr)
        self.buttonLineMkrMenu.clicked.connect(self.lineMkrMenu)
        self.buttonPrevMenu.clicked.connect(self.markersMenu)

    def mkrSrchMenu(self):
        self.clearLayout(self.subButtonLayout)  

        self.buttonSrchMode = QtWidgets.QPushButton("Search Mode [Peak]", self)
        self.buttonSrchMode.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonSrchMode)
        self.buttonPeakSrch = QtWidgets.QPushButton("Peak Search", self)
        self.subButtonLayout.addWidget(self.buttonPeakSrch)
        self.buttonNextPeakDown = QtWidgets.QPushButton("Next Peak Down", self)
        self.subButtonLayout.addWidget(self.buttonNextPeakDown)
        self.buttonNextPeakLeft = QtWidgets.QPushButton("Next Peak Left", self)
        self.subButtonLayout.addWidget(self.buttonNextPeakLeft)
        self.buttonNextPeakRight = QtWidgets.QPushButton("Next Peak Right", self)
        self.subButtonLayout.addWidget(self.buttonNextPeakRight)
        self.buttonActMrks = QtWidgets.QPushButton("Active Markers", self)
        self.subButtonLayout.addWidget(self.buttonActMrks)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonSrchMode.clicked.connect(self.srchMode)
        self.buttonPeakSrch.clicked.connect(self.peakSrch)
        self.buttonActMrks.clicked.connect(self.actMrks)
        self.buttonPrevMenu.clicked.connect(self.moreMkrFunc)

    def srchMode(self):
        if self.buttonSrchMode.isChecked():
            self.buttonSrchMode.setText("Search Mode [Pit]")
        else:
            self.buttonSrchMode.setText("Search Mode [Peak]")

    def noiseMkr(self):
        if self.buttonNoiseMkr.isChecked():
            self.buttonNoiseMkr.setText("Noise Marker [On]")
        else:
            self.buttonNoiseMkr.setText("Noise Marker [Off]")
        
    def deltaMkr(self):
        if self.buttonDeltaMkr.isChecked():
            self.buttonDeltaMkr.setText("Delta Marker [On]")
        else:
            self.buttonDeltaMkr.setText("Delta Marker [Off]")

    def OSNRMkr(self):
        if self.buttonOSNRMkr.isChecked():
            self.buttonOSNRMkr.setText("OSNR Marker [On]")
        else:
            self.buttonOSNRMkr.setText("OSNR Marker [Off]")

    def lineMkrMenu(self):
        self.clearLayout(self.subButtonLayout)

        self.buttonWLLineMkr1 = QtWidgets.QPushButton("Wavelength Line Mkr 1", self)
        self.subButtonLayout.addWidget(self.buttonWLLineMkr1)
        self.buttonWLLineMkr2 = QtWidgets.QPushButton("Wavelength Line Mkr 2", self)
        self.subButtonLayout.addWidget(self.buttonWLLineMkr2)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonLineMkrsOff = QtWidgets.QPushButton("Line Markers Off", self)
        self.subButtonLayout.addWidget(self.buttonLineMkrsOff)
        self.buttonAdvLineMkrFunc = QtWidgets.QPushButton("Advanved Line Marker Functions", self)
        self.subButtonLayout.addWidget(self.buttonAdvLineMkrFunc)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonAdvLineMkrFunc.clicked.connect(self.advLineMkrFunc)
        self.buttonPrevMenu.clicked.connect(self.moreMkrFunc)

    def advLineMkrFunc(self):
        widget = AdvancedLineMarkerWindow()
        widget.exec_()


    # Trace sub-menu
    def tracesMenu(self):
        self.clearLayout(self.subButtonLayout)  

        self.buttonActTrce = QtWidgets.QPushButton("Trace A", self)
        self.subButtonLayout.addWidget(self.buttonActTrce)
        self.menuActTrce = QtWidgets.QMenu()
        self.menuActTrce.addAction("Trace A", self.ActTrceAction1)
        self.menuActTrce.addAction("Trace B", self.ActTrceAction2)
        self.menuActTrce.addAction("Trace C", self.ActTrceAction3)
        self.menuActTrce.addAction("Trace D", self.ActTrceAction4)
        self.menuActTrce.addAction("Trace E", self.ActTrceAction5)
        self.menuActTrce.addAction("Trace F", self.ActTrceAction6)
        self.buttonActTrce.setMenu(self.menuActTrce)
        self.buttonUpdtTrce = QtWidgets.QPushButton("Update Trace [Off]", self)
        self.buttonUpdtTrce.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonUpdtTrce)
        self.buttonViewTrce = QtWidgets.QPushButton("View Trace [Off]", self)
        self.buttonViewTrce.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonViewTrce)
        self.buttonHoldTrce = QtWidgets.QPushButton("Hold Trace [None]", self)
        self.menuHoldTrce = QtWidgets.QMenu()
        self.menuHoldTrce.addAction("None", self.HoldTrceAction1)
        self.menuHoldTrce.addAction("Min", self.HoldTrceAction2)
        self.menuHoldTrce.addAction("Max", self.HoldTrceAction3)
        self.buttonHoldTrce.setMenu(self.menuHoldTrce)
        self.subButtonLayout.addWidget(self.buttonHoldTrce)
        self.buttonTrceMath = QtWidgets.QPushButton("Trace Math", self)
        self.subButtonLayout.addWidget(self.buttonTrceMath)
        self.buttonAveraging = QtWidgets.QPushButton("Averaging [Off]", self)
        self.buttonAveraging.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonAveraging)
        self.buttonTrceSetup = QtWidgets.QPushButton("Trace Setup", self)
        self.subButtonLayout.addWidget(self.buttonTrceSetup)

        self.buttonUpdtTrce.clicked.connect(self.updtTrce)
        self.buttonViewTrce.clicked.connect(self.viewTrce)
        self.buttonTrceMath.clicked.connect(self.trceMath)
        self.buttonAveraging.clicked.connect(self.averaging)
        self.buttonTrceSetup.clicked.connect(self.trceSetup)

    def HoldTrceAction1(self):
        self.buttonHoldTrce.setText("Hold Trace [None]")

    def HoldTrceAction2(self):
        self.buttonHoldTrce.setText("Hold Trace [Min]")

    def HoldTrceAction3(self):
        self.buttonHoldTrce.setText("Hold Trace [Max]")

    def updtTrce(self):
        if self.buttonUpdtTrce.isChecked():
            self.buttonUpdtTrce.setText("Update Trace [On]")
        else:
            self.buttonUpdtTrce.setText("Update Trace [Off]")

    def viewTrce(self):
        if self.buttonViewTrce.isChecked():
            self.buttonViewTrce.setText("View Trace [On]")
        else:
            self.buttonViewTrce.setText("View Trace [Off]")

    def trceMath(self):
        self.clearLayout(self.subButtonLayout)

        self.buttonDefMathTrcC = QtWidgets.QPushButton("Default Math Trace C", self)
        self.menuTrcMathC = QtWidgets.QMenu()
        self.menuTrcMathC.addAction("Log: C = A-B", self.TrcMathCAction1)
        self.menuTrcMathC.addAction("Log: C = A+B", self.TrcMathCAction2)
        self.menuTrcMathC.addAction("Lin: C = A-B", self.TrcMathCAction3)
        self.menuTrcMathC.addAction("Lin: C = A+B", self.TrcMathCAction4)
        self.menuTrcMathC.addAction("Trace C Math Off", self.TrcMathCAction5)
        self.buttonDefMathTrcC.setMenu(self.menuTrcMathC)
        self.subButtonLayout.addWidget(self.buttonDefMathTrcC)
        self.buttonDefMathTrcF = QtWidgets.QPushButton("Default Math Trace F", self)
        self.menuTrcMathF = QtWidgets.QMenu()
        self.menuTrcMathF.addAction("Log: F = C-D", self.TrcMathFAction1)
        self.menuTrcMathF.addAction("Trace F Math Off", self.TrcMathFAction2)
        self.buttonDefMathTrcF.setMenu(self.menuTrcMathF)
        self.subButtonLayout.addWidget(self.buttonDefMathTrcF)
        self.buttonExchMenu = QtWidgets.QPushButton("Exchange Menu", self)
        self.menuExchange = QtWidgets.QMenu()
        self.menuExchange.addAction("A Exchange B", self.ExchangeAction1)
        self.menuExchange.addAction("B Exchange C", self.ExchangeAction2)
        self.menuExchange.addAction("C Exchange A", self.ExchangeAction3)
        self.menuExchange.addAction("D Exchange A", self.ExchangeAction4)
        self.menuExchange.addAction("E Exchange A", self.ExchangeAction5)
        self.menuExchange.addAction("F Exchange A", self.ExchangeAction6)
        self.buttonExchMenu.setMenu(self.menuExchange)
        self.subButtonLayout.addWidget(self.buttonExchMenu)
        self.buttonTrceOffset = QtWidgets.QPushButton("Trace Offset", self)
        self.subButtonLayout.addWidget(self.buttonTrceOffset)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonAllMathOff = QtWidgets.QPushButton("All Math Off", self)
        self.subButtonLayout.addWidget(self.buttonAllMathOff)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonPrevMenu.clicked.connect(self.tracesMenu)

    def TrcMathCAction1(self):
        return

    def TrcMathCAction2(self):
        return

    def TrcMathCAction3(self):
        return

    def TrcMathCAction4(self):
        return

    def TrcMathCAction5(self):
        return

    def TrcMathFAction1(self):
        return

    def TrcMathFAction2(self):
        return

    def ExchangeAction1(self):
        return

    def ExchangeAction2(self):
        return

    def ExchangeAction3(self):
        return

    def ExchangeAction4(self):
        return

    def ExchangeAction5(self):
        return

    def ExchangeAction6(self):
        return

    def averaging(self):
        if self.buttonAveraging.isChecked():
            self.buttonAveraging.setText("Averaging [On]")
        else:
            self.buttonAveraging.setText("Averaging [Off]")

    def trceSetup(self):
        widget = InputDialog("Trace Setup", "Sweep Points")
        widget.exec_()


    # Bandwidth/Sweep sub-menu
    def bwMenu(self):
        self.clearLayout(self.subButtonLayout)  

        self.buttonResBW = QtWidgets.QPushButton("Res BW [Auto]", self)
        self.menuResBw = QtWidgets.QMenu()
        self.menuResBw.addAction("Auto", self.ResBWAction1)
        self.menuResBw.addAction("Manual", self.ResBWAction2)
        self.buttonResBW.setMenu(self.menuResBw)
        self.subButtonLayout.addWidget(self.buttonResBW)
        self.buttonVidBW = QtWidgets.QPushButton("Video BW [Auto]", self)
        self.menuVidBW = QtWidgets.QMenu()
        self.menuVidBW.addAction("Auto", self.VidBWAction1)
        self.menuVidBW.addAction("Manual", self.VidBWAction2)
        self.buttonVidBW.setMenu(self.menuVidBW)
        self.subButtonLayout.addWidget(self.buttonVidBW)
        self.buttonSweepTime = QtWidgets.QPushButton("Sweep Time [Auto]", self)
        self.menuSweepTime = QtWidgets.QMenu()
        self.menuSweepTime.addAction("Auto", self.SweepTimeAction1)
        self.menuSweepTime.addAction("Manual", self.SweepTimeAction2)
        self.buttonSweepTime.setMenu(self.menuSweepTime)
        self.subButtonLayout.addWidget(self.buttonSweepTime)
        self.buttonRptSweep = QtWidgets.QPushButton("Repeat Sweep [Off]", self)
        self.buttonRptSweep.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonRptSweep)
        self.buttonSnglSweep = QtWidgets.QPushButton("Single Sweep", self)
        self.subButtonLayout.addWidget(self.buttonSnglSweep)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonMoreBWFunc = QtWidgets.QPushButton("More BW/Sweep Functions", self)
        self.subButtonLayout.addWidget(self.buttonMoreBWFunc)

        self.buttonRptSweep.clicked.connect(self.rptSweep)
        self.buttonMoreBWFunc.clicked.connect(self.moreBWFunc)

    def ResBWAction1(self):
        self.buttonResBW.setText("Res BW [Auto]")

    def ResBWAction2(self):
        widget = InputDialog("Res BW", "nm")
        widget.exec_()
        if widget.userInput != 0:
            self.buttonResBW.setText("Res BW [Man]")

    def VidBWAction1(self):
        self.buttonVidBW.setText("Video BW [Auto]")

    def VidBWAction2(self):
        widget = InputDialog("Video BW", "Hz")
        widget.exec_()
        if widget.userInput != 0:
            self.buttonVidBW.setText("Video BW [Man]")

    def SweepTimeAction1(self):
        self.buttonSweepTime.setText("Sweep Time [Auto]")

    def SweepTimeAction2(self):
        widget = InputDialog("Sweep Time", "s")
        widget.exec_()
        if widget.userInput != 0:
            self.buttonSweepTime.setText("Sweep Time [Man]")

    def rptSweep(self):
        if self.buttonRptSweep.isChecked():
            self.buttonRptSweep.setText("Repeat Sweep [On]")
            self.get_thread = Threading()
            self.get_thread.sig.connect(self.addPlot)
            self.get_thread.start()
            print("Thread On")
        else:
            self.buttonRptSweep.setText("Repeat Sweep [Off]")
            self.get_thread.terminate()
            print("Thread Off")

    def moreBWFunc(self):
        self.clearLayout(self.subButtonLayout)  

        self.buttonTrigMode = QtWidgets.QPushButton("Trigger Mode [Internal]", self)
        self.menuTrigMode = QtWidgets.QMenu()
        self.menuTrigMode.addAction("Internal", self.TrigModeAction1)
        self.menuTrigMode.addAction("Gated", self.TrigModeAction2)
        self.menuTrigMode.addAction("External", self.TrigModeAction3)
        self.menuTrigMode.addAction("ADC+", self.TrigModeAction4)
        self.menuTrigMode.addAction("ADC-", self.TrigModeAction5)
        self.buttonTrigMode.setMenu(self.menuTrigMode)
        self.subButtonLayout.addWidget(self.buttonTrigMode)
        self.buttonTrigDelay = QtWidgets.QPushButton("Trigger Delay", self)
        self.subButtonLayout.addWidget(self.buttonTrigDelay)
        self.buttonADCTrigSync = QtWidgets.QPushButton("ADC Trig Sync [Low]", self)
        self.menuADCTrig = QtWidgets.QMenu()
        self.menuADCTrig.addAction("Low", self.ADCTrigAction1)
        self.menuADCTrig.addAction("High", self.ADCTrigAction2)
        self.menuADCTrig.addAction("Pulse", self.ADCTrigAction3)
        self.buttonADCTrigSync.setMenu(self.menuADCTrig)
        self.subButtonLayout.addWidget(self.buttonADCTrigSync)
        self.buttonADCSyncOut = QtWidgets.QPushButton("ADC Sync Out [Off]", self)
        self.buttonADCSyncOut.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonADCSyncOut)
        self.buttonADCSyncOutDuty = QtWidgets.QPushButton("ADC Sync Out Duty Cycle", self)
        self.subButtonLayout.addWidget(self.buttonADCSyncOutDuty)
        self.buttonADCSyncOutPulse = QtWidgets.QPushButton("ADC Sync Out Pulse Width", self)
        self.subButtonLayout.addWidget(self.buttonADCSyncOutPulse)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonTrigDelay.clicked.connect(self.trigDelay)
        self.buttonADCSyncOut.clicked.connect(self.ADCSyncOut)
        self.buttonADCSyncOutDuty.clicked.connect(self.ADCSyncOutDuty)
        self.buttonADCSyncOutPulse.clicked.connect(self.ADCSyncOutPulse)
        self.buttonPrevMenu.clicked.connect(self.bwMenu)

    def TrigModeAction1(self):
        self.buttonTrigMode.setText("Trigger Mode [Internal]")

    def TrigModeAction2(self):
        self.buttonTrigMode.setText("Trigger Mode [Gated]")

    def TrigModeAction3(self):
        self.buttonTrigMode.setText("Trigger Mode [External]")

    def TrigModeAction4(self):
        self.buttonTrigMode.setText("Trigger Mode [ADC+]")

    def TrigModeAction5(self):
        self.buttonTrigMode.setText("Trigger Mode [ADC-]")

    def trigDelay(self):
        widget = InputDialog("Trigger Delay", "us")
        widget.exec_()

    def ADCTrigAction1(self):
        self.buttonADCTrigSync.setText("ADC Trig Sync [Low]")

    def ADCTrigAction2(self):
        self.buttonADCTrigSync.setText("ADC Trig Sync [High]")

    def ADCTrigAction3(self):
        self.buttonADCTrigSync.setText("ADC Trig Sync [Pulse]")

    def ADCSyncOut(self):
        if self.buttonADCSyncOut.isChecked():
            self.buttonADCSyncOut.setText("ADC Sync Out [On]")
        else:
            self.buttonADCSyncOut.setText("ADC Sync Out [Off]")

    def ADCSyncOutDuty(self):
        widget = InputDialog("ADC Sync Out Duty Cycle", "us")
        widget.exec_()

    def ADCSyncOutPulse(self):
        widget = InputDialog("ADC Sync Out Pulse Width", "us")
        widget.exec_()


    # System sub-meuu
    def systemMenu(self):
        widget = SystemWindow()
        widget.exec_()


class InputDialog(QtWidgets.QDialog, Ui_inputDialog):
    def __init__(self, title, unit, parent=None):
        super(InputDialog, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle(title)
        self.label.setText(unit)
        validator = QtGui.QDoubleValidator()
        self.lineEdit.setValidator(validator)
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def onAccept(self):
        self.userInput = self.lineEdit.text()
        return self.userInput 

    def onReject(self):
        self.userInput = 0
        return self.userInput


class ActiveMarkersWindow(QtWidgets.QDialog, Ui_activeMarkersWindow):
    def __init__(self, title, parent=None):
        super(ActiveMarkersWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle(title)

        self.buttonAllOff.clicked.connect(self.allMkrsOff)

    def allMkrsOff(self):
        self.checkMkr1.setChecked(False)
        self.checkMkr2.setChecked(False)
        self.checkMkr3.setChecked(False)
        self.checkMkr4.setChecked(False)


class AmplitudeSetup(QtWidgets.QDialog, Ui_amplitudeSetupWindow):
    def __init__(self, parent=None):
        super(AmplitudeSetup, self).__init__(parent)
        self.setupUi(self)

        self.buttonAmpUnits.setText("Auto")
        self.menuAmpUnits = QtWidgets.QMenu()
        self.menuAmpUnits.addAction("Auto", self.AmpUnitsAction1)
        self.menuAmpUnits.addAction("W", self.AmpUnitsAction2)
        self.buttonAmpUnits.setMenu(self.menuAmpUnits)
        self.buttonAutoRang.setText("On")
        self.menuAutoRang = QtWidgets.QMenu()
        self.menuAutoRang.addAction("On", self.AutoRangAction1)
        self.menuAutoRang.addAction("Off", self.AutoRangAction2)
        self.buttonAutoRang.setMenu(self.menuAutoRang)
        self.buttonAutoZero.setText("On")
        self.menuAutoZero = QtWidgets.QMenu()
        self.menuAutoZero.addAction("On", self.AutoZeroAction1)
        self.menuAutoZero.addAction("Off", self.AutoZeroAction2)
        self.buttonAutoZero.setMenu(self.menuAutoZero)
        self.buttonAutoChop.setText("On")
        self.menuAutoChop = QtWidgets.QMenu()
        self.menuAutoChop.addAction("On", self.AutoChopAction1)
        self.menuAutoChop.addAction("Off", self.AutoChopAction2)
        self.buttonAutoChop.setMenu(self.menuAutoChop)
        self.buttonAmpCorr.setText("1")
        self.menuAmpCorr = QtWidgets.QMenu()
        self.menuAmpCorr.addAction("1", self.AmpCorrAction1)
        self.menuAmpCorr.addAction("2", self.AmpCorrAction2)
        self.menuAmpCorr.addAction("3", self.AmpCorrAction3)
        self.menuAmpCorr.addAction("4", self.AmpCorrAction4)
        self.buttonAmpCorr.setMenu(self.menuAmpCorr)
        self.buttonAmpCorrMode.setText("On")
        self.menuAmpCorrMode = QtWidgets.QMenu()
        self.menuAmpCorrMode.addAction("On", self.AmpCorrModeAction1)
        self.menuAmpCorrMode.addAction("Off", self.AmpCorrModeAction2)
        self.buttonAmpCorrMode.setMenu(self.menuAmpCorrMode)

    def AmpUnitsAction1(self):
        self.buttonAmpUnits.setText("Auto")

    def AmpUnitsAction2(self):
        self.buttonAmpUnits.setText("W")

    def AutoRangAction1(self):
        self.buttonAutoRang.setText("On")

    def AutoRangAction2(self):
        self.buttonAutoRang.setText("Off")

    def AutoZeroAction1(self):
        self.buttonAutoZero.setText("On")

    def AutoZeroAction2(self):
        self.buttonAutoZero.setText("Off")

    def AutoChopAction1(self):
        self.buttonAutoChop.setText("On")

    def AutoChopAction2(self):
        self.buttonAutoChop.setText("Off")

    def AmpCorrAction1(self):
        self.buttonAmpCorr.setText("1")

    def AmpCorrAction2(self):
        self.buttonAmpCorr.setText("2")

    def AmpCorrAction3(self):
        self.buttonAmpCorr.setText("3")

    def AmpCorrAction4(self):
        self.buttonAmpCorr.setText("4")

    def AmpCorrModeAction1(self):
        self.buttonAmpCorrMode.setText("On")

    def AmpCorrModeAction2(self):
        self.buttonAmpCorrMode.setText("Off")


class WavelengthSetup(QtWidgets.QDialog, Ui_wavelengthSetupWindow):
    def __init__(self, parent=None):
        super(WavelengthSetup, self).__init__(parent)
        self.setupUi(self)

        self.buttonWLUnits.setText("nm")
        self.menuWLUnits = QtWidgets.QMenu()
        self.menuWLUnits.addAction("nm", self.WLUnitsAction1)
        self.menuWLUnits.addAction("um", self.WLUnitsAction2)
        self.menuWLUnits.addAction("Ang", self.WLUnitsAction3)
        self.buttonWLUnits.setMenu(self.menuWLUnits)
        self.buttonWLRef.setText("Air")
        self.menuWLRef = QtWidgets.QMenu()
        self.menuWLRef.addAction("Air", self.WLRefAction1)
        self.menuWLRef.addAction("Vacuum", self.WLRefAction2)
        self.buttonWLRef.setMenu(self.menuWLRef)

    def WLUnitsAction1(self):
        self.buttonWLUnits.setText("nm")

    def WLUnitsAction2(self):
        self.buttonWLUnits.setText("um")

    def WLUnitsAction3(self):
        self.buttonWLUnits.setText("Ang")

    def WLRefAction1(self):
        self.buttonWLRef.setText("Air")

    def WLRefAction2(self):
        self.buttonWLRef.setText("Vacuum")

class MarkerSetup(QtWidgets.QDialog, Ui_markerSetupWindow):
    def __init__(self, MkrNo, parent=None):
        super(MarkerSetup, self).__init__(parent)
        self.setupUi(self)

        self.buttonNormMkrUnits.setText("nm")
        self.menuNormMkrUnits = QtWidgets.QMenu()
        self.menuNormMkrUnits.addAction("nm", self.NormMkrUnitsAction1)
        self.menuNormMkrUnits.addAction("um", self.NormMkrUnitsAction2)
        self.menuNormMkrUnits.addAction("Ang", self.NormMkrUnitsAction3)
        self.menuNormMkrUnits.addAction("GHz", self.NormMkrUnitsAction4)
        self.menuNormMkrUnits.addAction("THz", self.NormMkrUnitsAction5)
        self.buttonNormMkrUnits.setMenu(self.menuNormMkrUnits)
        self.buttonBWMkrUnits.setText("nm")
        self.menuBWMkrUnits = QtWidgets.QMenu()
        self.menuBWMkrUnits.addAction("nm", self.BWMkrUnitsAction1)
        self.menuBWMkrUnits.addAction("um", self.BWMkrUnitsAction2)
        self.menuBWMkrUnits.addAction("Ang", self.BWMkrUnitsAction3)
        self.menuBWMkrUnits.addAction("GHz", self.BWMkrUnitsAction4)
        self.menuBWMkrUnits.addAction("THz", self.BWMkrUnitsAction5)
        self.buttonBWMkrUnits.setMenu(self.menuBWMkrUnits)
        self.buttonDeltaMkrUnits.setText("nm")
        self.menuDeltaMkrUnits = QtWidgets.QMenu()
        self.menuDeltaMkrUnits.addAction("nm", self.DeltaMkrUnitsAction1)
        self.menuDeltaMkrUnits.addAction("um", self.DeltaMkrUnitsAction2)
        self.menuDeltaMkrUnits.addAction("Ang", self.DeltaMkrUnitsAction3)
        self.menuDeltaMkrUnits.addAction("GHz", self.DeltaMkrUnitsAction4)
        self.menuDeltaMkrUnits.addAction("THz", self.DeltaMkrUnitsAction5)
        self.buttonDeltaMkrUnits.setMenu(self.menuDeltaMkrUnits)
        self.buttonMkrInterp.setText("On")
        self.menuMkrInterp = QtWidgets.QMenu()
        self.menuMkrInterp.addAction("On", self.MkrInterpAction1)
        self.menuMkrInterp.addAction("Off", self.MkrInterpAction2)
        self.buttonMkrInterp.setMenu(self.menuMkrInterp)
        self.buttonBWMkrInterp.setText("On")
        self.menuBWMkrInterp = QtWidgets.QMenu()
        self.menuBWMkrInterp.addAction("On", self.BWMkrInterpAction1)
        self.menuBWMkrInterp.addAction("Off", self.BWMkrInterpAction2)
        self.buttonBWMkrInterp.setMenu(self.menuBWMkrInterp)
        self.buttonUserMkrThresh.setText("On")
        self.menuUserMkrThresh = QtWidgets.QMenu()
        self.menuUserMkrThresh.addAction("On", self.UserMkrThreshAction1)
        self.menuUserMkrThresh.addAction("Off", self.UserMkrThreshAction2)
        self.buttonUserMkrThresh.setMenu(self.menuUserMkrThresh)
        self.buttonNoiseMkrBW.setText("0.1 nm")
        self.menuNoiseMkrBW = QtWidgets.QMenu()
        self.menuNoiseMkrBW.addAction("0.1 nm", self.NoiseMkrBWAction1)
        self.menuNoiseMkrBW.addAction("1.0 nm", self.NoiseMkrBWAction2)
        self.buttonNoiseMkrBW.setMenu(self.menuNoiseMkrBW)
        self.buttonOSNR.setText("PM")
        self.menuOSNR = QtWidgets.QMenu()
        self.menuOSNR.addAction("PM", self.OSNRAction1)
        self.menuOSNR.addAction("Auto", self.OSNRAction2)
        self.menuOSNR.addAction("Manual", self.OSNRAction3)
        self.buttonOSNR.setMenu(self.menuOSNR)

    def NormMkrUnitsAction1(self):
        self.buttonNormMkrUnits.setText("nm")

    def NormMkrUnitsAction2(self):
        self.buttonNormMkrUnits.setText("um")

    def NormMkrUnitsAction3(self):
        self.buttonNormMkrUnits.setText("Ang")

    def NormMkrUnitsAction4(self):
        self.buttonNormMkrUnits.setText("GHz")

    def NormMkrUnitsAction5(self):
        self.buttonNormMkrUnits.setText("THz")

    def BWMkrUnitsAction1(self):
        self.buttonBWMkrUnits.setText("nm")

    def BWMkrUnitsAction2(self):
        self.buttonBWMkrUnits.setText("um")

    def BWMkrUnitsAction3(self):
        self.buttonBWMkrUnits.setText("Ang")

    def BWMkrUnitsAction4(self):
        self.buttonBWMkrUnits.setText("GHz")

    def BWMkrUnitsAction5(self):
        self.buttonBWMkrUnits.setText("THz")

    def DeltaMkrUnitsAction1(self):
        self.buttonDeltaMkrUnits.setText("nm")

    def DeltaMkrUnitsAction2(self):
        self.buttonDeltaMkrUnits.setText("um")

    def DeltaMkrUnitsAction3(self):
        self.buttonDeltaMkrUnits.setText("Ang")

    def DeltaMkrUnitsAction4(self):
        self.buttonDeltaMkrUnits.setText("GHz")

    def DeltaMkrUnitsAction5(self):
        self.buttonDeltaMkrUnits.setText("THz")

    def MkrInterpAction1(self):
        self.buttonMkrInterp.setText("On")

    def MkrInterpAction2(self):
        self.buttonMkrInterp.setText("Off")

    def BWMkrInterpAction1(self):
        self.buttonBWMkrInterp.setText("On")

    def BWMkrInterpAction2(self):
        self.buttonBWMkrInterp.setText("Off")

    def UserMkrThreshAction1(self):
        self.buttonUserMkrThresh.setText("On")

    def UserMkrThreshAction2(self):
        self.buttonUserMkrThresh.setText("Off")

    def NoiseMkrBWAction1(self):
        self.buttonNoiseMkrBW.setText("0.1 nm")

    def NoiseMkrBWAction2(self):
        self.buttonNoiseMkrBW.setText("1.0 nm")

    def OSNRAction1(self):
        self.buttonOSNR.setText("PM")

    def OSNRAction2(self):
        self.buttonOSNR.setText("Auto")

    def OSNRAction3(self):
        self.buttonOSNR.setText("Manual")


class AdvancedLineMarkerWindow(QtWidgets.QDialog, Ui_advancedLineMarkerWindow):
    def __init__(self, parent=None):
        super(AdvancedLineMarkerWindow, self).__init__(parent)
        self.setupUi(self)

        self.buttonSweepLimit.setText("On")
        self.menuSweepLimit = QtWidgets.QMenu()
        self.menuSweepLimit.addAction("On", self.SweepLimitAction1)
        self.menuSweepLimit.addAction("Off", self.SweepLimitAction2)
        self.buttonSweepLimit.setMenu(self.menuSweepLimit)
        self.buttonSrchLimit.setText("On")
        self.menuSrchLimit = QtWidgets.QMenu()
        self.menuSrchLimit.addAction("On", self.SrchLimitAction1)
        self.menuSrchLimit.addAction("Off", self.SrchLimitAction2)
        self.buttonSrchLimit.setMenu(self.menuSrchLimit)
        self.buttonIntegLimit.setText("On")
        self.menuIntegLimit = QtWidgets.QMenu()
        self.menuIntegLimit.addAction("On", self.IntegLimitAction1)
        self.menuIntegLimit.addAction("Off", self.IntegLimitAction2)
        self.buttonIntegLimit.setMenu(self.menuIntegLimit)
        self.buttonTraceInteg.setText("On")
        self.menuTraceInteg = QtWidgets.QMenu()
        self.menuTraceInteg.addAction("On", self.TraceIntegAction1)
        self.menuTraceInteg.addAction("Off", self.TraceIntegAction2)
        self.buttonTraceInteg.setMenu(self.menuTraceInteg)

    def SweepLimitAction1(self):
        self.buttonSweepLimit.setText("On")

    def SweepLimitAction2(self):
        self.buttonSweepLimit.setText("Off")

    def SrchLimitAction1(self):
        self.buttonSrchLimit.setText("On")

    def SrchLimitAction2(self):
        self.buttonSrchLimit.setText("Off")

    def IntegLimitAction1(self):
        self.buttonIntegLimit.setText("On")

    def IntegLimitAction2(self):
        self.buttonIntegLimit.setText("Off")

    def TraceIntegAction1(self):
        self.buttonTraceInteg.setText("On")

    def TraceIntegAction2(self):
        self.buttonTraceInteg.setText("Off")


class SystemWindow(QtWidgets.QDialog, Ui_systemWindow):
    def __init__(self, parent=None):
        super(SystemWindow, self).__init__(parent)
        self.setupUi(self)
        
        self.buttonSigSource.setText("External")
        self.menuSigSource = QtWidgets.QMenu()
        self.menuSigSource.addAction("External", self.SigSourceAction1)
        self.menuSigSource.addAction("Calirator", self.SigSourceAction2)
        self.buttonSigSource.setMenu(self.menuSigSource)
        self.buttonWLRef.setText("Air")
        self.menuWLRef = QtWidgets.QMenu()
        self.menuWLRef.addAction("Air", self.WLRefAction1)
        self.menuWLRef.addAction("Vacuum", self.WLRefAction2)
        self.buttonWLRef.setMenu(self.menuWLRef)

    def SigSourceAction1(self):
        self.buttonSigSource.setText("External")

    def SigSourceAction2(self):
        self.buttonSigSource.setText("Calibrator")

    def WLRefAction1(self):
        self.buttonWLRef.setText("Air")

    def WLRefAction2(self):
        self.buttonWLRef.setText("Vacuum")

class NewMarkerWindow(QtWidgets.QDialog, Ui_newMarkerWindow):
    def __init__(self, parent=None):
        super(NewMarkerWindow, self).__init__(parent)
        self.setupUi(self)

        self.buttonMkrSel.setText("Mkr 1")
        self.menuMkrSel = QtWidgets.QMenu()
        self.menuMkrSel.addAction("Mkr 1", self.MkrSelAction1)
        self.menuMkrSel.addAction("Mkr 2", self.MkrSelAction2)
        self.menuMkrSel.addAction("Mkr 3", self.MkrSelAction3)
        self.menuMkrSel.addAction("Mkr 4", self.MkrSelAction4)
        self.buttonMkrSel.setMenu(self.menuMkrSel)
        self.buttonTrcSel.setText("Trace A")
        self.menuTrcSel = QtWidgets.QMenu()
        self.menuTrcSel.addAction("Trace A", self.TrcSelAction1)
        self.menuTrcSel.addAction("Trace B", self.TrcSelAction2)
        self.menuTrcSel.addAction("Trace C", self.TrcSelAction3)
        self.menuTrcSel.addAction("Trace D", self.TrcSelAction4)
        self.menuTrcSel.addAction("Trace E", self.TrcSelAction5)
        self.menuTrcSel.addAction("Trace F", self.TrcSelAction6)
        self.buttonTrcSel.setMenu(self.menuTrcSel)

        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def MkrSelAction1(self):
        self.buttonMkrSel.setText("Mkr 1")

    def MkrSelAction2(self):
        self.buttonMkrSel.setText("Mkr 2")

    def MkrSelAction3(self):
        self.buttonMkrSel.setText("Mkr 3")

    def MkrSelAction4(self):
        self.buttonMkrSel.setText("Mkr 4")

    def TrcSelAction1(self):
        self.buttonTrcSel.setText("Trace A")

    def TrcSelAction2(self):
        self.buttonTrcSel.setText("Trace B")

    def TrcSelAction3(self):
        self.buttonTrcSel.setText("Trace C")

    def TrcSelAction4(self):
        self.buttonTrcSel.setText("Trace D")

    def TrcSelAction5(self):
        self.buttonTrcSel.setText("Trace E")

    def TrcSelAction6(self):
        self.buttonTrcSel.setText("Trace F")

    def onAccept(self):
        self.marker = self.buttonMkrSel.text()
        self.trace = self.buttonTrcSel.text()
        self.selection = 1
        return self.marker, self.trace, self.selection

    def onReject(self):
        self.selection = 0
        return self.selection

# Main window
class MainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)
        self.actionNew_Instrument.triggered.connect(self.instrumentSelectWindow)
        self.actionClose_Instrument.triggered.connect(self.closeTab)
        self.tabWidget.tabCloseRequested.connect(self.closeTab)
        self.tabCount = 0

    def instrumentSelectWindow(self):
        widget = InstrumentSelect(parent=self)
        widget.exec_()
        self.openInstrument(widget.selection)

    def openInstrument(self, device):
        if device == "Agilent 86142B":
            self.tab = Agilent86142B()
        if device == "":
            return
        self.tabCount += 1
        self.tabWidget.addTab(self.tab, "%i - %s" % (self.tabCount, device))
        self.tabWidget.setCurrentIndex(self.tabCount)

    def closeTab(self, currentIndex):
        currentQWidget = self.tabWidget.widget(currentIndex)
        currentQWidget.deleteLater()
        self.tabWidget.removeTab(currentIndex)


def main():
    app = QtWidgets.QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()