# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'amplitudesetupwindow.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_amplitudeSetupWindow(object):
    def setupUi(self, amplitudeSetupWindow):
        amplitudeSetupWindow.setObjectName("amplitudeSetupWindow")
        amplitudeSetupWindow.resize(400, 266)
        self.verticalLayout = QtWidgets.QVBoxLayout(amplitudeSetupWindow)
        self.verticalLayout.setContentsMargins(14, -1, -1, -1)
        self.verticalLayout.setObjectName("verticalLayout")
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.label_10 = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label_10.setObjectName("label_10")
        self.gridLayout.addWidget(self.label_10, 5, 0, 1, 2)
        self.buttonAmpCorr = QtWidgets.QPushButton(amplitudeSetupWindow)
        self.buttonAmpCorr.setObjectName("buttonAmpCorr")
        self.gridLayout.addWidget(self.buttonAmpCorr, 4, 2, 1, 1)
        self.label_6 = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label_6.setObjectName("label_6")
        self.gridLayout.addWidget(self.label_6, 3, 0, 1, 2)
        self.buttonAmpUnits = QtWidgets.QPushButton(amplitudeSetupWindow)
        self.buttonAmpUnits.setCheckable(False)
        self.buttonAmpUnits.setChecked(False)
        self.buttonAmpUnits.setObjectName("buttonAmpUnits")
        self.gridLayout.addWidget(self.buttonAmpUnits, 0, 2, 1, 1)
        self.buttonAutoChop = QtWidgets.QPushButton(amplitudeSetupWindow)
        self.buttonAutoChop.setCheckable(False)
        self.buttonAutoChop.setObjectName("buttonAutoChop")
        self.gridLayout.addWidget(self.buttonAutoChop, 3, 2, 1, 1)
        self.label_4 = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 1, 0, 1, 2)
        self.label_3 = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 0, 0, 1, 2)
        self.buttonAutoZero = QtWidgets.QPushButton(amplitudeSetupWindow)
        self.buttonAutoZero.setCheckable(False)
        self.buttonAutoZero.setObjectName("buttonAutoZero")
        self.gridLayout.addWidget(self.buttonAutoZero, 2, 2, 1, 1)
        self.label_5 = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label_5.setObjectName("label_5")
        self.gridLayout.addWidget(self.label_5, 2, 0, 1, 2)
        self.buttonAmpCorrMode = QtWidgets.QPushButton(amplitudeSetupWindow)
        self.buttonAmpCorrMode.setObjectName("buttonAmpCorrMode")
        self.gridLayout.addWidget(self.buttonAmpCorrMode, 5, 2, 1, 1)
        self.buttonAutoRang = QtWidgets.QPushButton(amplitudeSetupWindow)
        self.buttonAutoRang.setCheckable(False)
        self.buttonAutoRang.setObjectName("buttonAutoRang")
        self.gridLayout.addWidget(self.buttonAutoRang, 1, 2, 1, 1)
        self.label_9 = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label_9.setObjectName("label_9")
        self.gridLayout.addWidget(self.label_9, 4, 0, 1, 2)
        self.verticalLayout.addLayout(self.gridLayout)
        self.buttonBox = QtWidgets.QDialogButtonBox(amplitudeSetupWindow)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(amplitudeSetupWindow)
        self.buttonBox.accepted.connect(amplitudeSetupWindow.accept)
        self.buttonBox.rejected.connect(amplitudeSetupWindow.reject)
        QtCore.QMetaObject.connectSlotsByName(amplitudeSetupWindow)

    def retranslateUi(self, amplitudeSetupWindow):
        _translate = QtCore.QCoreApplication.translate
        amplitudeSetupWindow.setWindowTitle(_translate("amplitudeSetupWindow", "Amplitude Setup"))
        self.label_10.setText(_translate("amplitudeSetupWindow", "Amplitude Correction Mode:"))
        self.buttonAmpCorr.setText(_translate("amplitudeSetupWindow", "PushButton"))
        self.label_6.setText(_translate("amplitudeSetupWindow", "Auto Chop Mode:"))
        self.buttonAmpUnits.setText(_translate("amplitudeSetupWindow", "PushButton"))
        self.buttonAutoChop.setText(_translate("amplitudeSetupWindow", "PushButton"))
        self.label_4.setText(_translate("amplitudeSetupWindow", "Auto Ranging:"))
        self.label_3.setText(_translate("amplitudeSetupWindow", "Amplitude Units:"))
        self.buttonAutoZero.setText(_translate("amplitudeSetupWindow", "PushButton"))
        self.label_5.setText(_translate("amplitudeSetupWindow", "Auto Zero:"))
        self.buttonAmpCorrMode.setText(_translate("amplitudeSetupWindow", "PushButton"))
        self.buttonAutoRang.setText(_translate("amplitudeSetupWindow", "PushButton"))
        self.label_9.setText(_translate("amplitudeSetupWindow", "Amplitude Correction Set:"))

