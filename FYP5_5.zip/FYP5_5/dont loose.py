##            # Bandwidth
##            elif mkr_1_param[3] == "1":
##                markerX = mkr_1_param[1]
##                markerY = mkr_1_param[2]
##                trc = mkr_1_param[7]
##                xL = str(my_instrument.query("CALCulate:MARKer1:FUNCtion:BANDwidth:X:LEFT?").rstrip())
##                BWxL = conversions.str2float(xL, BW_units)
##                xR = str(my_instrument.query("CALCulate:MARKer1:FUNCtion:BANDwidth:X:RIGHt?").rstrip())
##                BWxR = conversions.str2float(xR, BW_units)
##                xC = str(my_instrument.query("CALCulate:MARKer1:FUNCtion:BANDwidth:X:CENTer?").rstrip())
##                BWxC = conversions.str2float(xC, BW_units)
##                mkrBWY = conversions.str2float(my_instrument.query("CALCulate:MARKer1:FUNCtion:BANDwidth:NDB?"),amplitude_units)                                                        
##                BWyL = mkr_1_param[2] + mkrBWY
##                BWyR = mkr_1_param[2] + mkrBWY
##                BW_1_param = [BWxL, BWxR, BWxC, BWyL, BWyR, mkrBWY]
##            # Delta
##            elif mkr_1_param[5] == "1":
##                delta_distance = my_instrument.query("CALC:MARK1:FUNC:DELTa:X:OFFset?")
##                delta_distance = conversions.str2float(delta_distance,delta_units)
##                markerX = conversions.str2float(str(my_instrument.query("CALCulate:MARKer1:X?").rstrip()),delta_units)
##                markerY = float(my_instrument.query("CALCulate:MARKer1:Y?"))
##                markerXRef = conversions.str2float(str(my_instrument.query("CALCulate:MARKer1:FUNC:DELta:X:REF?").rstrip()),delta_units)
##                markerYRef = float(my_instrument.query("CALCulate:MARKer1:FUNC:DELta:Y:REF?"))
##                delta_1_param = [markerX, markerY, markerXRef, markerYRef, delta_distance]
##            # OSNR
##            elif mkr_1_param[6] == "1":
##                OSNRVal = float(my_instrument.query("CALCulate:MARKer1:FUNCtion:OSNR:RESult?"))
##                OSNRVal = conversions.str2float(OSNRVal,amplitude_units)
##                OSNRxL = conversions.str2float(str(my_instrument.query("CALCulate:MARKer1:FUNCtion:OSNR:X:LEFT?").rstrip()), mkr_units)
##                OSNRxR = conversions.str2float(str(my_instrument.query("CALCulate:MARKer1:FUNCtion:OSNR:X:RIGHt?").rstrip()), mkr_units)
##
##                if active_trace == 'TRA':
##                    trace_data = traceA
##                if active_trace == 'TRB':
##                    trace_data = traceB
##                if active_trace == 'TRC':
##                    trace_data = traceC
##                if active_trace == 'TRD':
##                    trace_data = traceD
##                if active_trace == 'TRE':
##                    trace_data = traceE
##                if active_trace == 'TRF':
##                    trace_data = traceF
##
##                trace_x = trace_data[:,0]
##                trace_y = trace_data[:,1]
##                
##                error_thresh = 1
##                for i in range(len(trace_x)):
##                    distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxL)
##                    if distance_x < error_thresh:
##                        mkr_index = i
##                        error_thresh = distance_x
##                OSNRyL = trace_y[mkr_index]
##
##                error_thresh = 1
##                for i in range(len(trace_x)):
##                    distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxR)
##                    if distance_x < error_thresh:
##                        mkr_index = i
##                        error_thresh = distance_x
##                OSNRyR = trace_y[mkr_index]
##
##                OSNRxC = conversions.str2float(str(my_instrument.query("CALCulate:MARKer1:FUNCtion:OSNR:X:CENTer?").rstrip()), mkr_units)
##
##                error_thresh = 1
##                for i in range(len(trace_x)):
##                    distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxC)
##                    if distance_x < error_thresh:
##                        mkr_index = i
##                        error_thresh = distance_x
##                OSNRyC = trace_y[mkr_index]
##                
##                OSNRyC = float(my_instrument.query("CALCulate:MARKer1:FUNCtion:OSNR:Y:CENTer?"))
##                if OSNRyC > 100:
##                    OSNRyC = 0
##                    OSNRVal = 0
##
##                OSNR_1_param = [OSNRxL, OSNRyL, OSNRxR, OSNRyR, OSNRxC, OSNRyC, OSNRVal]



##            # Bandwidth
##            elif mkr_2_param[3] == "1":
##                markerX = mkr_2_param[1]
##                markerY = mkr_2_param[2]
##                trc = mkr_2_param[7]
##                xL = str(my_instrument.query("CALCulate:marker2:FUNCtion:BANDwidth:X:LEFT?").rstrip())
##                BWxL = conversions.str2float(xL, BW_units)
##                xR = str(my_instrument.query("CALCulate:marker2:FUNCtion:BANDwidth:X:RIGHt?").rstrip())
##                BWxR = conversions.str2float(xR, BW_units)
##                xC = str(my_instrument.query("CALCulate:marker2:FUNCtion:BANDwidth:X:CENTer?").rstrip())
##                BWxC = conversions.str2float(xC, BW_units)
##                mkrBWY = conversions.str2float(my_instrument.query("CALCulate:marker2:FUNCtion:BANDwidth:NDB?"),amplitude_units)                                                        
##                BWyL = mkr_2_param[2] + mkrBWY
##                BWyR = mkr_2_param[2] + mkrBWY
##                BW_2_param = [BWxL, BWxR, BWxC, BWyL, BWyR, mkrBWY]
##            # Delta
##            elif mkr_2_param[5] == "1":
##                delta_distance = my_instrument.query("CALC:MARK2:FUNC:DELTa:X:OFFset?")
##                delta_distance = conversions.str2float(delta_distance,delta_units)
##                markerX = conversions.str2float(str(my_instrument.query("CALCulate:marker2:X?").rstrip()),delta_units)
##                markerY = float(my_instrument.query("CALCulate:marker2:Y?"))
##                markerXRef = conversions.str2float(str(my_instrument.query("CALCulate:marker2:FUNC:DELta:X:REF?").rstrip()),delta_units)
##                markerYRef = float(my_instrument.query("CALCulate:marker2:FUNC:DELta:Y:REF?"))
##                delta_2_param = [markerX, markerY, markerXRef, markerYRef, delta_distance]
##            # OSNR
##            elif mkr_2_param[6] == "1":
##                OSNRVal = float(my_instrument.query("CALCulate:marker2:FUNCtion:OSNR:RESult?"))
##                OSNRVal = conversions.str2float(OSNRVal,amplitude_units)
##                OSNRxL = conversions.str2float(str(my_instrument.query("CALCulate:marker2:FUNCtion:OSNR:X:LEFT?").rstrip()), mkr_units)
##                OSNRxR = conversions.str2float(str(my_instrument.query("CALCulate:marker2:FUNCtion:OSNR:X:RIGHt?").rstrip()), mkr_units)
##
##                if active_trace == 'TRA':
##                    trace_data = traceA
##                if active_trace == 'TRB':
##                    trace_data = traceB
##                if active_trace == 'TRC':
##                    trace_data = traceC
##                if active_trace == 'TRD':
##                    trace_data = traceD
##                if active_trace == 'TRE':
##                    trace_data = traceE
##                if active_trace == 'TRF':
##                    trace_data = traceF
##
##                trace_x = trace_data[:,0]
##                trace_y = trace_data[:,1]
##                
##                error_thresh = 1
##                for i in range(len(trace_x)):
##                    distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxL)
##                    if distance_x < error_thresh:
##                        mkr_index = i
##                        error_thresh = distance_x
##                OSNRyL = trace_y[mkr_index]
##
##                error_thresh = 1
##                for i in range(len(trace_x)):
##                    distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxR)
##                    if distance_x < error_thresh:
##                        mkr_index = i
##                        error_thresh = distance_x
##                OSNRyR = trace_y[mkr_index]
##
##                OSNRxC = conversions.str2float(str(my_instrument.query("CALCulate:MARKer2:FUNCtion:OSNR:X:CENTer?").rstrip()), mkr_units)
##
##                error_thresh = 1
##                for i in range(len(trace_x)):
##                    distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxC)
##                    if distance_x < error_thresh:
##                        mkr_index = i
##                        error_thresh = distance_x
##                OSNRyC = trace_y[mkr_index]
##                
##                OSNRyC = float(my_instrument.query("CALCulate:MARKer2:FUNCtion:OSNR:Y:CENTer?"))
##                if OSNRyC > 100:
##                    OSNRyC = 0
##                    OSNRVal = 0
##
##                OSNR_2_param = [OSNRxL, OSNRyL, OSNRxR, OSNRyR, OSNRxC, OSNRyC, OSNRVal]

##        # Bandwidth
##        elif mkr_3_param[3] == "1":
##            markerX = mkr_3_param[1]
##            markerY = mkr_3_param[2]
##            trc = mkr_3_param[7]
##            xL = str(my_instrument.query("CALCulate:MARKer3:FUNCtion:BANDwidth:X:LEFT?").rstrip())
##            BWxL = conversions.str2float(xL, BW_units)
##            xR = str(my_instrument.query("CALCulate:MARKer3:FUNCtion:BANDwidth:X:RIGHt?").rstrip())
##            BWxR = conversions.str2float(xR, BW_units)
##            xC = str(my_instrument.query("CALCulate:MARKer3:FUNCtion:BANDwidth:X:CENTer?").rstrip())
##            BWxC = conversions.str2float(xC, BW_units)
##            mkrBWY = conversions.str2float(my_instrument.query("CALCulate:MARKer3:FUNCtion:BANDwidth:NDB?"),amplitude_units)                                                        
##            BWyL = mkr_3_param[2] + mkrBWY
##            BWyR = mkr_3_param[2] + mkrBWY
##            BW_3_param = [BWxL, BWxR, BWxC, BWyL, BWyR, mkrBWY]
##        # Delta
##        elif mkr_3_param[5] == "1":
##            delta_distance = my_instrument.query("CALC:MARK3:FUNC:DELTa:X:OFFset?")
##            delta_distance = conversions.str2float(delta_distance,delta_units)
##            markerX = conversions.str2float(str(my_instrument.query("CALCulate:MARKer3:X?").rstrip()),delta_units)
##            markerY = float(my_instrument.query("CALCulate:MARKer3:Y?"))
##            markerXRef = conversions.str2float(str(my_instrument.query("CALCulate:MARKer3:FUNC:DELta:X:REF?").rstrip()),delta_units)
##            markerYRef = float(my_instrument.query("CALCulate:MARKer3:FUNC:DELta:Y:REF?"))
##            delta_3_param = [markerX, markerY, markerXRef, markerYRef, delta_distance]
##        # OSNR
##        elif mkr_3_param[6] == "1":
##            OSNRVal = float(my_instrument.query("CALCulate:MARKer3:FUNCtion:OSNR:RESult?"))
##            OSNRVal = conversions.str2float(OSNRVal,amplitude_units)
##            OSNRxL = conversions.str2float(str(my_instrument.query("CALCulate:MARKer3:FUNCtion:OSNR:X:LEFT?").rstrip()), mkr_units)
##            OSNRxR = conversions.str2float(str(my_instrument.query("CALCulate:MARKer3:FUNCtion:OSNR:X:RIGHt?").rstrip()), mkr_units)
##
##            if active_trace == 'TRA':
##                trace_data = traceA
##            if active_trace == 'TRB':
##                trace_data = traceB
##            if active_trace == 'TRC':
##                trace_data = traceC
##            if active_trace == 'TRD':
##                trace_data = traceD
##            if active_trace == 'TRE':
##                trace_data = traceE
##            if active_trace == 'TRF':
##                trace_data = traceF
##
##            trace_x = trace_data[:,0]
##            trace_y = trace_data[:,1]
##            
##            error_thresh = 1
##            for i in range(len(trace_x)):
##                distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxL)
##                if distance_x < error_thresh:
##                    mkr_index = i
##                    error_thresh = distance_x
##            OSNRyL = trace_y[mkr_index]
##
##            error_thresh = 1
##            for i in range(len(trace_x)):
##                distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxR)
##                if distance_x < error_thresh:
##                    mkr_index = i
##                    error_thresh = distance_x
##            OSNRyR = trace_y[mkr_index]
##
##            OSNRxC = conversions.str2float(str(my_instrument.query("CALCulate:MARKer3:FUNCtion:OSNR:X:CENTer?").rstrip()), mkr_units)
##
##            error_thresh = 1
##            for i in range(len(trace_x)):
##                distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxC)
##                if distance_x < error_thresh:
##                    mkr_index = i
##                    error_thresh = distance_x
##            OSNRyC = trace_y[mkr_index]
##            
##            OSNRyC = float(my_instrument.query("CALCulate:MARKer3:FUNCtion:OSNR:Y:CENTer?"))
##            if OSNRyC > 100:
##                OSNRyC = 0
##                OSNRVal = 0
##
##            OSNR_3_param = [OSNRxL, OSNRyL, OSNRxR, OSNRyR, OSNRxC, OSNRyC, OSNRVal] 


##        # Bandwidth
##        elif mkr_4_param[3] == "1":
##            markerX = mkr_4_param[1]
##            markerY = mkr_4_param[2]
##            trc = mkr_4_param[7]
##            xL = str(my_instrument.query("CALCulate:MARKer4:FUNCtion:BANDwidth:X:LEFT?").rstrip())
##            BWxL = conversions.str2float(xL, BW_units)
##            xR = str(my_instrument.query("CALCulate:MARKer4:FUNCtion:BANDwidth:X:RIGHt?").rstrip())
##            BWxR = conversions.str2float(xR, BW_units)
##            xC = str(my_instrument.query("CALCulate:MARKer4:FUNCtion:BANDwidth:X:CENTer?").rstrip())
##            BWxC = conversions.str2float(xC, BW_units)
##            mkrBWY = conversions.str2float(my_instrument.query("CALCulate:MARKer4:FUNCtion:BANDwidth:NDB?"),amplitude_units)                                                        
##            BWyL = mkr_4_param[2] + mkrBWY
##            BWyR = mkr_4_param[2] + mkrBWY
##            BW_4_param = [BWxL, BWxR, BWxC, BWyL, BWyR, mkrBWY]
##        # Delta
##        elif mkr_4_param[5] == "1":
##            delta_distance = my_instrument.query("CALC:MARK4:FUNC:DELTa:X:OFFset?")
##            delta_distance = conversions.str2float(delta_distance,delta_units)
##            markerX = conversions.str2float(str(my_instrument.query("CALCulate:MARKer4:X?").rstrip()),delta_units)
##            markerY = float(my_instrument.query("CALCulate:MARKer4:Y?"))
##            markerXRef = conversions.str2float(str(my_instrument.query("CALCulate:MARKer4:FUNC:DELta:X:REF?").rstrip()),delta_units)
##            markerYRef = float(my_instrument.query("CALCulate:MARKer4:FUNC:DELta:Y:REF?"))
##            delta_4_param = [markerX, markerY, markerXRef, markerYRef, delta_distance]
##        # OSNR
##        elif mkr_4_param[6] == "1":
##            OSNRVal = float(my_instrument.query("CALCulate:MARKer4:FUNCtion:OSNR:RESult?"))
##            OSNRVal = conversions.str2float(OSNRVal,amplitude_units)
##            OSNRxL = conversions.str2float(str(my_instrument.query("CALCulate:MARKer4:FUNCtion:OSNR:X:LEFT?").rstrip()), mkr_units)
##            OSNRxR = conversions.str2float(str(my_instrument.query("CALCulate:MARKer4:FUNCtion:OSNR:X:RIGHt?").rstrip()), mkr_units)
##
##            if active_trace == 'TRA':
##                trace_data = traceA
##            if active_trace == 'TRB':
##                trace_data = traceB
##            if active_trace == 'TRC':
##                trace_data = traceC
##            if active_trace == 'TRD':
##                trace_data = traceD
##            if active_trace == 'TRE':
##                trace_data = traceE
##            if active_trace == 'TRF':
##                trace_data = traceF
##
##            trace_x = trace_data[:,0]
##            trace_y = trace_data[:,1]
##            
##            error_thresh = 1
##            for i in range(len(trace_x)):
##                distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxL)
##                if distance_x < error_thresh:
##                    mkr_index = i
##                    error_thresh = distance_x
##            OSNRyL = trace_y[mkr_index]
##
##            error_thresh = 1
##            for i in range(len(trace_x)):
##                distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxR)
##                if distance_x < error_thresh:
##                    mkr_index = i
##                    error_thresh = distance_x
##            OSNRyR = trace_y[mkr_index]
##
##            OSNRxC = conversions.str2float(str(my_instrument.query("CALCulate:MARKer4:FUNCtion:OSNR:X:CENTer?").rstrip()), mkr_units)
##
##            error_thresh = 1
##            for i in range(len(trace_x)):
##                distance_x = abs(conversions.str2float(trace_x[i],wavelength_units)-OSNRxC)
##                if distance_x < error_thresh:
##                    mkr_index = i
##                    error_thresh = distance_x
##            OSNRyC = trace_y[mkr_index]
##            
##            OSNRyC = float(my_instrument.query("CALCulate:MARKer4:FUNCtion:OSNR:Y:CENTer?"))
##            if OSNRyC > 100:
##                OSNRyC = 0
##                OSNRVal = 0
##
##            OSNR_4_param = [OSNRxL, OSNRyL, OSNRxR, OSNRyR, OSNRxC, OSNRyC, OSNRVal] 
