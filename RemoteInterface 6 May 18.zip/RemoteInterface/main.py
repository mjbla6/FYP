# Remote Interface FYP 2018
# Mitch Blair & Isaac Naylor
#
# Last edit: 23/04/18
# Progress: NEED TO SEE TRACE MATH MENU EXCHANGE SUB AND TRACE OFFSET SUB
# 			Everything else is done except for applications... Do we need to do these?
#			Next step? Port Agilent instrument to separate file and work on next instrument?

from PyQt5 import QtCore, QtGui, QtWidgets
import sys
import pyqtgraph as pg
import numpy

from gui_mainwindow import Ui_MainWindow
from gui_instrumentselect import Ui_instrumentSelect
from gui_inputdialog import Ui_inputDialog
from gui_hp8157a import Ui_HP8157A
from gui_agilent86142b import Ui_Agilent86142B
from gui_amplitudesetupwindow import Ui_amplitudeSetupWindow
from gui_wavelengthsetupwindow import Ui_wavelengthSetupWindow
from gui_activemarkerswindow import Ui_activeMarkersWindow
from gui_activetracewindow import Ui_activeTraceWindow
from gui_markersetupwindow import Ui_markerSetupWindow
from gui_advancedlinemarkerwindow import Ui_advancedLineMarkerWindow
from gui_systemwindow import Ui_systemWindow

class InstrumentSelect(QtWidgets.QDialog, Ui_instrumentSelect):
	def __init__(self, parent=None):
		super(InstrumentSelect, self).__init__(parent)
		self.setupUi(self)
		self.listWidget.addItem("Agilent 86142B")
		self.listWidget.addItem("HP 8157A")
		self.accepted.connect(self.onAccept)
		self.rejected.connect(self.onReject)

	def onAccept(self):
		self.selection = self.listWidget.currentItem().text()
		return self.selection

	def onReject(self):
		self.selection = ""
		return self.selection


# HP 8157A instrument
class hp8157A(QtWidgets.QWidget, Ui_HP8157A):
	def __init__(self, parent=None):
		super(hp8157A, self).__init__(parent)
		self.setupUi(self)
		self.spinBox.valueChanged.connect(self.valueChange)

	def valueChange(self):
		self.lcdAtt.display(self.spinBox.value())


# Agilent 86142B instrument
class Agilent86142B(QtWidgets.QWidget, Ui_Agilent86142B):
	def __init__(self, parent=None):
		super(Agilent86142B, self).__init__(parent)
		self.setupUi(self)

		# Setup graph variables
		y = [2,4,6,8,10,12,14,16,18,20]
		y2 = [0,1,2,4,12,14,16,17,14,22]
		x = range(0,10)

		# Setup graph
		self.plot = pg.GraphicsWindow()
		self.p1 = self.plot.addPlot()
		self.p1.showGrid(x=True, y=True)
		self.p1.setLabel('left', 'Amplitude', units='dBm')
		self.p1.setLabel('bottom', 'Wavelength', units='nm')
		c1 = self.p1.plot(x, y, pen='y')
		c2 = self.p1.plot(x, y2, pen='r')
		self.graphLayout.addWidget(self.plot)

		# Top menu buttons clicked
		self.buttonWavelength.clicked.connect(self.wavelengthMenu)
		self.buttonAmplitude.clicked.connect(self.amplitudeMenu)
		self.buttonMarkers.clicked.connect(self.markersMenu)
		self.buttonTraces.clicked.connect(self.tracesMenu)
		self.buttonBW.clicked.connect(self.bwMenu)
		self.buttonSystem.clicked.connect(self.systemMenu)

	# Function to clear sub-menu ready to add next menu
	def clearLayout(self, layout):
		if layout != None:
			while layout.count():
				child = layout.takeAt(0)
				if child.widget() is not None:
					child.widget().deleteLater()
				elif child.layout() is not None:
					clearLayout(child.layout())

	# Wavelength sub-menu
	def wavelengthMenu(self):
		self.clearLayout(self.subButtonLayout)	

		self.buttonCenterWL = QtWidgets.QPushButton("Center WL", self)
		self.subButtonLayout.addWidget(self.buttonCenterWL)
		self.buttonSpan = QtWidgets.QPushButton("Span", self)
		self.subButtonLayout.addWidget(self.buttonSpan)
		self.buttonStartWL = QtWidgets.QPushButton("Start WL", self)
		self.subButtonLayout.addWidget(self.buttonStartWL)
		self.buttonStopWL = QtWidgets.QPushButton("Stop WL", self)
		self.subButtonLayout.addWidget(self.buttonStopWL)
		self.buttonPeakToCenter = QtWidgets.QPushButton("Peak To Center", self)
		self.subButtonLayout.addWidget(self.buttonPeakToCenter)
		self.buttonBlank = QtWidgets.QPushButton("", self)
		self.subButtonLayout.addWidget(self.buttonBlank)
		self.buttonWavelengthSetup = QtWidgets.QPushButton("Wavelength Setup", self)
		self.subButtonLayout.addWidget(self.buttonWavelengthSetup)

		self.buttonCenterWL.clicked.connect(self.centerWL)
		self.buttonSpan.clicked.connect(self.span)
		self.buttonStartWL.clicked.connect(self.startWL)
		self.buttonStopWL.clicked.connect(self.stopWL)
		self.buttonWavelengthSetup.clicked.connect(self.wavelengthSetupWindow)

	def centerWL(self):
		# Query/read instrument current state and then pass to input dialog lineEdit
		widget = InputDialog("Center WL", "nm")
		widget.exec_()
		#current_instrument.write(Center_Wavelength + "%s") % widget.userInput 
		print(widget.userInput)

	def span(self):
		widget = InputDialog("Span", "nm")
		widget.exec_()

	def startWL(self):
		widget = InputDialog("Start WL", "nm")
		widget.exec_()

	def stopWL(self):
		widget = InputDialog("Stop WL", "nm")
		widget.exec_()

	def wavelengthSetupWindow(self):
		widget = WavelengthSetup(parent=self)
		widget.exec_()

	# Amplitude sub-menu
	def amplitudeMenu(self):
		self.clearLayout(self.subButtonLayout)	

		self.buttonRefLvl = QtWidgets.QPushButton("Reference Level", self)
		self.subButtonLayout.addWidget(self.buttonRefLvl)
		self.buttonScaleDiv = QtWidgets.QPushButton("Scale/Div", self)
		self.subButtonLayout.addWidget(self.buttonScaleDiv)
		self.buttonDispMode = QtWidgets.QPushButton("Display Mode [Log]", self)
		self.buttonDispMode.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonDispMode)
		self.buttonSensitivity = QtWidgets.QPushButton("Sensitivity [Auto]", self)
		self.buttonSensitivity.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonSensitivity)
		self.buttonPeakToRefLvl = QtWidgets.QPushButton("Peak To Ref Level", self)
		self.subButtonLayout.addWidget(self.buttonPeakToRefLvl)
		self.buttonTraceInteg = QtWidgets.QPushButton("Trace Integ [Off]", self)
		self.buttonTraceInteg.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonTraceInteg)
		self.buttonAmplitudeSetup = QtWidgets.QPushButton("Amplitude Setup", self)
		self.subButtonLayout.addWidget(self.buttonAmplitudeSetup)

		self.buttonRefLvl.clicked.connect(self.refLVL)
		self.buttonScaleDiv.clicked.connect(self.scaleDiv)
		self.buttonDispMode.clicked.connect(self.dispMode)
		self.buttonSensitivity.clicked.connect(self.sensitivity)
		self.buttonPeakToRefLvl.clicked.connect(self.peakToRefLvl)
		self.buttonTraceInteg.clicked.connect(self.traceInteg)
		self.buttonAmplitudeSetup.clicked.connect(self.amplitudeSetupWindow)

	def refLVL(self):
		widget = InputDialog("Reference Level", "dBm")
		widget.exec_()

	def scaleDiv(self):
		widget = InputDialog("Scale/Div", "dB")
		widget.exec_()

	def dispMode(self):
		if self.buttonDispMode.isChecked():
			self.buttonDispMode.setText("Display Mode [Lin]")
		else:
			self.buttonDispMode.setText("Display Mode [Log]")

	def sensitivity(self):
		if self.buttonSensitivity.isChecked():
			self.buttonSensitivity.setText("Sensitivity [Man]")
		else:
			self.buttonSensitivity.setText("Sensitivity [Auto]")

	def peakToRefLvl(self):
		widget = InputDialog("Peak to Reference Level", "dBm")
		widget.exec_()

	def traceInteg(self):
		if self.buttonTraceInteg.isChecked():
			self.buttonTraceInteg.setText("Trace Integ [On]")
		else:
			self.buttonTraceInteg.setText("Trace Integ [Off]")

	def amplitudeSetupWindow(self):
		widget = AmplitudeSetup()
		widget.exec_()


	# Markers sub-menu
	def markersMenu(self):
		self.clearLayout(self.subButtonLayout)	

		self.buttonActMrks = QtWidgets.QPushButton("Active Markers", self)
		self.subButtonLayout.addWidget(self.buttonActMrks)
		self.buttonActTrce = QtWidgets.QPushButton("Active Trace", self)
		self.subButtonLayout.addWidget(self.buttonActTrce)
		self.buttonPeakSrch = QtWidgets.QPushButton("Peak Search", self)
		self.subButtonLayout.addWidget(self.buttonPeakSrch)
		self.buttonMkrToCen = QtWidgets.QPushButton("Marker to Center", self)
		self.subButtonLayout.addWidget(self.buttonMkrToCen)
		self.buttonMkrToRefLvl = QtWidgets.QPushButton("Marker To Ref Level", self)
		self.subButtonLayout.addWidget(self.buttonMkrToRefLvl)
		self.buttonMkrSetup = QtWidgets.QPushButton("Marker Setup", self)
		self.subButtonLayout.addWidget(self.buttonMkrSetup)
		self.buttonMoreMkrFunc = QtWidgets.QPushButton("More Marker Functons", self)
		self.subButtonLayout.addWidget(self.buttonMoreMkrFunc)

		self.buttonActMrks.clicked.connect(self.actMrks)
		self.buttonActTrce.clicked.connect(self.actTrce)
		self.buttonMkrSetup.clicked.connect(self.mkrSetup)
		self.buttonPeakSrch.clicked.connect(self.peakSrch)
		self.buttonMkrToCen.clicked.connect(self.mrkToCen)
		self.buttonMkrToRefLvl.clicked.connect(self.mkrToRefLvl)
		self.buttonMoreMkrFunc.clicked.connect(self.moreMkrFunc)

	def actMrks(self):
		widget = ActiveMarkersWindow("Active Markers")
		widget.exec_()

	def actTrce(self):
		widget = ActiveTraceWindow("Active Trace")
		widget.exec_()

	def peakSrch(self):
		widget = InputDialog("Peak Search", "nm")
		widget.exec_()

	def mrkToCen(self):
		widget = InputDialog("Marker To Center", "nm")
		widget.exec_()

	def mkrToRefLvl(self):
		widget = InputDialog("Marker To Ref Lvl", "dBm")
		widget.exec_()

	def mkrSetup(self):
		widget = MarkerSetup()
		widget.exec_()

	def moreMkrFunc(self):
		self.clearLayout(self.subButtonLayout)	

		self.buttonMkrSrchMenu = QtWidgets.QPushButton("Marker Search Menu", self)
		self.subButtonLayout.addWidget(self.buttonMkrSrchMenu)
		self.buttonMkrBW = QtWidgets.QPushButton("Marker Bandwidth", self)
		self.subButtonLayout.addWidget(self.buttonMkrBW)
		self.buttonNoiseMkr = QtWidgets.QPushButton("Noise Marker [Off]", self)
		self.buttonNoiseMkr.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonNoiseMkr)
		self.buttonDeltaMkr = QtWidgets.QPushButton("Delta Marker [Off]", self)
		self.buttonDeltaMkr.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonDeltaMkr)
		self.buttonOSNRMkr = QtWidgets.QPushButton("OSNR Marker [Off]", self)
		self.buttonOSNRMkr.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonOSNRMkr)
		self.buttonLineMkrMenu = QtWidgets.QPushButton("Line Marker Menu", self)
		self.subButtonLayout.addWidget(self.buttonLineMkrMenu)
		self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
		self.subButtonLayout.addWidget(self.buttonPrevMenu)

		self.buttonMkrSrchMenu.clicked.connect(self.mkrSrchMenu)
		self.buttonNoiseMkr.clicked.connect(self.noiseMkr)
		self.buttonDeltaMkr.clicked.connect(self.deltaMkr)
		self.buttonOSNRMkr.clicked.connect(self.OSNRMkr)
		self.buttonLineMkrMenu.clicked.connect(self.lineMkrMenu)
		self.buttonPrevMenu.clicked.connect(self.markersMenu)

	def mkrSrchMenu(self):
		self.clearLayout(self.subButtonLayout)	

		self.buttonSrchMode = QtWidgets.QPushButton("Search Mode [Peak]", self)
		self.buttonSrchMode.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonSrchMode)
		self.buttonPeakSrch = QtWidgets.QPushButton("Peak Search", self)
		self.subButtonLayout.addWidget(self.buttonPeakSrch)
		self.buttonNextPeakDown = QtWidgets.QPushButton("Next Peak Down", self)
		self.subButtonLayout.addWidget(self.buttonNextPeakDown)
		self.buttonNextPeakLeft = QtWidgets.QPushButton("Next Peak Left", self)
		self.subButtonLayout.addWidget(self.buttonNextPeakLeft)
		self.buttonNextPeakRight = QtWidgets.QPushButton("Next Peak Right", self)
		self.subButtonLayout.addWidget(self.buttonNextPeakRight)
		self.buttonActMrks = QtWidgets.QPushButton("Active Markers", self)
		self.subButtonLayout.addWidget(self.buttonActMrks)
		self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
		self.subButtonLayout.addWidget(self.buttonPrevMenu)

		self.buttonSrchMode.clicked.connect(self.srchMode)
		self.buttonPeakSrch.clicked.connect(self.peakSrch)
		self.buttonActMrks.clicked.connect(self.actMrks)
		self.buttonPrevMenu.clicked.connect(self.moreMkrFunc)

	def srchMode(self):
		if self.buttonSrchMode.isChecked():
			self.buttonSrchMode.setText("Search Mode [Pit]")
		else:
			self.buttonSrchMode.setText("Search Mode [Peak]")

	def noiseMkr(self):
		if self.buttonNoiseMkr.isChecked():
			self.buttonNoiseMkr.setText("Noise Marker [On]")
		else:
			self.buttonNoiseMkr.setText("Noise Marker [Off]")
		
	def deltaMkr(self):
		if self.buttonDeltaMkr.isChecked():
			self.buttonDeltaMkr.setText("Delta Marker [On]")
		else:
			self.buttonDeltaMkr.setText("Delta Marker [Off]")

	def OSNRMkr(self):
		if self.buttonOSNRMkr.isChecked():
			self.buttonOSNRMkr.setText("OSNR Marker [On]")
		else:
			self.buttonOSNRMkr.setText("OSNR Marker [Off]")

	def lineMkrMenu(self):
		self.clearLayout(self.subButtonLayout)

		self.buttonWLLineMkr1 = QtWidgets.QPushButton("Wavelength Line Mkr 1", self)
		self.subButtonLayout.addWidget(self.buttonWLLineMkr1)
		self.buttonWLLineMkr2 = QtWidgets.QPushButton("Wavelength Line Mkr 2", self)
		self.subButtonLayout.addWidget(self.buttonWLLineMkr2)
		self.buttonBlank = QtWidgets.QPushButton("", self)
		self.subButtonLayout.addWidget(self.buttonBlank)
		self.buttonBlank = QtWidgets.QPushButton("", self)
		self.subButtonLayout.addWidget(self.buttonBlank)
		self.buttonLineMkrsOff = QtWidgets.QPushButton("Line Markers Off", self)
		self.subButtonLayout.addWidget(self.buttonLineMkrsOff)
		self.buttonAdvLineMkrFunc = QtWidgets.QPushButton("Advanved Line Marker Functions", self)
		self.subButtonLayout.addWidget(self.buttonAdvLineMkrFunc)
		self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
		self.subButtonLayout.addWidget(self.buttonPrevMenu)

		self.buttonAdvLineMkrFunc.clicked.connect(self.advLineMkrFunc)
		self.buttonPrevMenu.clicked.connect(self.moreMkrFunc)

	def advLineMkrFunc(self):
		widget = AdvancedLineMarkerWindow()
		widget.exec_()


	# Trace sub-menu
	def tracesMenu(self):
		self.clearLayout(self.subButtonLayout)	

		self.buttonActTrce = QtWidgets.QPushButton("Active Trace", self)
		self.subButtonLayout.addWidget(self.buttonActTrce)
		self.buttonUpdtTrce = QtWidgets.QPushButton("Update Trace [Off]", self)
		self.buttonUpdtTrce.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonUpdtTrce)
		self.buttonViewTrce = QtWidgets.QPushButton("View Trace [Off]", self)
		self.buttonViewTrce.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonViewTrce)
		self.buttonHoldTrce = QtWidgets.QPushButton("Hold Trace [None]", self)
		self.menuHoldTrce = QtWidgets.QMenu()
		self.menuHoldTrce.addAction("None", self.HoldTrceAction1)
		self.menuHoldTrce.addAction("Min", self.HoldTrceAction2)
		self.menuHoldTrce.addAction("Max", self.HoldTrceAction3)
		self.buttonHoldTrce.setMenu(self.menuHoldTrce)
		self.subButtonLayout.addWidget(self.buttonHoldTrce)
		self.buttonTrceMath = QtWidgets.QPushButton("Trace Math", self)
		self.subButtonLayout.addWidget(self.buttonTrceMath)
		self.buttonAveraging = QtWidgets.QPushButton("Averaging [Off]", self)
		self.buttonAveraging.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonAveraging)
		self.buttonTrceSetup = QtWidgets.QPushButton("Trace Setup", self)
		self.subButtonLayout.addWidget(self.buttonTrceSetup)

		self.buttonActTrce.clicked.connect(self.actTrce)
		self.buttonUpdtTrce.clicked.connect(self.updtTrce)
		self.buttonViewTrce.clicked.connect(self.viewTrce)
		self.buttonTrceMath.clicked.connect(self.trceMath)
		self.buttonAveraging.clicked.connect(self.averaging)
		self.buttonTrceSetup.clicked.connect(self.trceSetup)

	def HoldTrceAction1(self):
		self.buttonHoldTrce.setText("Hold Trace [None]")

	def HoldTrceAction2(self):
		self.buttonHoldTrce.setText("Hold Trace [Min]")

	def HoldTrceAction3(self):
		self.buttonHoldTrce.setText("Hold Trace [Max]")

	def updtTrce(self):
		if self.buttonUpdtTrce.isChecked():
			self.buttonUpdtTrce.setText("Update Trace [On]")
		else:
			self.buttonUpdtTrce.setText("Update Trace [Off]")

	def viewTrce(self):
		if self.buttonViewTrce.isChecked():
			self.buttonViewTrce.setText("View Trace [On]")
		else:
			self.buttonViewTrce.setText("View Trace [Off]")

	def trceMath(self):
		self.clearLayout(self.subButtonLayout)

		self.buttonDefMathTrcC = QtWidgets.QPushButton("Default Math Trace C", self)
		self.subButtonLayout.addWidget(self.buttonDefMathTrcC)
		self.buttonDefMathTrcF = QtWidgets.QPushButton("Default Math Trace F", self)
		self.subButtonLayout.addWidget(self.buttonDefMathTrcF)
		self.buttonExchMenu = QtWidgets.QPushButton("Exchange Menu", self)
		self.subButtonLayout.addWidget(self.buttonExchMenu)
		self.buttonTrceOffset = QtWidgets.QPushButton("Trace Offset", self)
		self.subButtonLayout.addWidget(self.buttonTrceOffset)
		self.buttonBlank = QtWidgets.QPushButton("", self)
		self.subButtonLayout.addWidget(self.buttonBlank)
		self.buttonAllMathOff = QtWidgets.QPushButton("All Math Off", self)
		self.subButtonLayout.addWidget(self.buttonAllMathOff)
		self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
		self.subButtonLayout.addWidget(self.buttonPrevMenu)

		self.buttonPrevMenu.clicked.connect(self.tracesMenu)

	def averaging(self):
		if self.buttonAveraging.isChecked():
			self.buttonAveraging.setText("Averaging [On]")
		else:
			self.buttonAveraging.setText("Averaging [Off]")

	def trceSetup(self):
		widget = InputDialog("Trace Setup", "Sweep Points")
		widget.exec_()


	# Bandwidth/Sweep sub-menu
	def bwMenu(self):
		self.clearLayout(self.subButtonLayout)	

		self.buttonResBW = QtWidgets.QPushButton("Res BW [Auto]", self)
		self.buttonResBW.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonResBW)
		self.buttonVidBW = QtWidgets.QPushButton("Video BW [Auto]", self)
		self.buttonVidBW.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonVidBW)
		self.buttonSweepTime = QtWidgets.QPushButton("Sweep Time [Auto]", self)
		self.buttonSweepTime.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonSweepTime)
		self.buttonRptSweep = QtWidgets.QPushButton("Repeat Sweep [Off]", self)
		self.buttonRptSweep.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonRptSweep)
		self.buttonSnglSweep = QtWidgets.QPushButton("Single Sweep", self)
		self.subButtonLayout.addWidget(self.buttonSnglSweep)
		self.buttonBlank = QtWidgets.QPushButton("", self)
		self.subButtonLayout.addWidget(self.buttonBlank)
		self.buttonMoreBWFunc = QtWidgets.QPushButton("More BW/Sweep Functions", self)
		self.subButtonLayout.addWidget(self.buttonMoreBWFunc)

		self.buttonResBW.clicked.connect(self.resBW)
		self.buttonVidBW.clicked.connect(self.vidBW)
		self.buttonSweepTime.clicked.connect(self.sweepTime)
		self.buttonRptSweep.clicked.connect(self.rptSweep)
		self.buttonMoreBWFunc.clicked.connect(self.moreBWFunc)

	def resBW(self):
		if self.buttonResBW.isChecked():
			self.buttonResBW.setText("Res BW [Man]")
		else:
			self.buttonResBW.setText("Res BW [Auto]")

	def vidBW(self):
		if self.buttonVidBW.isChecked():
			self.buttonVidBW.setText("Video BW [Man]")
		else:
			self.buttonVidBW.setText("Vidwo BW [Auto]")

	def sweepTime(self):
		if self.buttonSweepTime.isChecked():
			self.buttonSweepTime.setText("Sweep Time [Man]")
		else:
			self.buttonSweepTime.setText("Sweep Time [Auto]")

	def rptSweep(self):
		if self.buttonRptSweep.isChecked():
			self.buttonRptSweep.setText("Repeat Sweep [On]")
		else:
			self.buttonRptSweep.setText("Repeat Sweep [Off]")

	def moreBWFunc(self):
		self.clearLayout(self.subButtonLayout)	

		self.buttonTrigMode = QtWidgets.QPushButton("Trigger Mode [Internal]", self)
		self.menuTrigMode = QtWidgets.QMenu()
		self.menuTrigMode.addAction("Internal", self.TrigModeAction1)
		self.menuTrigMode.addAction("Gated", self.TrigModeAction2)
		self.menuTrigMode.addAction("External", self.TrigModeAction3)
		self.menuTrigMode.addAction("ADC+", self.TrigModeAction4)
		self.menuTrigMode.addAction("ADC-", self.TrigModeAction5)
		self.buttonTrigMode.setMenu(self.menuTrigMode)
		self.subButtonLayout.addWidget(self.buttonTrigMode)
		self.buttonTrigDelay = QtWidgets.QPushButton("Trigger Delay", self)
		self.subButtonLayout.addWidget(self.buttonTrigDelay)
		self.buttonADCTrigSync = QtWidgets.QPushButton("ADC Trig Sync [Low]", self)
		self.menuADCTrig = QtWidgets.QMenu()
		self.menuADCTrig.addAction("Low", self.ADCTrigAction1)
		self.menuADCTrig.addAction("High", self.ADCTrigAction2)
		self.menuADCTrig.addAction("Pulse", self.ADCTrigAction3)
		self.buttonADCTrigSync.setMenu(self.menuADCTrig)
		self.subButtonLayout.addWidget(self.buttonADCTrigSync)
		self.buttonADCSyncOut = QtWidgets.QPushButton("ADC Sync Out [Off]", self)
		self.buttonADCSyncOut.setCheckable(1)
		self.subButtonLayout.addWidget(self.buttonADCSyncOut)
		self.buttonADCSyncOutDuty = QtWidgets.QPushButton("ADC Sync Out Duty Cycle", self)
		self.subButtonLayout.addWidget(self.buttonADCSyncOutDuty)
		self.buttonADCSyncOutPulse = QtWidgets.QPushButton("ADC Sync Out Pulse Width", self)
		self.subButtonLayout.addWidget(self.buttonADCSyncOutPulse)
		self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
		self.subButtonLayout.addWidget(self.buttonPrevMenu)

		self.buttonTrigDelay.clicked.connect(self.trigDelay)
		self.buttonADCSyncOut.clicked.connect(self.ADCSyncOut)
		self.buttonADCSyncOutDuty.clicked.connect(self.ADCSyncOutDuty)
		self.buttonADCSyncOutPulse.clicked.connect(self.ADCSyncOutPulse)
		self.buttonPrevMenu.clicked.connect(self.bwMenu)

	def TrigModeAction1(self):
		self.buttonTrigMode.setText("Trigger Mode [Internal]")

	def TrigModeAction2(self):
		self.buttonTrigMode.setText("Trigger Mode [Gated]")

	def TrigModeAction3(self):
		self.buttonTrigMode.setText("Trigger Mode [External]")

	def TrigModeAction4(self):
		self.buttonTrigMode.setText("Trigger Mode [ADC+]")

	def TrigModeAction5(self):
		self.buttonTrigMode.setText("Trigger Mode [ADC-]")

	def trigDelay(self):
		widget = InputDialog("Trigger Delay", "us")
		widget.exec_()

	def ADCTrigAction1(self):
		self.buttonADCTrigSync.setText("ADC Trig Sync [Low]")

	def ADCTrigAction2(self):
		self.buttonADCTrigSync.setText("ADC Trig Sync [High]")

	def ADCTrigAction3(self):
		self.buttonADCTrigSync.setText("ADC Trig Sync [Pulse]")

	def ADCSyncOut(self):
		if self.buttonADCSyncOut.isChecked():
			self.buttonADCSyncOut.setText("ADC Sync Out [On]")
		else:
			self.buttonADCSyncOut.setText("ADC Sync Out [Off]")

	def ADCSyncOutDuty(self):
		widget = InputDialog("ADC Sync Out Duty Cycle", "us")
		widget.exec_()

	def ADCSyncOutPulse(self):
		widget = InputDialog("ADC Sync Out Pulse Width", "us")
		widget.exec_()


	# System sub-meuu
	def systemMenu(self):
		widget = SystemWindow()
		widget.exec_()


class InputDialog(QtWidgets.QDialog, Ui_inputDialog):
	def __init__(self, title, unit, parent=None):
		super(InputDialog, self).__init__(parent)
		self.setupUi(self)
		self.setWindowTitle(title)
		self.label.setText(unit)
		self.accepted.connect(self.onAccept)
		self.rejected.connect(self.onReject)

	def onAccept(self):
		self.userInput = self.lineEdit.text()
		return self.userInput 

	def onReject(self):
		self.userInput = 0
		return self.userInput


class ActiveMarkersWindow(QtWidgets.QDialog, Ui_activeMarkersWindow):
	def __init__(self, title, parent=None):
		super(ActiveMarkersWindow, self).__init__(parent)
		self.setupUi(self)
		self.setWindowTitle(title)


class ActiveTraceWindow(QtWidgets.QDialog, Ui_activeTraceWindow):
	def __init__(self, title, parent=None):
		super(ActiveTraceWindow, self).__init__(parent)
		self.setupUi(self)
		self.setWindowTitle(title)


class AmplitudeSetup(QtWidgets.QDialog, Ui_amplitudeSetupWindow):
	def __init__(self, parent=None):
		super(AmplitudeSetup, self).__init__(parent)
		self.setupUi(self)

		self.buttonAmpUnits.setText("Auto")
		self.menuAmpUnits = QtWidgets.QMenu()
		self.menuAmpUnits.addAction("Auto", self.AmpUnitsAction1)
		self.menuAmpUnits.addAction("W", self.AmpUnitsAction2)
		self.buttonAmpUnits.setMenu(self.menuAmpUnits)
		self.buttonAutoRang.setText("On")
		self.menuAutoRang = QtWidgets.QMenu()
		self.menuAutoRang.addAction("On", self.AutoRangAction1)
		self.menuAutoRang.addAction("Off", self.AutoRangAction2)
		self.buttonAutoRang.setMenu(self.menuAutoRang)
		self.buttonAmpCorr.setText("1")
		self.menuAmpCorr = QtWidgets.QMenu()
		self.menuAmpCorr.addAction("1", self.AmpCorrAction1)
		self.menuAmpCorr.addAction("2", self.AmpCorrAction2)
		self.menuAmpCorr.addAction("3", self.AmpCorrAction3)
		self.menuAmpCorr.addAction("4", self.AmpCorrAction4)
		self.buttonAmpCorr.setMenu(self.menuAmpCorr)
		self.buttonAmpCorrMode.setText("On")
		self.menuAmpCorrMode = QtWidgets.QMenu()
		self.menuAmpCorrMode.addAction("On", self.AmpCorrModeAction1)
		self.menuAmpCorrMode.addAction("Off", self.AmpCorrModeAction2)
		self.buttonAmpCorrMode.setMenu(self.menuAmpCorrMode)

	def AmpUnitsAction1(self):
		self.buttonAmpUnits.setText("Auto")

	def AmpUnitsAction2(self):
		self.buttonAmpUnits.setText("W")

	def AutoRangAction1(self):
		self.buttonAutoRang.setText("On")

	def AutoRangAction2(self):
		self.buttonAutoRang.setText("Off")

	def AmpCorrAction1(self):
		self.buttonAmpCorr.setText("1")

	def AmpCorrAction2(self):
		self.buttonAmpCorr.setText("2")

	def AmpCorrAction3(self):
		self.buttonAmpCorr.setText("3")

	def AmpCorrAction4(self):
		self.buttonAmpCorr.setText("4")

	def AmpCorrModeAction1(self):
		self.buttonAmpCorrMode.setText("On")

	def AmpCorrModeAction2(self):
		self.buttonAmpCorrMode.setText("Off")


class WavelengthSetup(QtWidgets.QDialog, Ui_wavelengthSetupWindow):
	def __init__(self, parent=None):
		super(WavelengthSetup, self).__init__(parent)
		self.setupUi(self)

		self.buttonWLUnits.setText("nm")
		self.menuWLUnits = QtWidgets.QMenu()
		self.menuWLUnits.addAction("nm", self.WLUnitsAction1)
		self.menuWLUnits.addAction("um", self.WLUnitsAction2)
		self.menuWLUnits.addAction("Anq", self.WLUnitsAction3)
		self.buttonWLUnits.setMenu(self.menuWLUnits)
		self.buttonWLRef.setText("Air")
		self.menuWLRef = QtWidgets.QMenu()
		self.menuWLRef.addAction("Air", self.WLRefAction1)
		self.menuWLRef.addAction("Vacuum", self.WLRefAction2)
		self.buttonWLRef.setMenu(self.menuWLRef)

	def WLUnitsAction1(self):
		self.buttonWLUnits.setText("nm")

	def WLUnitsAction2(self):
		self.buttonWLUnits.setText("um")

	def WLUnitsAction3(self):
		self.buttonWLUnits.setText("Anq")

	def WLRefAction1(self):
		self.buttonWLRef.setText("Air")

	def WLRefAction2(self):
		self.buttonWLRef.setText("Vacuum")

class MarkerSetup(QtWidgets.QDialog, Ui_markerSetupWindow):
	def __init__(self, parent=None):
		super(MarkerSetup, self).__init__(parent)
		self.setupUi(self)

		self.buttonNormMkrUnits.setText("nm")
		self.menuNormMkrUnits = QtWidgets.QMenu()
		self.menuNormMkrUnits.addAction("nm", self.NormMkrUnitsAction1)
		self.menuNormMkrUnits.addAction("um", self.NormMkrUnitsAction2)
		self.menuNormMkrUnits.addAction("Anq", self.NormMkrUnitsAction3)
		self.menuNormMkrUnits.addAction("GHz", self.NormMkrUnitsAction4)
		self.menuNormMkrUnits.addAction("THz", self.NormMkrUnitsAction5)
		self.buttonNormMkrUnits.setMenu(self.menuNormMkrUnits)
		self.buttonBWMkrUnits.setText("nm")
		self.menuBWMkrUnits = QtWidgets.QMenu()
		self.menuBWMkrUnits.addAction("nm", self.BWMkrUnitsAction1)
		self.menuBWMkrUnits.addAction("um", self.BWMkrUnitsAction2)
		self.menuBWMkrUnits.addAction("Anq", self.BWMkrUnitsAction3)
		self.menuBWMkrUnits.addAction("GHz", self.BWMkrUnitsAction4)
		self.menuBWMkrUnits.addAction("THz", self.BWMkrUnitsAction5)
		self.buttonBWMkrUnits.setMenu(self.menuBWMkrUnits)
		self.buttonDeltaMkrUnits.setText("nm")
		self.menuDeltaMkrUnits = QtWidgets.QMenu()
		self.menuDeltaMkrUnits.addAction("nm", self.DeltaMkrUnitsAction1)
		self.menuDeltaMkrUnits.addAction("um", self.DeltaMkrUnitsAction2)
		self.menuDeltaMkrUnits.addAction("Anq", self.DeltaMkrUnitsAction3)
		self.menuDeltaMkrUnits.addAction("GHz", self.DeltaMkrUnitsAction4)
		self.menuDeltaMkrUnits.addAction("THz", self.DeltaMkrUnitsAction5)
		self.buttonDeltaMkrUnits.setMenu(self.menuDeltaMkrUnits)
		self.buttonMkrInterp.setText("On")
		self.menuMkrInterp = QtWidgets.QMenu()
		self.menuMkrInterp.addAction("On", self.MkrInterpAction1)
		self.menuMkrInterp.addAction("Off", self.MkrInterpAction2)
		self.buttonMkrInterp.setMenu(self.menuMkrInterp)
		self.buttonBWMkrInterp.setText("On")
		self.menuBWMkrInterp = QtWidgets.QMenu()
		self.menuBWMkrInterp.addAction("On", self.BWMkrInterpAction1)
		self.menuBWMkrInterp.addAction("Off", self.BWMkrInterpAction2)
		self.buttonBWMkrInterp.setMenu(self.menuBWMkrInterp)
		self.buttonUserMkrThresh.setText("On")
		self.menuUserMkrThresh = QtWidgets.QMenu()
		self.menuUserMkrThresh.addAction("On", self.UserMkrThreshAction1)
		self.menuUserMkrThresh.addAction("Off", self.UserMkrThreshAction2)
		self.buttonUserMkrThresh.setMenu(self.menuUserMkrThresh)
		self.buttonNoiseMkrBW.setText("0.1 nm")
		self.menuNoiseMkrBW = QtWidgets.QMenu()
		self.menuNoiseMkrBW.addAction("0.1 nm", self.NoiseMkrBWAction1)
		self.menuNoiseMkrBW.addAction("1.0 nm", self.NoiseMkrBWAction2)
		self.buttonNoiseMkrBW.setMenu(self.menuNoiseMkrBW)
		self.buttonPeakSrchSweep.setText("On")
		self.menuPeakSrchSweep = QtWidgets.QMenu()
		self.menuPeakSrchSweep.addAction("On", self.PeakSrchSweepAction1)
		self.menuPeakSrchSweep.addAction("Off", self.PeakSrchSweepAction2)
		self.buttonPeakSrchSweep.setMenu(self.menuPeakSrchSweep)
		self.buttonOSNR.setText("PM")
		self.menuOSNR = QtWidgets.QMenu()
		self.menuOSNR.addAction("PM", self.OSNRAction1)
		self.menuOSNR.addAction("Auto", self.OSNRAction2)
		self.menuOSNR.addAction("Manual", self.OSNRAction3)
		self.buttonOSNR.setMenu(self.menuOSNR)

	def NormMkrUnitsAction1(self):
		self.buttonNormMkrUnits.setText("nm")

	def NormMkrUnitsAction2(self):
		self.buttonNormMkrUnits.setText("um")

	def NormMkrUnitsAction3(self):
		self.buttonNormMkrUnits.setText("Anq")

	def NormMkrUnitsAction4(self):
		self.buttonNormMkrUnits.setText("GHz")

	def NormMkrUnitsAction5(self):
		self.buttonNormMkrUnits.setText("THz")

	def BWMkrUnitsAction1(self):
		self.buttonBWMkrUnits.setText("nm")

	def BWMkrUnitsAction2(self):
		self.buttonBWMkrUnits.setText("um")

	def BWMkrUnitsAction3(self):
		self.buttonBWMkrUnits.setText("Anq")

	def BWMkrUnitsAction4(self):
		self.buttonBWMkrUnits.setText("GHz")

	def BWMkrUnitsAction5(self):
		self.buttonBWMkrUnits.setText("THz")

	def DeltaMkrUnitsAction1(self):
		self.buttonDeltaMkrUnits.setText("nm")

	def DeltaMkrUnitsAction2(self):
		self.buttonDeltaMkrUnits.setText("um")

	def DeltaMkrUnitsAction3(self):
		self.buttonDeltaMkrUnits.setText("Anq")

	def DeltaMkrUnitsAction4(self):
		self.buttonDeltaMkrUnits.setText("GHz")

	def DeltaMkrUnitsAction5(self):
		self.buttonDeltaMkrUnits.setText("THz")

	def MkrInterpAction1(self):
		self.buttonMkrInterp.setText("On")

	def MkrInterpAction2(self):
		self.buttonMkrInterp.setText("Off")

	def BWMkrInterpAction1(self):
		self.buttonBWMkrInterp.setText("On")

	def BWMkrInterpAction2(self):
		self.buttonBWMkrInterp.setText("Off")

	def UserMkrThreshAction1(self):
		self.buttonUserMkrThresh.setText("On")

	def UserMkrThreshAction2(self):
		self.buttonUserMkrThresh.setText("Off")

	def NoiseMkrBWAction1(self):
		self.buttonNoiseMkrBW.setText("0.1 nm")

	def NoiseMkrBWAction2(self):
		self.buttonNoiseMkrBW.setText("1.0 nm")

	def PeakSrchSweepAction1(self):
		self.buttonPeakSrchSweep.setText("On")

	def PeakSrchSweepAction2(self):
		self.buttonPeakSrchSweep.setText("Off")

	def OSNRAction1(self):
		self.buttonOSNR.setText("PM")

	def OSNRAction2(self):
		self.buttonOSNR.setText("Auto")

	def OSNRAction3(self):
		self.buttonOSNR.setText("Manual")


class AdvancedLineMarkerWindow(QtWidgets.QDialog, Ui_advancedLineMarkerWindow):
	def __init__(self, parent=None):
		super(AdvancedLineMarkerWindow, self).__init__(parent)
		self.setupUi(self)

		self.buttonSweepLimit.setText("On")
		self.menuSweepLimit = QtWidgets.QMenu()
		self.menuSweepLimit.addAction("On", self.SweepLimitAction1)
		self.menuSweepLimit.addAction("Off", self.SweepLimitAction2)
		self.buttonSweepLimit.setMenu(self.menuSweepLimit)
		self.buttonSrchLimit.setText("On")
		self.menuSrchLimit = QtWidgets.QMenu()
		self.menuSrchLimit.addAction("On", self.SrchLimitAction1)
		self.menuSrchLimit.addAction("Off", self.SrchLimitAction2)
		self.buttonSrchLimit.setMenu(self.menuSrchLimit)
		self.buttonIntegLimit.setText("On")
		self.menuIntegLimit = QtWidgets.QMenu()
		self.menuIntegLimit.addAction("On", self.IntegLimitAction1)
		self.menuIntegLimit.addAction("Off", self.IntegLimitAction2)
		self.buttonIntegLimit.setMenu(self.menuIntegLimit)
		self.buttonTraceInteg.setText("On")
		self.menuTraceInteg = QtWidgets.QMenu()
		self.menuTraceInteg.addAction("On", self.TraceIntegAction1)
		self.menuTraceInteg.addAction("Off", self.TraceIntegAction2)
		self.buttonTraceInteg.setMenu(self.menuTraceInteg)

	def SweepLimitAction1(self):
		self.buttonSweepLimit.setText("On")

	def SweepLimitAction2(self):
		self.buttonSweepLimit.setText("Off")

	def SrchLimitAction1(self):
		self.buttonSrchLimit.setText("On")

	def SrchLimitAction2(self):
		self.buttonSrchLimit.setText("Off")

	def IntegLimitAction1(self):
		self.buttonIntegLimit.setText("On")

	def IntegLimitAction2(self):
		self.buttonIntegLimit.setText("Off")

	def TraceIntegAction1(self):
		self.buttonTraceInteg.setText("On")

	def TraceIntegAction2(self):
		self.buttonTraceInteg.setText("Off")


class SystemWindow(QtWidgets.QDialog, Ui_systemWindow):
	def __init__(self, parent=None):
		super(SystemWindow, self).__init__(parent)
		self.setupUi(self)
		
		self.buttonSigSource.setText("External")
		self.menuSigSource = QtWidgets.QMenu()
		self.menuSigSource.addAction("External", self.SigSourceAction1)
		self.menuSigSource.addAction("Calirator", self.SigSourceAction2)
		self.buttonSigSource.setMenu(self.menuSigSource)
		self.buttonWLRef.setText("Air")
		self.menuWLRef = QtWidgets.QMenu()
		self.menuWLRef.addAction("Air", self.WLRefAction1)
		self.menuWLRef.addAction("Vacuum", self.WLRefAction2)
		self.buttonWLRef.setMenu(self.menuWLRef)

	def SigSourceAction1(self):
		self.buttonSigSource.setText("External")

	def SigSourceAction2(self):
		self.buttonSigSource.setText("Calibrator")

	def WLRefAction1(self):
		self.buttonWLRef.setText("Air")

	def WLRefAction2(self):
		self.buttonWLRef.setText("Vacuum")

# Main window
class MainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
	def __init__(self, parent=None):
		super(MainWindow, self).__init__(parent)
		self.setupUi(self)
		self.actionNew_Instrument.triggered.connect(self.instrumentSelectWindow)
		self.actionClose_Instrument.triggered.connect(self.closeTab)
		self.tabWidget.tabCloseRequested.connect(self.closeTab)
		self.tabCount = 0

	def instrumentSelectWindow(self):
		widget = InstrumentSelect(parent=self)
		widget.exec_()
		self.openInstrument(widget.selection)

	def openInstrument(self, device):
		if device == "Agilent 86142B":
			self.tab = Agilent86142B()
		if device == "HP 8157A":
			self.tab = hp8157A()
		if device == "":
			return
		self.tabCount += 1
		self.tabWidget.addTab(self.tab, "%i - %s" % (self.tabCount, device))
		self.tabWidget.setCurrentIndex(self.tabCount)

	def closeTab(self, currentIndex):
		currentQWidget = self.tabWidget.widget(currentIndex)
		currentQWidget.deleteLater()
		self.tabWidget.removeTab(currentIndex)


def main():
	app = QtWidgets.QApplication(sys.argv)
	main_window = MainWindow()
	main_window.show()
	sys.exit(app.exec_())

if __name__ == '__main__':
	main()