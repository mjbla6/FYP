# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'agilent86142b.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Agilent86142B(object):
    def setupUi(self, Agilent86142B):
        Agilent86142B.setObjectName("Agilent86142B")
        Agilent86142B.resize(800, 500)
        self.gridLayout = QtWidgets.QGridLayout(Agilent86142B)
        self.gridLayout.setObjectName("gridLayout")
        self.buttonSystem = QtWidgets.QPushButton(Agilent86142B)
        self.buttonSystem.setObjectName("buttonSystem")
        self.gridLayout.addWidget(self.buttonSystem, 3, 2, 1, 1)
        self.buttonApplications = QtWidgets.QPushButton(Agilent86142B)
        self.buttonApplications.setObjectName("buttonApplications")
        self.gridLayout.addWidget(self.buttonApplications, 3, 3, 1, 1)
        self.line = QtWidgets.QFrame(Agilent86142B)
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.gridLayout.addWidget(self.line, 2, 0, 1, 4)
        self.subButtonLayout = QtWidgets.QVBoxLayout()
        self.subButtonLayout.setObjectName("subButtonLayout")
        self.gridLayout.addLayout(self.subButtonLayout, 0, 3, 2, 1)
        self.buttonAutoAlign = QtWidgets.QPushButton(Agilent86142B)
        self.buttonAutoAlign.setObjectName("buttonAutoAlign")
        self.gridLayout.addWidget(self.buttonAutoAlign, 3, 1, 1, 1)
        self.buttonAutoMeasure = QtWidgets.QPushButton(Agilent86142B)
        self.buttonAutoMeasure.setObjectName("buttonAutoMeasure")
        self.gridLayout.addWidget(self.buttonAutoMeasure, 3, 0, 1, 1)
        self.buttonLayout = QtWidgets.QVBoxLayout()
        self.buttonLayout.setObjectName("buttonLayout")
        self.buttonWavelength = QtWidgets.QPushButton(Agilent86142B)
        self.buttonWavelength.setMinimumSize(QtCore.QSize(0, 48))
        self.buttonWavelength.setObjectName("buttonWavelength")
        self.buttonLayout.addWidget(self.buttonWavelength)
        self.buttonAmplitude = QtWidgets.QPushButton(Agilent86142B)
        self.buttonAmplitude.setMinimumSize(QtCore.QSize(0, 48))
        self.buttonAmplitude.setObjectName("buttonAmplitude")
        self.buttonLayout.addWidget(self.buttonAmplitude)
        self.buttonMarkers = QtWidgets.QPushButton(Agilent86142B)
        self.buttonMarkers.setMinimumSize(QtCore.QSize(0, 48))
        self.buttonMarkers.setObjectName("buttonMarkers")
        self.buttonLayout.addWidget(self.buttonMarkers)
        self.buttonTraces = QtWidgets.QPushButton(Agilent86142B)
        self.buttonTraces.setMinimumSize(QtCore.QSize(0, 48))
        self.buttonTraces.setObjectName("buttonTraces")
        self.buttonLayout.addWidget(self.buttonTraces)
        self.buttonBW = QtWidgets.QPushButton(Agilent86142B)
        self.buttonBW.setMinimumSize(QtCore.QSize(0, 48))
        self.buttonBW.setAutoFillBackground(False)
        self.buttonBW.setCheckable(False)
        self.buttonBW.setFlat(False)
        self.buttonBW.setObjectName("buttonBW")
        self.buttonLayout.addWidget(self.buttonBW)
        self.gridLayout.addLayout(self.buttonLayout, 0, 4, 2, 1)
        self.plot = QtWidgets.QWidget(Agilent86142B)
        self.plot.setObjectName("plot")
        self.gridLayout.addWidget(self.plot, 0, 0, 2, 3)

        self.retranslateUi(Agilent86142B)
        QtCore.QMetaObject.connectSlotsByName(Agilent86142B)

    def retranslateUi(self, Agilent86142B):
        _translate = QtCore.QCoreApplication.translate
        Agilent86142B.setWindowTitle(_translate("Agilent86142B", "Form"))
        self.buttonSystem.setText(_translate("Agilent86142B", "System"))
        self.buttonApplications.setText(_translate("Agilent86142B", "Applications"))
        self.buttonAutoAlign.setText(_translate("Agilent86142B", "Auto Align"))
        self.buttonAutoMeasure.setText(_translate("Agilent86142B", "Auto Measure"))
        self.buttonWavelength.setText(_translate("Agilent86142B", "Wavelength"))
        self.buttonAmplitude.setText(_translate("Agilent86142B", "Amplitude"))
        self.buttonMarkers.setText(_translate("Agilent86142B", "Markers"))
        self.buttonTraces.setText(_translate("Agilent86142B", "Traces"))
        self.buttonBW.setText(_translate("Agilent86142B", "Bandwidth/\n"
"Sweep"))

