# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'hp8157a.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_HP8157A(object):
    def setupUi(self, HP8157A):
        HP8157A.setObjectName("HP8157A")
        HP8157A.resize(800, 500)
        self.gridLayout_2 = QtWidgets.QGridLayout(HP8157A)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.LeftLayout = QtWidgets.QGridLayout()
        self.LeftLayout.setObjectName("LeftLayout")
        self.lcdLCL = QtWidgets.QLCDNumber(HP8157A)
        self.lcdLCL.setObjectName("lcdLCL")
        self.LeftLayout.addWidget(self.lcdLCL, 1, 0, 1, 1)
        self.spinBox = QtWidgets.QDoubleSpinBox(HP8157A)
        self.spinBox.setObjectName("spinBox")
        self.LeftLayout.addWidget(self.spinBox, 1, 6, 1, 1)
        self.labelLCL = QtWidgets.QLabel(HP8157A)
        self.labelLCL.setObjectName("labelLCL")
        self.LeftLayout.addWidget(self.labelLCL, 1, 1, 1, 1)
        self.labelCal = QtWidgets.QLabel(HP8157A)
        self.labelCal.setObjectName("labelCal")
        self.LeftLayout.addWidget(self.labelCal, 1, 5, 1, 1)
        self.labelAtt = QtWidgets.QLabel(HP8157A)
        self.labelAtt.setObjectName("labelAtt")
        self.LeftLayout.addWidget(self.labelAtt, 1, 7, 1, 1)
        self.labelUnits = QtWidgets.QLabel(HP8157A)
        self.labelUnits.setObjectName("labelUnits")
        self.LeftLayout.addWidget(self.labelUnits, 0, 7, 1, 1)
        self.lcdNumberCal = QtWidgets.QLCDNumber(HP8157A)
        self.lcdNumberCal.setObjectName("lcdNumberCal")
        self.LeftLayout.addWidget(self.lcdNumberCal, 1, 4, 1, 1)
        self.lcdWL = QtWidgets.QLCDNumber(HP8157A)
        self.lcdWL.setObjectName("lcdWL")
        self.LeftLayout.addWidget(self.lcdWL, 1, 2, 1, 1)
        self.labelWL = QtWidgets.QLabel(HP8157A)
        self.labelWL.setObjectName("labelWL")
        self.LeftLayout.addWidget(self.labelWL, 1, 3, 1, 1)
        self.lcdAtt = QtWidgets.QLCDNumber(HP8157A)
        self.lcdAtt.setSmallDecimalPoint(False)
        self.lcdAtt.setObjectName("lcdAtt")
        self.LeftLayout.addWidget(self.lcdAtt, 0, 0, 1, 7)
        self.gridLayout_2.addLayout(self.LeftLayout, 0, 0, 1, 2)
        self.buttonDisable = QtWidgets.QPushButton(HP8157A)
        self.buttonDisable.setCheckable(True)
        self.buttonDisable.setObjectName("buttonDisable")
        self.gridLayout_2.addWidget(self.buttonDisable, 1, 0, 1, 2)

        self.retranslateUi(HP8157A)
        QtCore.QMetaObject.connectSlotsByName(HP8157A)

    def retranslateUi(self, HP8157A):
        _translate = QtCore.QCoreApplication.translate
        HP8157A.setWindowTitle(_translate("HP8157A", "Form"))
        self.labelLCL.setText(_translate("HP8157A", "LCL"))
        self.labelCal.setText(_translate("HP8157A", "CAL"))
        self.labelAtt.setText(_translate("HP8157A", "ATT"))
        self.labelUnits.setText(_translate("HP8157A", "dB"))
        self.labelWL.setText(_translate("HP8157A", "WAVELENGTH"))
        self.buttonDisable.setText(_translate("HP8157A", "Disable"))

