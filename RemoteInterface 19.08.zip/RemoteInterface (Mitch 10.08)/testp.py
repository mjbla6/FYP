userInput = '10'
wavelength_units = 'nm'
wavelength = "SENSe:WAVelength:CENTer " + "%s%s" %(userInput,wavelength_units)
print(wavelength)
