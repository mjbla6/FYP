# Remote Interface FYP 2018
# Mitch Blair & Isaac Naylor
#
# Last edit: 25/07/2018
# Progress: Up to More Marker Functions sub-menu connections and calls

## TODO: need to create checks on user input to ensure that people are inputing the correct numbers
## TODO: for bandwidth auto/man functions may need to add input dialog for manual functions
## TODO: need to make things case insensitive
## TODO: need to add in manual entry boxes for bw/sweep params
## TODO: self.tabWidget.currentIndex()
## TODO: update plot when machine is being used locally
## TODO: figure out a way of showing continuos sweeps on plot
## TODO: need to figure out which functions need to run display.
##      at the moment every function is doing this but it probably
##      doesnt need to and will slow down the machine b/c sweeps
## TODO: IDEA: we could probably run a separte display function when only updating markers and such?
##      may remove the need to run extra sweeps
from PyQt5 import QtCore, QtGui, QtWidgets
import sys
from gui_mainwindow import Ui_MainWindow
from gui_instrumentselect import Ui_instrumentSelect
from gui_inputdialog import Ui_inputDialog
from gui_checkdialog import Ui_checkDialog
from gui_checkdialog2 import Ui_checkDialog2
from gui_agilent86142b import Ui_Agilent86142B
from gui_amplitudesetupwindow import Ui_amplitudeSetupWindow
from gui_wavelengthsetupwindow import Ui_wavelengthSetupWindow
from gui_activemarkerswindow import Ui_activeMarkersWindow
from gui_activetracewindow import Ui_activeTraceWindow
from gui_markersetupwindow import Ui_markerSetupWindow
from gui_advancedlinemarkerwindow import Ui_advancedLineMarkerWindow
from gui_triggermode import Ui_triggerMode
from gui_systemwindow import Ui_systemWindow
from gui_hp8157a import Ui_HP8157A
from threading import Thread, Event
import visa
import math
import numpy
import visa_manager
import conversions
import pyqtgraph as pg
import ast
import time, threading
from graphPlot import display

## VISA query to find available resources
## Determines all devices on link with associated address
rm = visa.ResourceManager()
resources =  rm.list_resources()
devices_info = visa_manager.devices()
address = visa_manager.GPIB_address()
num_devices = visa_manager.num_devices()

## Instrument select class adds in all available devices to the
## UI on start up and on click will start that machine process
class InstrumentSelect(QtWidgets.QDialog, Ui_instrumentSelect):
    def __init__(self, parent=None):
        super(InstrumentSelect, self).__init__(parent)
        self.setupUi(self)
        i = 0
        while i < num_devices:
            self.listWidget.addItem("%s" %devices_info[i])
            i += 1
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def onAccept(self):
        self.selection = self.listWidget.currentItem().text()
        return self.selection

    def onReject(self):
        self.selection = ""
        return self.selection

## Creating variables for global variables
wavelength_name = "Wave"
amplitude_name = "Amp"
wavelength_units = ''
wavelength_units_display = ''
amplitude_units = ''
time_units = ''
my_instrument = ''
active_marker = ''
active_marker_matrix = ''
active_trace = ''
active_trace_num = ''
logLin = ''
autoMan =''
traceIntOnOff = ''
peakPit = ''
upDown = ''
markerBWOnOff =''
noiseMarkOnOff = ''
deltaMarkOnOff = ''
osnrMarkOnOff = ''
updateTraceOnOff = ''
viewTraceOnOff = ''
holdTraceNoneMinMax = ''
averagingOnOff = ''
resBwManAuto = ''
vidBwManAuto = ''
sweepTimeManAuto = ''
repeatSweepOnOff = ''
trigSyncLowHighPulse = ''
syncOutOnOff = ''
wavelengthOffset = ''
wavelengthStepSize = ''
wavelengthRefIn = ''
interval = 5
flag = ''
p1 = ''
num_points = ''


##class MyThread(Thread):
##    def __init__(self, event):
##        Thread.__init__(self)
##        self.stopped = event
##
##    def run(self):
##        while not self.stopped.wait(3):
##            print("Thread is running..")
##            print(flag)
##            if flag == 1:
##                print('running')
##                display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units,amplitude_units,num_points)

## Main class for the HP8157A machine
## TODO: move this out to a separate file
class hp8157A(QtWidgets.QWidget, Ui_HP8157A):
    def __init__(self, parent=None):
        super(hp8157A, self).__init__(parent)
        self.setupUi(self)

        att = my_instrument.query("ATT?")
        self.spinBoxATT.setValue(float(att))
        cal = my_instrument.query("CAL?")
        self.spinBoxCAL.setValue(float(cal))
        self.lcdAtt.display(float(att) + float(cal))
        wvl = my_instrument.query("WVL?")
        wvl = float(wvl)
        wvl = wvl*(1000000000)
        wvl = int(wvl)
        self.spinBoxWL.setValue(wvl)
        D = my_instrument.query("D?")
        D = int(D)
        if (D == 1):
            self.buttonDisable.setChecked(True)

        self.spinBoxATT.valueChanged.connect(self.valueChange)
        self.spinBoxCAL.valueChanged.connect(self.valueChange)
        self.spinBoxWL.valueChanged.connect(self.valueChange)
        self.buttonDisable.clicked.connect(self.unitEnable)

    def valueChange(self):
        self.lcdAtt.display(self.spinBoxATT.value() + self.spinBoxCAL.value())
        my_instrument.write("ATT %f dB" % self.spinBoxATT.value()) 
        my_instrument.write("CAL %f dB" % self.spinBoxCAL.value())
        my_instrument.write("WVL %i NM" % self.spinBoxWL.value())

    def unitEnable(self):
        if self.buttonDisable.isChecked():
            my_instrument.write("D1")
        else:
            my_instrument.write("D0")

##my_event = Event()
##thread = MyThread(my_event)
##thread.start()

# Main class for the Agilent 86142B OSA
class Agilent86142B(QtWidgets.QWidget, Ui_Agilent86142B):
    def __init__(self, parent=None):
        super(Agilent86142B, self).__init__(parent)
        self.setupUi(self)
        self.setupInstrument()

        self.plot = pg.GraphicsWindow()
        self.p1 = self.plot.addPlot()
        self.p1.showGrid(x=True, y=True)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        
        # Top menu buttons clicked
        self.buttonWavelength.clicked.connect(self.wavelengthMenu)
        self.buttonAmplitude.clicked.connect(self.amplitudeMenu)
        self.buttonMarkers.clicked.connect(self.markersMenu)
        self.buttonTraces.clicked.connect(self.tracesMenu)
        self.buttonBW.clicked.connect(self.bwMenu)
        self.buttonSystem.clicked.connect(self.systemMenu)

        # Bottom menu button clicked
        self.buttonAutoMeasure.clicked.connect(self.autoMeasure)
        self.buttonAutoAlign.clicked.connect(self.autoAlign)
        self.buttonSystem.clicked.connect(self.system)
        self.buttonApplications.clicked.connect(self.appl)

    def autoMeasure(self):
        my_instrument.write("DISPlay:WINDow:TRACe:ALL:SCALe:AUTO")

    def autoAlign(self):
        my_instrument.write("CALibration:ALIGn")

    def appl(self):
        apps = my_instrument.query("INSTrument:CATalog?")
        ## TODO: need to create an interface for this menu to select
        ## the appropriate app
        chosen_app = 'whatever gets picked from the interface'
        app_select = "INSTrument:SELect %s" %chosen_app
        my_instrument.write(app_select)  

    
    ## Setup instrument is run at start up of the OSA to query the machine and
    ## determine initial values and settings
    def setupInstrument(self): 
        markerOne = str(my_instrument.query("CALCulate:MARKer1:STATe?")).rstrip()
        markerTwo = str(my_instrument.query("CALCulate:MARKer2:STATe?")).rstrip()
        markerThree = str(my_instrument.query("CALCulate:MARKer3:STATe?")).rstrip()
        markerFour = str(my_instrument.query("CALCulate:MARKer4:STATe?")).rstrip()
        markerFive = str(my_instument.query("CALCulate:MARKer5:STATe?")).rstrip()
        global active_marker
        global active_trace
        global active_marker_matrix
        active_marker_matrix = [markerOne,markerTwo,markerThree,markerFour,markerFive]
        ## need to play around with marker functions to see what happens when more than one marker is on,
        ## also when more than one trace is on, trace? may return TRA,TRB etc
        ## TODO: start up with markers off
        if markerOne == "1":
            active_marker = "1"
            value = str(my_instrument.query("CALCulate:MARKer1:TRACe?")).rstrip()
            active_trace = value
        elif markerTwo == "1":
            active_marker = "2"
            value = str(my_instrument.query("CALCulate:MARKer2:TRACe?")).rstrip()
            active_trace = value
        elif markerThree == "1":
            active_marker = "3"
            value = str(my_instrument.query("CALCulate:MARKer3:TRACe?")).rstrip()
            active_trace = value
        elif markerFour == "1":
            active_marker = "4"
            value = str(my_instrument.query("CALCulate:MARKer4:TRACe?")).rstrip()
            active_trace = value
        elif markerFive == "1":
            active_marker = "5"
            value = str(my_instrument.query("CALCulate:MARKer5:TRACe?")).rstrip()
            active_trace = value
        else:
            active_marker = "1"
            value = str(my_instrument.query("CALCulate:MARKer1:TRACe?")).rstrip()
            active_trace = value
        
        global active_trace_num
        if active_trace == "TRA":
            active_trace_num = "1"
        elif active_trace == "TRB":
            active_trace_num = "2"
        elif active_trace == "TRC":
            active_trace_num = "3"
        elif active_trace == "TRD":
            active_trace_num = "4"
        elif active_trace == "TRE":
            active_trace_num = "5"
        elif active_trace == "TRF":
            active_trace_num = "6"

        global wavelength_units
        wavelength_units = "nm" 
        
        global wavelength_units_display
        if wavelength_units == 'nm' or wavelength_units == 'um':
            wavelength_units_display = 'm'
        elif wavelength_units == 'Anq':
            wavelength_units_display = 'Anq'
        else:
            wavelength_units_display = 'm'

        global logLin
        logLin = str(my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:SPACing?")).rstrip()

        global amplitude_units
        amplitude_units = str(my_instrument.query("UNIT:POW?")).rstrip()
        if amplitude_units == 'AUTO':
            if logLin == 'LOG':
                amplitude_units = 'dB'
            elif logLin == 'LIN':
                amplitude_units = 'W'

        global time_units
        time_units = 'us'

        global autoMan
        autoMan = str(my_instrument.query("SENSe:POWer:DC:RANGe:LOWer:AUTO?")).rstrip()
        if autoMan == "1":
            autoMan = "AUTO"
        elif autoMan == "0":
            autoMan = "MAN"

        global traceIntOnOff
        traceIntOnOff = str(my_instrument.query("CALCulate:TPOWer:STATe?")).rstrip()
        if traceIntOnOff == "1":
            traceIntOnOff = "ON"
        elif traceIntOnOff == "0":
            traceIntOnOff = "OFF"

        global peakPit
        peakPit = "PEAK" ## TODO: this needs to be dynamic?

        global upDown
        upDown = "Down" ## TODO: this needs to be dynamic?

        global markerBWOnOff
        markerBWOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe?" %active_marker)).rstrip()
        if markerBWOnOff == "1":
            markerBWOnOff = "ON"
        elif markerBWOnOff == "0":
            markerBWOnOff = "OFF"

        global noiseMarkOnOff
        noiseMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:NOISe:STATe?" %active_marker)).rstrip()
        if noiseMarkOnOff == "1":
            noiseMarkOnOff = "ON"
        elif noiseMarkOnOff == "0":
            noiseMarkOnOff = "OFF"

        global deltaMarkOnOff
        deltaMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:DELTa:STATe?" %active_marker)).rstrip()
        if deltaMarkOnOff == "1":
            deltaMarkOnOff = "ON"
        elif deltaMarkOnOff == "0":
            deltaMarkOnOff = "OFF"

        global osnrMarkOnOff
        osnrMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:DELTa:STATe?" %active_marker)).rstrip()
        if osnrMarkOnOff == "1":
            osnrMarkOnOff = "ON"
        elif osnrMarkOnOff == "0":
            osnrMarkOnOff = "OFF"

        global updateTraceOnOff
        updateTraceOnOff = str(my_instrument.query("TRACe:FEED:CONTrol? %s" %active_trace)).rstrip()

        global viewTraceOnOff
        viewTraceOnOff = str(my_instrument.query("DISPlay:WINDow:TRACe:STATe? %s" %active_trace)).rstrip()
        if viewTraceOnOff == "1":
            viewTraceOnOff = "ON"
        elif viewTraceOnOff == "0":
            viewTraceOnOff = "OFF"

        global holdTraceNoneMinMax
        holdTraceMax = str(my_instrument.query("CALCulate%s:MAXimum:STATe?" %active_trace_num)).rstrip()
        holdTraceMin = str(my_instrument.query("CALCulate%s:MINimum:STATe?" %active_trace_num)).rstrip()
        if holdTraceMax == "1" and holdTraceMin == "0":
            holdTraceNoneMinMax = "MAX"
        elif holdTraceMax == "0" and holdTraceMin == "1":
            holdTraceNoneMinMax = "MIN"
        else:
            holdTraceNoneMinMax = "NONE"

        global averagingOnOff
        averagingOnOff = str(my_instrument.query("CALCulate:AVERage:STATe?")).rstrip()
        if averagingOnOff == "1":
            averagingOnOff = "ON"
        elif averagingOnOff == "0":
            averagingOnOff = "OFF"

        global resBwManAuto
        resBwManAuto = str(my_instrument.query("SENSe:BANDwidth:RESolution:AUTO?")).rstrip()
        if resBwManAuto == "1":
            resBwManAuto = "AUTO"
        elif resBwManAuto == "0":
            resBwManAuto = "MAN"

        global vidBwManAuto
        vidBwManAuto = str(my_instrument.query("SENSe:BANDwidth:VIDeo:AUTO?")).rstrip()
        if vidBwManAuto == "1":
            vidBwManAuto = "AUTO"
        elif vidBwManAuto == "0":
            vidBwManAuto = "MAN"

        global sweepTimeManAuto
        sweepTimeManAuto = str(my_instrument.query("SENSe:SWEep:TIME:AUTO?")).rstrip()
        if sweepTimeManAuto == "1":
            sweepTimeManAuto = "AUTO"
        elif sweepTimeManAuto == "0":
            sweepTimeManAuto = "MAN"

        global repeatSweepOnOff
        repeatSweepOnOff = str(my_instrument.query("INITiate:CONTinuous?")).rstrip()
        if repeatSweepOnOff == "1":
            repeatSweepOnOff = "ON"
        elif repeatSweepOnOff == "0":
            repeatSweepOnOff = "OFF"

        global trigSyncLowHighPulse
        trigSyncLowHighPulse = str(my_instrument.query("TRIGger:OUTPut?")).rstrip()
        if trigSyncLowHighPulse == "ON":
            trigSyncLowHighPulse = "HIGH"
        elif trigSyncLowHighPulse == "OFF":
            trigSyncLowHighPulse = "LOW"
        elif trigSyncLowHighPulse == "AUTO":
            trigSyncLowHighPulse = "PULSE"

        global syncOutOnOff
        syncOutOnOff = str(my_instrument.query("TRIGger:OUTPut:PULSe:STATe?")).rstrip()
        if syncOutOnOff == "1":
            syncOutOnOff = "ON"
        elif syncOutOnOff == "0":
            syncOutOnOff = "OFF"

        global wavelengthOffset
        wavelengthOffset = str(ast.literal_eval(my_instrument.query("SENSe:WAVelength:OFFSet?")))
        

        global wavelengthStepSize
        wavelengthStepSize = str(my_instrument.query("SENse:WAVelength:CENTer:STEP:INCRement?"))
        wavelengthStepSize = conversions.str2float(wavelengthStepSize, "nm")

        global wavelengthRefIn
        wavelengthRefIn = str(my_instrument.query("SENSe:CORRection:RVELocity:MEDium?")).rstrip()

        global num_points
        num_points = str(my_instrument.query("SENSe:SWEep:POINts?")).rstrip()
        
    ## Function to clear sub-menu ready to add next menu
    def clearLayout(self, layout):
        if layout != None:
            while layout.count():
                child = layout.takeAt(0)
                if child.widget() is not None:
                    child.widget().deleteLater()
                elif child.layout() is not None:
                    clearLayout(child.layout())

    ## Wavelength sub-menu
    ## The wavelength menu buttons are defined here. On click the
    ## buttons will load the associated function from below
    def wavelengthMenu(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonCenterWL = QtWidgets.QPushButton("Center WL", self)
        self.subButtonLayout.addWidget(self.buttonCenterWL)
        self.buttonSpan = QtWidgets.QPushButton("Span", self)
        self.subButtonLayout.addWidget(self.buttonSpan)
        self.buttonStartWL = QtWidgets.QPushButton("Start WL", self)
        self.subButtonLayout.addWidget(self.buttonStartWL)
        self.buttonStopWL = QtWidgets.QPushButton("Stop WL", self)
        self.subButtonLayout.addWidget(self.buttonStopWL)
        self.buttonPeakToCenter = QtWidgets.QPushButton("Peak To Center", self)
        self.subButtonLayout.addWidget(self.buttonPeakToCenter)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonWavelengthSetup = QtWidgets.QPushButton("Wavelength Setup", self)
        self.subButtonLayout.addWidget(self.buttonWavelengthSetup)

        self.buttonCenterWL.clicked.connect(self.centerWL)
        self.buttonSpan.clicked.connect(self.span)
        self.buttonStartWL.clicked.connect(self.startWL)
        self.buttonStopWL.clicked.connect(self.stopWL)
        self.buttonPeakToCenter.clicked.connect(self.peakToCenter)
        self.buttonWavelengthSetup.clicked.connect(self.wavelengthSetupWindow)

    def centerWL(self): ## works
        value = my_instrument.query("SENSe:WAVelength:CENTer?")
        current_value = str(conversions.str2float(value,"%s"%wavelength_units))
        widget = InputDialog("Center WL", "%s" %wavelength_units, current_value) 
        widget.exec_()
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:CENTer " + "%s%s" %(widget.userInput,wavelength_units)
            print(wavelength)
            my_instrument.write(wavelength)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        
    def span(self): ## works
        value = my_instrument.query("SENSe:WAVelength:SPAN?")
        current_value = str(conversions.str2float(value,"%s"%wavelength_units))
        widget = InputDialog("Span", "%s" %wavelength_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:SPAN " + "%s%s" %(widget.userInput,wavelength_units)
            my_instrument.write(wavelength)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def startWL(self): ## works
        value = my_instrument.query("SENSe:WAVelength:STARt?")
        current_value = str(conversions.str2float(value,"%s" %wavelength_units))
        widget = InputDialog("Start WL", "%s" %wavelength_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:STARt " + "%s%s" %(widget.userInput,wavelength_units)
            my_instrument.write(wavelength)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def stopWL(self): ## works
        value = my_instrument.query("SENSe:WAVelength:STOP?")
        current_value = str(conversions.str2float(value,"%s" %wavelength_units))
        widget = InputDialog("Stop WL", "%s" %wavelength_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:STOP " + "%s%s" %(widget.userInput,wavelength_units)
            my_instrument.write(wavelength)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def peakToCenter(self): ## works
        my_instrument.write("CALCulate:MARK:SCENter")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def wavelengthSetupWindow(self): ## works
        widget = WavelengthSetup(parent=self)
        widget.exec_()

    # Amplitude sub-menu
    def amplitudeMenu(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonRefLvl = QtWidgets.QPushButton("Reference Level", self)
        self.subButtonLayout.addWidget(self.buttonRefLvl)
        self.buttonScaleDiv = QtWidgets.QPushButton("Scale/Div", self)
        self.subButtonLayout.addWidget(self.buttonScaleDiv)
        logLin = str(my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:SPACing?")).rstrip()
        self.buttonDispMode = QtWidgets.QPushButton("Display Mode [%s]" %logLin, self)
        self.buttonDispMode.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonDispMode)
        self.buttonSensitivity = QtWidgets.QPushButton("Sensitivity [%s]" %autoMan, self)
        self.buttonSensitivity.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonSensitivity)
        self.buttonPeakToRefLvl = QtWidgets.QPushButton("Peak To Ref Level", self)
        self.subButtonLayout.addWidget(self.buttonPeakToRefLvl)
        self.buttonTraceInteg = QtWidgets.QPushButton("Trace Integ [%s]" %traceIntOnOff, self)
        self.buttonTraceInteg.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonTraceInteg)
        self.buttonAmplitudeSetup = QtWidgets.QPushButton("Amplitude Setup", self)
        self.subButtonLayout.addWidget(self.buttonAmplitudeSetup)

        self.buttonRefLvl.clicked.connect(self.refLVL)
        self.buttonScaleDiv.clicked.connect(self.scaleDiv)
        self.buttonDispMode.clicked.connect(self.dispMode)
        self.buttonSensitivity.clicked.connect(self.sensitivity)
        self.buttonPeakToRefLvl.clicked.connect(self.peakToRefLvl)
        self.buttonTraceInteg.clicked.connect(self.traceInteg)
        self.buttonAmplitudeSetup.clicked.connect(self.amplitudeSetupWindow)

    def refLVL(self): ## works, TODO: this may need to be input as dBm, not dB
        value = my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:RLEVel?")
        current_value = str(conversions.str2float(value,"%s" %amplitude_units))
        widget = InputDialog("Reference Level", "%s" %amplitude_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            level = "DISPlay:WINDow:TRACe:Y:SCALe:RLEVel " + "%s%s" %(widget.userInput,amplitude_units)
            my_instrument.write(level)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def scaleDiv(self): ## works
        value = my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:PDIVision?")
        current_value = str(conversions.str2float(value,"%s" %amplitude_units))
        widget = InputDialog("Scale/Div", "%s" %amplitude_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            scale = "DISPlay:WINDow:TRACe:Y:SCALe:PDIVision " + "%s%s" %(widget.userInput,amplitude_units)
            my_instrument.write(scale)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

        ## TODO: not sure why this loop is in this function
        if amplitude_units == 'AUTO':
            if logLin == 'LOG':
                amplitude_units = 'dB'
            elif logLin == 'LIN':
                amplitude_units = 'W'

    def dispMode(self): ## works
        logLin = str(my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:SPACing?")).rstrip()
        if logLin == "LOG":
            self.buttonDispMode.setText("Display Mode [LIN]")
            my_instrument.write("DISPlay:WINDow:TRACe:Y:SCALe:SPACing LIN")
            amplitude_units = str(my_instrument.query("UNIT:POW?")).rstrip()
            if amplitude_units == 'AUTO':
                amplitude_units = 'dB'
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
            logLin == "LIN"
        elif logLin == "LIN":
            self.buttonDispMode.setText("Display Mode [LOG]")
            my_instrument.write("DISPlay:WINDow:TRACe:Y:SCALe:SPACing LOG")
            amplitude_units = str(my_instrument.query("UNIT:POW?")).rstrip()
            if amplitude_units == 'AUTO':
                amplitude_units = 'W'
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
            logLin == "LOG"
            
    def sensitivity(self): ## works TODO: may need to remove display
        autoMan = str(my_instrument.query("SENSe:POWer:DC:RANGe:LOWer:AUTO?")).rstrip()
        if autoMan == "1":
            self.buttonSensitivity.setText("Sensitivity [MAN]")
            my_instrument.write("SENSe:POWer:DC:RANGe:LOWer:AUTO OFF")
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif autoMan == "0":
            self.buttonSensitivity.setText("Sensitivity [AUTO]")
            my_instrument.write("SENSe:POWer:DC:RANGe:LOWer:AUTO ON")
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def peakToRefLvl(self): ## works
        my_instrument.write("CALCulate:MARKer:SRLevel")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def traceInteg(self): ## works
        ## TODO: may need to add the trace to the calc (calc2 = calc(trb))
        traceIntOnOff = str(my_instrument.query("CALCulate:TPOWer:STATe?")).rstrip()
        if traceIntOnOff == "1":
            self.buttonTraceInteg.setText("Trace Integ [OFF]")
            my_instrument.write("CALCulate%s:TPOWer:STATe OFF" %active_trace_num) ## TODO: need to see how active_trace_num functions
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        if traceIntOnOff == "0":
            self.buttonTraceInteg.setText("Trace Integ [ON]")
            my_instrument.write("CALCulate%s:TPOWer:STATe ON" %active_trace_num)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def amplitudeSetupWindow(self):
        widget = AmplitudeSetup()
        widget.exec_()

    # Markers sub-menu
    def markersMenu(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonActMrks = QtWidgets.QPushButton("Active Markers", self)
        self.subButtonLayout.addWidget(self.buttonActMrks)
        self.buttonActTrce = QtWidgets.QPushButton("Active Trace", self)
        self.subButtonLayout.addWidget(self.buttonActTrce)
        self.buttonPeakSrch = QtWidgets.QPushButton("Peak Search", self)
        self.subButtonLayout.addWidget(self.buttonPeakSrch)
        self.buttonMkrToCen = QtWidgets.QPushButton("Marker to Center", self)
        self.subButtonLayout.addWidget(self.buttonMkrToCen)
        self.buttonMkrToRefLvl = QtWidgets.QPushButton("Marker To Ref Level", self)
        self.subButtonLayout.addWidget(self.buttonMkrToRefLvl)
        self.buttonMkrSetup = QtWidgets.QPushButton("Marker Setup", self)
        self.subButtonLayout.addWidget(self.buttonMkrSetup)
        self.buttonMoreMkrFunc = QtWidgets.QPushButton("More Marker Functons", self)
        self.subButtonLayout.addWidget(self.buttonMoreMkrFunc)

        self.buttonActMrks.clicked.connect(self.actMrks)
        self.buttonActTrce.clicked.connect(self.actTrce)
        self.buttonMkrSetup.clicked.connect(self.mkrSetup)
        self.buttonPeakSrch.clicked.connect(self.peakSrch)
        self.buttonMkrToCen.clicked.connect(self.mrkToCen)
        self.buttonMkrToRefLvl.clicked.connect(self.mkrToRefLvl)
        self.buttonMoreMkrFunc.clicked.connect(self.moreMkrFunc)

    def actMrks(self):
        ## TODO: check how active markers window work
        widget = ActiveMarkersWindow("Active Markers")
        widget.exec_()

    def actTrce(self):
        widget = ActiveTraceWindow("Active Trace")
        widget.exec_()

    def peakSrch(self):  ## works
        my_instrument.write("CALCulate:MARKer%s:MAXimum" %active_marker)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def mrkToCen(self): ## works
        my_instrument.write("CALCulate:MARKer%s:SCENter" %active_marker)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def mkrToRefLvl(self): ## works
        my_instrument.write("CALCulate:MARKer%s:SRLevel" %active_marker)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def mkrSetup(self):
        widget = MarkerSetup()
        widget.exec_()

    def moreMkrFunc(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonMkrSrchMenu = QtWidgets.QPushButton("Marker Search Menu", self)
        self.subButtonLayout.addWidget(self.buttonMkrSrchMenu)
        self.buttonMkrBW = QtWidgets.QPushButton("Marker Bandwidth [%s]" %markerBWOnOff, self)
        self.buttonMkrBW.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonMkrBW)
        self.buttonNoiseMkr = QtWidgets.QPushButton("Noise Marker [%s]" %noiseMarkOnOff, self)
        self.buttonNoiseMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonNoiseMkr)
        self.buttonDeltaMkr = QtWidgets.QPushButton("Delta Marker [%s]" %deltaMarkOnOff, self)
        self.buttonDeltaMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonDeltaMkr)
        self.buttonOSNRMkr = QtWidgets.QPushButton("OSNR Marker [%s]" %osnrMarkOnOff, self)
        self.buttonOSNRMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonOSNRMkr)
        self.buttonLineMkrMenu = QtWidgets.QPushButton("Line Marker Menu", self)
        self.subButtonLayout.addWidget(self.buttonLineMkrMenu)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonMkrSrchMenu.clicked.connect(self.mkrSrchMenu)
        self.buttonMkrBW.clicked.connect(self.mkrBWOnOff)
        self.buttonNoiseMkr.clicked.connect(self.noiseMkr)
        self.buttonDeltaMkr.clicked.connect(self.deltaMkr)
        self.buttonOSNRMkr.clicked.connect(self.OSNRMkr)
        self.buttonLineMkrMenu.clicked.connect(self.lineMkrMenu)
        self.buttonPrevMenu.clicked.connect(self.markersMenu)

    def mkrSrchMenu(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonSrchMode = QtWidgets.QPushButton("Search Mode [%s]" %peakPit, self)
        self.buttonSrchMode.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonSrchMode)
        self.buttonPeakSrch = QtWidgets.QPushButton("%s Search" %peakPit, self)
        self.subButtonLayout.addWidget(self.buttonPeakSrch)
        self.buttonNextPeakDown = QtWidgets.QPushButton("Next %s %s" %(peakPit,upDown), self)
        self.subButtonLayout.addWidget(self.buttonNextPeakDown)
        self.buttonNextPeakLeft = QtWidgets.QPushButton("Next %s Left" %peakPit, self)
        self.subButtonLayout.addWidget(self.buttonNextPeakLeft)
        self.buttonNextPeakRight = QtWidgets.QPushButton("Next %s Right" %peakPit, self)
        self.subButtonLayout.addWidget(self.buttonNextPeakRight)
        self.buttonActMrks = QtWidgets.QPushButton("Active Markers", self)
        self.subButtonLayout.addWidget(self.buttonActMrks)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonSrchMode.clicked.connect(self.srchMode)
        self.buttonPeakSrch.clicked.connect(self.peakSrch)
        self.buttonNextPeakDown.clicked.connect(self.nextDown)
        self.buttonNextPeakLeft.clicked.connect(self.nextLeft)
        self.buttonNextPeakRight.clicked.connect(self.nextRight)
        self.buttonActMrks.clicked.connect(self.actMrks)
        self.buttonPrevMenu.clicked.connect(self.moreMkrFunc)

    def srchMode(self): ## works
        global peakPit
        global upDown
        if peakPit == "PEAK":
            upDown = "Up"
            self.buttonSrchMode.setText("Search Mode [PIT]")
            self.buttonPeakSrch.setText("Pit Search")
            self.buttonNextPeakDown.setText("Next Pit Up")
            self.buttonNextPeakLeft.setText("Next Pit Left")
            self.buttonNextPeakRight.setText("Next Pit Right")
            peakPit = "PIT"
        elif peakPit == "PIT":
            upDown = "Down"
            self.buttonSrchMode.setText("Search Mode [PEAK]")
            self.buttonPeakSrch.setText("Peak Search")
            self.buttonNextPeakDown.setText("Next Peak Down")
            self.buttonNextPeakLeft.setText("Next Peak Left")
            self.buttonNextPeakRight.setText("Next Peak Right")
            peakPit = "PEAK"

    def peakSrch(self): ## works
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def nextDown(self): ## works
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX:NEXT" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN:NEXT" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
            
    def nextLeft(self): ## works
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX:LEFT" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN:LEFT" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def nextRight(self): ## works
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX:RIGH" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN:RIGH" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        
    def mkrBWOnOff(self): ## works
        markerBWOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe?" %active_marker)).rstrip()
        if markerBWOnOff == "1":
            self.buttonMkrBW.setText("Noise Marker [OFF]")
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe OFF" %active_marker)
            markerBWOnOff = "OFF"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif markerBWOnOff == "0":
            self.buttonMkrBW.setText("Noise Marker [ON]")
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe ON" %active_marker)
            current_value = ''
            widget = InputDialog("Marker BW", "dB", current_value)
            widget.exec_()
            if widget.userInput != 0:
                bw = "CALC:MARK%s:FUNC:BAND:NDB " %active_marker + "%sdB" %widget.userInput
                markerBWOnOff = "ON"
                my_instrument.write(bw)
                display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
                
    def noiseMkr(self): ## works
        noiseMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:NOISe:STATe?" %active_marker)).rstrip()
        if noiseMarkOnOff == "1":
            self.buttonNoiseMkr.setText("Noise Marker [OFF]")
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:NOISe:STATe OFF" %active_marker)
            noiseMarkOnOff = "OFF"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif noiseMarkOnOff == "0":
            self.buttonNoiseMkr.setText("Noise Marker [ON]")
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:NOISe:STATe ON" %active_marker)
            noiseMarkOnOff = "ON"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def deltaMkr(self): ## works
        deltaMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:DELTa:STATe?" %active_marker)).rstrip()
        if deltaMarkOnOff == "1":
            self.buttonDeltaMkr.setText("Delta Marker [OFF]")
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:DELTa:STATe OFF" %active_marker)
            deltaMarkOnOff = "OFF"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif deltaMarkOnOff == "0":
            self.buttonDeltaMkr.setText("Delta Marker [ON]")
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:DELTa:STATe ON" %active_marker)
            deltaMarkOnOff = "ON"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def OSNRMkr(self): ## works
        osnrMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:OSNR:STATe?" %active_marker)).rstrip()
        if osnrMarkOnOff == "1":
            self.buttonOSNRMkr.setText("OSNR Marker [OFF]")
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:OSNR:STATe OFF" %active_marker)
            osnrMarkOnOff = "OFF"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif osnrMarkOnOff == "0":
            self.buttonOSNRMkr.setText("OSNR Marker [ON]")
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:OSNR:STATe ON" %active_marker)
            osnrMarkOnOff = "ON"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    ## TODO: need to complete line marker menu
    def lineMkrMenu(self):
        self.clearLayout(self.subButtonLayout)

        self.buttonWLLineMkr1 = QtWidgets.QPushButton("Wavelength Line Mkr 1", self)
        self.subButtonLayout.addWidget(self.buttonWLLineMkr1)
        self.buttonWLLineMkr2 = QtWidgets.QPushButton("Wavelength Line Mkr 2", self)
        self.subButtonLayout.addWidget(self.buttonWLLineMkr2)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonLineMkrsOff = QtWidgets.QPushButton("Line Markers Off", self)
        self.subButtonLayout.addWidget(self.buttonLineMkrsOff)
        self.buttonAdvLineMkrFunc = QtWidgets.QPushButton("Advanved Line Marker Functions", self)
        self.subButtonLayout.addWidget(self.buttonAdvLineMkrFunc)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonAdvLineMkrFunc.clicked.connect(self.advLineMkrFunc)
        self.buttonPrevMenu.clicked.connect(self.moreMkrFunc)

    def advLineMkrFunc(self):
        widget = AdvancedLineMarkerWindow()
        widget.exec_()

    # Trace sub-menu
    def tracesMenu(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonActTrce = QtWidgets.QPushButton("Active Trace", self)
        self.subButtonLayout.addWidget(self.buttonActTrce)
        self.buttonUpdtTrce = QtWidgets.QPushButton("Update Trace [%s]" %updateTraceOnOff, self)
        self.buttonUpdtTrce.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonUpdtTrce)
        self.buttonViewTrce = QtWidgets.QPushButton("View Trace [%s]" %viewTraceOnOff, self)
        self.buttonViewTrce.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonViewTrce)
        self.buttonHoldTrce = QtWidgets.QPushButton("Hold Trace [%s]" %holdTraceNoneMinMax, self)
        self.menuHoldTrce = QtWidgets.QMenu()
        self.menuHoldTrce.addAction("None", self.HoldTrceAction1)
        self.menuHoldTrce.addAction("Min", self.HoldTrceAction2)
        self.menuHoldTrce.addAction("Max", self.HoldTrceAction3)
        self.buttonHoldTrce.setMenu(self.menuHoldTrce)
        self.subButtonLayout.addWidget(self.buttonHoldTrce)
        self.buttonTrceMath = QtWidgets.QPushButton("Trace Math", self)
        self.subButtonLayout.addWidget(self.buttonTrceMath)
        self.buttonAveraging = QtWidgets.QPushButton("Averaging [%s]" %averagingOnOff, self)
        self.buttonAveraging.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonAveraging)
        self.buttonTrceSetup = QtWidgets.QPushButton("Trace Setup", self)
        self.subButtonLayout.addWidget(self.buttonTrceSetup)

        self.buttonActTrce.clicked.connect(self.actTrce)
        self.buttonUpdtTrce.clicked.connect(self.updtTrce)
        self.buttonViewTrce.clicked.connect(self.viewTrce)
        self.buttonTrceMath.clicked.connect(self.trceMath)
        self.buttonAveraging.clicked.connect(self.averaging)
        self.buttonTrceSetup.clicked.connect(self.trceSetup)

    def HoldTrceAction1(self): ## works
        self.buttonHoldTrce.setText("Hold Trace [NONE]")
        my_instrument.write("CALCulate%s:MAXimum:STATe OFF" %active_trace_num)
        my_instrument.write("CALCulate%s:MINimum:STATe OFF" %active_trace_num)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def HoldTrceAction2(self): ## works
        self.buttonHoldTrce.setText("Hold Trace [MIN]")
        my_instrument.write("CALCulate%s:MINimum:STATe ON" %active_trace_num)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def HoldTrceAction3(self): ## works
        self.buttonHoldTrce.setText("Hold Trace [MAX]")
        my_instrument.write("CALCulate%s:MAXimum:STATe ON" %active_trace_num)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def updtTrce(self): ## works
        updateTraceOnOff = str(my_instrument.query("TRACe:FEED:CONTrol? %s" %active_trace)).rstrip()
        if updateTraceOnOff == "ALW":
            self.buttonUpdtTrce.setText("Update Trace [NEV]")
            my_instrument.write("TRACe:FEED:CONTrol %s,NEV" %active_trace)
            updateTraceOnOff == "NEV"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif updateTraceOnOff == "NEV":
            self.buttonUpdtTrce.setText("Update Trace [ALW]")
            my_instrument.write("TRACe:FEED:CONTrol %s,ALW" %active_trace)
            updateTraceOnOff == "ALW"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def viewTrce(self): ## works but need to clear the display in this command somewhere
        viewTraceOnOff = str(my_instrument.query("DISPlay:WINDow:TRACe:STATe? %s" %active_trace)).rstrip()
        print(viewTraceOnOff)
        if viewTraceOnOff == "1":
            self.buttonViewTrce.setText("View Trace [OFF]")
            my_instrument.write("DISPlay:WINDow:TRACe:STATe %s,OFF" %active_trace)
            viewTraceOnOff = "OFF"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif viewTraceOnOff == "0":
            self.buttonViewTrce.setText("View Trace [ON]")
            my_instrument.write("DISPlay:WINDow:TRACe:STATe %s,ON" %active_trace)
            viewTraceOnOff = "ON"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    ## TODO: need to do trace math
    def trceMath(self):
        self.clearLayout(self.subButtonLayout)

        self.buttonDefMathTrcC = QtWidgets.QPushButton("Default Math Trace C", self)
        self.subButtonLayout.addWidget(self.buttonDefMathTrcC)
        self.buttonDefMathTrcF = QtWidgets.QPushButton("Default Math Trace F", self)
        self.subButtonLayout.addWidget(self.buttonDefMathTrcF)
        self.buttonExchMenu = QtWidgets.QPushButton("Exchange Menu", self)
        self.subButtonLayout.addWidget(self.buttonExchMenu)
        self.buttonTrceOffset = QtWidgets.QPushButton("Trace Offset", self)
        self.subButtonLayout.addWidget(self.buttonTrceOffset)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonAllMathOff = QtWidgets.QPushButton("All Math Off", self)
        self.subButtonLayout.addWidget(self.buttonAllMathOff)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonPrevMenu.clicked.connect(self.tracesMenu)

    def averaging(self): ##works
        averagingOnOff = str(my_instrument.query("CALCulate:AVERage:STATe?")).rstrip()
        if averagingOnOff == "1":
            self.buttonAveraging.setText("Averaging [OFF]")
            my_instrument.write("CALCulate:AVERage:STATe OFF")
            averagingOnOff = "OFF"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif averagingOnOff == "0":
            self.buttonAveraging.setText("Averaging [ON]")
            my_instrument.write("CALCulate:AVERage:STATe ON")
            averagingOnOff = "ON"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def trceSetup(self): ## works
        num_points = str(my_instrument.query("SENSe:SWEep:POINts?")).rstrip()
        widget = InputDialog("Trace Setup", "Sweep Points", num_points)
        widget.exec_()
        if widget.userInput != 0:
            num_points = "SENSe:SWEep:POINts " + "%s" %widget.userInput
            my_instrument.write(num_points)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    # Bandwidth/Sweep sub-menu
    def bwMenu(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonResBW = QtWidgets.QPushButton("Res BW [%s]" %resBwManAuto, self)
        self.buttonResBW.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonResBW)
        self.buttonVidBW = QtWidgets.QPushButton("Video BW [%s]" %vidBwManAuto, self)
        self.buttonVidBW.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonVidBW)
        self.buttonSweepTime = QtWidgets.QPushButton("Sweep Time [%s]" %sweepTimeManAuto, self)
        self.buttonSweepTime.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonSweepTime)
        self.buttonRptSweep = QtWidgets.QPushButton("Repeat Sweep [%s]" %repeatSweepOnOff, self)
        self.buttonRptSweep.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonRptSweep)
        self.buttonSnglSweep = QtWidgets.QPushButton("Single Sweep", self)
        self.subButtonLayout.addWidget(self.buttonSnglSweep)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonMoreBWFunc = QtWidgets.QPushButton("More BW/Sweep Functions", self)
        self.subButtonLayout.addWidget(self.buttonMoreBWFunc)

        self.buttonResBW.clicked.connect(self.resBW)
        self.buttonVidBW.clicked.connect(self.vidBW)
        self.buttonSweepTime.clicked.connect(self.sweepTime)
        self.buttonRptSweep.clicked.connect(self.rptSweep)
        self.buttonSnglSweep.clicked.connect(self.snglSweep)
        self.buttonMoreBWFunc.clicked.connect(self.moreBWFunc)

    def resBW(self): ## TODO: man to auto works, but need to add in a dialog box for manual entry
        resBwManAuto = str(my_instrument.query("SENSe:BANDwidth:RESolution:AUTO?")).rstrip()
        if resBwManAuto == "1":
            self.buttonResBW.setText("Res BW [MAN]")
            my_instrument.write("SENSe:BANDwidth:RESolution:AUTO 0")
            resBwManAuto = "0"
            #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif resBwManAuto == "0":
            self.buttonResBW.setText("Res BW [AUTO]")
            my_instrument.write("SENSe:BANDwidth:RESolution:AUTO 1")
            resBwManAuto = "1"
            #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def vidBW(self): ## TODO: man to auto works, but need to add in a dialog box for manual entry
        vidBwManAuto = str(my_instrument.query("SENSe:BANDwidth:VIDeo:AUTO?")).rstrip()
        if vidBwManAuto == "1":
            self.buttonVidBW.setText("Video BW [MAN]")
            my_instrument.write("SENSe:BANDwidth:VIDeo:AUTO 0")
            vidBwManAuto = "0"
            #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif vidBwManAuto == "0":
            self.buttonVidBW.setText("Video BW [Auto]")
            my_instrument.write("SENSe:BANDwidth:VIDeo:AUTO 1")
            vidBwManAuto = "1"
            #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def sweepTime(self): ## TODO: man to auto works, but need to add in a dialog box for manual entry
        sweepTimeManAuto = str(my_instrument.query("SENSe:SWEep:TIME:AUTO?")).rstrip()
        if sweepTimeManAuto == "1":
            self.buttonSweepTime.setText("Sweep Time [MAN]")
            my_instrument.write("SENSe:SWEep:TIME:AUTO 0")
            sweepTimeManAuto = "0"
            #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif sweepTimeManAuto == "0":
            self.buttonSweepTime.setText("Sweep Time [AUTO]")
            my_instrument.write("SENSe:SWEep:TIME:AUTO 1")
            sweepTimeManAuto = "1"
            #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def rptSweep(self):
        repeatSweepOnOff = str(my_instrument.query("INITiate:CONTinuous?")).rstrip()
        if repeatSweepOnOff == "1":
            self.buttonRptSweep.setText("Repeat Sweep [OFF]")
            my_instrument.write("INITiate:CONTinuous 0")
            repeatSweepOnOff = "0"
            #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif repeatSweepOnOff == "0":
            self.buttonRptSweep.setText("Repeat Sweep [ON]")
            my_instrument.write("INITiate:CONTinuous 1")
            repeatSweepOnOff = "1"
            ## this is where we will need to constantly update the display if we are taking continuos sweeps
            #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def snglSweep(self):
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def moreBWFunc(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonTrigMode = QtWidgets.QPushButton("Trigger Mode", self)
        self.subButtonLayout.addWidget(self.buttonTrigMode)
        self.buttonTrigDelay = QtWidgets.QPushButton("Trigger Delay", self)
        self.subButtonLayout.addWidget(self.buttonTrigDelay)
        self.buttonADCTrigSync = QtWidgets.QPushButton("ADC Trig Sync [%s]" %trigSyncLowHighPulse, self)
        self.menuADCTrig = QtWidgets.QMenu()
        self.menuADCTrig.addAction("Low", self.ADCTrigAction1)
        self.menuADCTrig.addAction("High", self.ADCTrigAction2)
        self.menuADCTrig.addAction("Pulse", self.ADCTrigAction3)
        self.buttonADCTrigSync.setMenu(self.menuADCTrig)
        self.subButtonLayout.addWidget(self.buttonADCTrigSync)
        self.buttonADCSyncOut = QtWidgets.QPushButton("ADC Sync Out [%s]" %syncOutOnOff, self)
        self.buttonADCSyncOut.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonADCSyncOut)
        self.buttonADCSyncOutDuty = QtWidgets.QPushButton("ADC Sync Out Duty Cycle", self)
        self.subButtonLayout.addWidget(self.buttonADCSyncOutDuty)
        self.buttonADCSyncOutPulse = QtWidgets.QPushButton("ADC Sync Out Pulse Width", self)
        self.subButtonLayout.addWidget(self.buttonADCSyncOutPulse)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonTrigMode.clicked.connect(self.trigMode)
        self.buttonTrigDelay.clicked.connect(self.trigDelay)
        self.buttonADCSyncOut.clicked.connect(self.ADCSyncOut)
        self.buttonADCSyncOutDuty.clicked.connect(self.ADCSyncOutDuty)
        self.buttonADCSyncOutPulse.clicked.connect(self.ADCSyncOutPulse)
        self.buttonPrevMenu.clicked.connect(self.bwMenu)

    def trigMode(self):
        widget = TriggerModeWindow()
        widget.exec_()

    def trigDelay(self): ## works
        value = my_instrument.query("TRIGger:DELay?")
        current_value = str(conversions.str2float(value,"%s" %time_units)) 
        widget = InputDialog("Trigger Delay", "%s" %time_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            delay = "TRIGger:DELay " + "%s%s" %(widget.userInput,time_units)
            print(delay)
            my_instrument.write(delay)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def ADCTrigAction1(self): ## works, TODO: may need to remove display
        self.buttonADCTrigSync.setText("ADC Trig Sync [LOW]")
        my_instrument.write("TRIGger:OUTPut OFF")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def ADCTrigAction2(self): ## works, TODO: may need to remove display
        self.buttonADCTrigSync.setText("ADC Trig Sync [HIGH]")
        my_instrument.write("TRIGger:OUTPut ON")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def ADCTrigAction3(self): ## works, TODO: may need to remove display
        self.buttonADCTrigSync.setText("ADC Trig Sync [PULSE]")
        my_instrument.write("TRIGger:OUTPut AUTO")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def ADCSyncOut(self): ## works, TODO: may need to remove display
        syncOutOnOff = str(my_instrument.query("TRIGger:OUTPut:PULSe:STATe?")).rstrip()
        if syncOutOnOff == "0":
            self.buttonADCSyncOut.setText("ADC Sync Out [ON]")
            my_instrument.write("TRIGger:OUTPut:PULSe:STATe 1")
            syncOutOnOff = "1"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)
        elif syncOutOnOff == "1":
            self.buttonADCSyncOut.setText("ADC Sync Out [OFF]")
            my_instrument.write("TRIGger:OUTPut:PULSe:STATe 0")
            syncOutOnOff = "0"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def ADCSyncOutDuty(self): ## works, TODO: may need to remove display
        value = my_instrument.query("TRIGger:OUTPut:PULSe:DCYCle?")
        current_value = str(conversions.str2float(value,"%")) ##TODO: need to add us to str2float
        widget = InputDialog("ADC Sync Out Duty Cycle", "%", current_value)
        widget.exec_()
        if widget.userInput != 0:
            duty_cycle = "TRIGger:OUTPut:PULSe:DCYCle " + "%s" %widget.userInput
            my_instrument.write(duty_cycle)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def ADCSyncOutPulse(self): ## works, TODO: may need to remove display
        value = my_instrument.query("TRIGger:OUTPut:PULSe:WIDTh?")
        current_value = str(conversions.str2float(value,"%s" %time_units))
        widget = InputDialog("ADC Sync Out Pulse Width", "%s" %time_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            pulse_width = "TRIGger:OUTPut:PULSe:WIDTh " + "%s%s" %(widget.userInput,time_units)
            my_instrument.write(pulse_width)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    def systemMenu(self):
        widget = SystemWindow()
        widget.exec_()

## The input dialog class is used throught the agilent class to allow the
## user to input values into menu options
class InputDialog(QtWidgets.QDialog, Ui_inputDialog):
    def __init__(self, title, unit, value, parent=None):
        super(InputDialog, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle(title)
        self.label.setText(unit)
        self.lineEdit.setText(value)
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)
        global flag
        flag = 0

    def onAccept(self):
        self.userInput = self.lineEdit.text()
        global flag
        flag = 1
        return self.userInput
        

    def onReject(self):
        self.userInput = 0
        global flag
        flag = 1
        return self.userInput
    

class ActiveMarkersWindow(QtWidgets.QDialog, Ui_activeMarkersWindow): ## TODO: need to test this and find a way to implement marker_num
    def __init__(self, title, parent=None):
        super(ActiveMarkersWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle(title)
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)
        if my_instrument.query("CALCulate:MARKer1:STATe?") == 1:
            self.checkMkr1.setChecked(True)
        if my_instrument.query("CALCulate:MARKer2:STATe?") == 1:
            self.checkMkr2.setChecked(True)
        if my_instrument.query("CALCulate:MARKer3:STATe?") == 1:
            self.checkMkr3.setChecked(True)
        if my_instrument.query("CALCulate:MARKer4:STATe?") == 1:
            self.checkMkr4.setChecked(True)
        if my_instrument.query("CALCulate:MARKer5:STATe?") == 1:
            self.checkMkr5.setChecked(True)

    def onAccept(self):
        if self.checkMkr1.isChecked() == True:
            my_instrument.write("CALCulate:MARKer1:STATe ON")
        if self.checkMkr1.isChecked() == False:
            my_instrument.write("CALCulate:MARKer1:STATe OFF")
        if self.checkMkr2.isChecked() == True:
            my_instrument.write("CALCulate:MARKer2:STATe ON")
        if self.checkMkr2.isChecked() == False:
            my_instrument.write("CALCulate:MARKer2:STATe OFF")
        if self.checkMkr3.isChecked() == True:
            my_instrument.write("CALCulate:MARKer3:STATe ON")
        if self.checkMkr3.isChecked() == False:
            my_instrument.write("CALCulate:MARKer3:STATe OFF")
        if self.checkMkr4.isChecked() == True:
            my_instrument.write("CALCulate:MARKer4:STATe ON")
        if self.checkMkr4.isChecked() == False:
            my_instrument.write("CALCulate:MARKer4:STATe OFF")
        if self.checkMkr5.isChecked() == True:
            my_instrument.write("CALCulate:MARKer5:STATe ON")
        if self.checkMkr5.isChecked() == False:
            my_instrument.write("CALCulate:MARKer5:STATe OFF")
        if self.checkAllOff.isChecked() == True:
            my_instrument.write("CALCulate:MARKer:AOFF")
                    
        self.userInput = 1
        return self.userInput

    def onReject(self):
        self.userInput = 0
        return self.userInput


class ActiveTraceWindow(QtWidgets.QDialog, Ui_activeTraceWindow):
    def __init__(self, title, parent=None):
        super(ActiveTraceWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle(title)
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

        traceQuery = "CALCulate:MARKer%s:TRACe?" %marker_num
        if my_instrument.query(traceQuery) == 'TRA':
            self.checkBox_1.setChecked(True)
        if my_instrument.query(traceQuery) == 'TRB':
            self.checkBox_2.setChecked(True)
        if my_instrument.query(traceQuery) == 'TRC':
            self.checkBox_3.setChecked(True)
        if my_instrument.query(traceQuery) == 'TRD':
            self.checkBox_4.setChecked(True)
        if my_instrument.query(traceQuery) == 'TRE':
            self.checkBox_5.setChecked(True)
        if my_instrument.query(traceQuery) == 'TRF':
            self.checkBox_6.setChecked(True)

    def onAccept(self):
        if self.checkBox_1.isChecked() == True:
            my_instrument.write("CALCulate:MARKer1:STATe ON")
        if self.checkBox_1.isChecked() == False:
            my_instrument.write("CALCulate:MARKer1:STATe OFF")
        if self.checkBox_2.isChecked() == True:
            my_instrument.write("CALCulate:MARKer2:STATe ON")
        if self.checkBox_2.isChecked() == False:
            my_instrument.write("CALCulate:MARKer2:STATe OFF")
        if self.checkBox_3.isChecked() == True:
            my_instrument.write("CALCulate:MARKer3:STATe ON")
        if self.checkBox_3.isChecked() == False:
            my_instrument.write("CALCulate:MARKer3:STATe OFF")
        if self.checkBox_4.isChecked() == True:
            my_instrument.write("CALCulate:MARKer4:STATe ON")
        if self.checkBox_4.isChecked() == False:
            my_instrument.write("CALCulate:MARKer4:STATe OFF")
        if self.checkBox_5.isChecked() == True:
            my_instrument.write("CALCulate:MARKer5:STATe ON")
        if self.checkBox_5.isChecked() == False:
            my_instrument.write("CALCulate:MARKer5:STATe OFF")
        if self.checkBox_6.isChecked() == True:
            my_instrument.write("CALCulate:MARKer:AOFF")
        if self.checkBox_6.isChecked() == False:
            my_instrument.write("CALCulate:MARKer5:STATe OFF")
                    
        self.userInput = 1
        return self.userInput

    def onReject(self):
        self.userInput = 0
        eturn self.userInput


class AmplitudeSetup(QtWidgets.QDialog, Ui_amplitudeSetupWindow):
    def __init__(self, parent=None):
        super(AmplitudeSetup, self).__init__(parent)
        self.setupUi(self)

        self.buttonAmpUnits.setText("Auto")
        self.menuAmpUnits = QtWidgets.QMenu()
        self.menuAmpUnits.addAction("Auto", self.AmpUnitsAction1)
        self.menuAmpUnits.addAction("W", self.AmpUnitsAction2)
        self.buttonAmpUnits.setMenu(self.menuAmpUnits)
        self.buttonAutoRang.setText("On")
        self.menuAutoRang = QtWidgets.QMenu()
        self.menuAutoRang.addAction("On", self.AutoRangAction1)
        self.menuAutoRang.addAction("Off", self.AutoRangAction2)
        self.buttonAutoRang.setMenu(self.menuAutoRang)
        self.buttonAmpCorr.setText("1")
        self.menuAmpCorr = QtWidgets.QMenu()
        self.menuAmpCorr.addAction("1", self.AmpCorrAction1)
        self.menuAmpCorr.addAction("2", self.AmpCorrAction2)
        self.menuAmpCorr.addAction("3", self.AmpCorrAction3)
        self.menuAmpCorr.addAction("4", self.AmpCorrAction4)
        self.buttonAmpCorr.setMenu(self.menuAmpCorr)
        self.buttonAmpCorrMode.setText("On")
        self.menuAmpCorrMode = QtWidgets.QMenu()
        self.menuAmpCorrMode.addAction("On", self.AmpCorrModeAction1)
        self.menuAmpCorrMode.addAction("Off", self.AmpCorrModeAction2)
        self.buttonAmpCorrMode.setMenu(self.menuAmpCorrMode)

    def AmpUnitsAction1(self):
        self.buttonAmpUnits.setText("Auto")

    def AmpUnitsAction2(self):
        self.buttonAmpUnits.setText("W")

    def AutoRangAction1(self):
        self.buttonAutoRang.setText("On")

    def AutoRangAction2(self):
        self.buttonAutoRang.setText("Off")

    def AmpCorrAction1(self):
        self.buttonAmpCorr.setText("1")

    def AmpCorrAction2(self):
        self.buttonAmpCorr.setText("2")

    def AmpCorrAction3(self):
        self.buttonAmpCorr.setText("3")

    def AmpCorrAction4(self):
        self.buttonAmpCorr.setText("4")

    def AmpCorrModeAction1(self):
        self.buttonAmpCorrMode.setText("On")

    def AmpCorrModeAction2(self):
        self.buttonAmpCorrMode.setText("Off")


class WavelengthSetup(QtWidgets.QDialog, Ui_wavelengthSetupWindow):
    def __init__(self, parent=None):
        super(WavelengthSetup, self).__init__(parent)
        self.setupUi(self)
        wavelengthOffset = str(ast.literal_eval(my_instrument.query("SENSe:WAVelength:OFFSet?")))
        wavelengthStepSize = str(my_instrument.query("SENse:WAVelength:CENTer:STEP:INCRement?"))
        self.buttonWLUnits.setText("%s" %wavelength_units)
        self.menuWLUnits = QtWidgets.QMenu()
        self.menuWLUnits.addAction("nm", self.WLUnitsAction1)
        self.menuWLUnits.addAction("um", self.WLUnitsAction2)
        self.menuWLUnits.addAction("Anq", self.WLUnitsAction3)
        self.buttonWLUnits.setMenu(self.menuWLUnits)
        self.lineWLOffset.setText("%s" %wavelengthOffset)
        self.lineWLStep.setText("%s" %wavelengthStepSize)
        self.buttonWLRef.setText("%s" %wavelengthRefIn)
        self.menuWLRef = QtWidgets.QMenu()
        self.menuWLRef.addAction("AIR", self.WLRefAction1)
        self.menuWLRef.addAction("VAC", self.WLRefAction2)
        self.buttonWLRef.setMenu(self.menuWLRef)
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def WLUnitsAction1(self):
        self.buttonWLUnits.setText("nm")
        global wavelength_units
        wavelength_units = "nm"
        wavelength_units_display = 'm'

    def WLUnitsAction2(self):
        self.buttonWLUnits.setText("um")
        global wavelength_units
        wavelength_units = "um"
        wavelength_units_display = 'm'

    def WLUnitsAction3(self):
        self.buttonWLUnits.setText("Anq")
        global wavelength_units
        wavelength_units = "Anq"
        wavelength_units_display = 'Anq'

    def WLRefAction1(self):
        self.buttonWLRef.setText("AIR")

    def WLRefAction2(self):
        self.buttonWLRef.setText("VAC")

    def onAccept(self):
        self.userInput = 1
        wavelengthOffset = str(self.lineWLOffset.text())
        wavelengthStepSize = str(self.lineWLStep.text())
        wavOff = "SENSe:WAVelength:OFFSet " + "%s%s" %(wavelengthOffset,wavlength_units)
        wavOff = str(conversions.str2float(wavOff, '%s' %wavelength_units))
        wavStep = "SENse:WAVelength:CENTer:STEP:INCRement " + "%snm" %wavelengthStepSize
        wavStep = str(conversions.str2float(wavStep, '%s' %wavelength_units))
        my_instrument.write(wavOff)
        my_instrument.write(wavStep)

        if self.buttonWLRef.text() == "AIR":
            my_instrument.write("SENSe:CORRection:RVELocity:MEDium AIR")
            wavelengthRefIn = "AIR"
            self.buttonWLRef.setText("AIR")
        else:
            my_instrument.write("SENSe:CORRection:RVELocity:MEDium VAC")
            wavelengthRefIn = "VAC"
            self.buttonWLRef.setText("VAC")
            
        return self.userInput

    def onReject(self):
        self.userInput = 0
        return self.userInput

        
    


class MarkerSetup(QtWidgets.QDialog, Ui_markerSetupWindow):
    def __init__(self, parent=None):
        super(MarkerSetup, self).__init__(parent)
        self.setupUi(self)

        self.buttonNormMkrUnits.setText("nm")
        self.menuNormMkrUnits = QtWidgets.QMenu()
        self.menuNormMkrUnits.addAction("nm", self.NormMkrUnitsAction1)
        self.menuNormMkrUnits.addAction("um", self.NormMkrUnitsAction2)
        self.menuNormMkrUnits.addAction("Anq", self.NormMkrUnitsAction3)
        self.menuNormMkrUnits.addAction("GHz", self.NormMkrUnitsAction4)
        self.menuNormMkrUnits.addAction("THz", self.NormMkrUnitsAction5)
        self.buttonNormMkrUnits.setMenu(self.menuNormMkrUnits)
        self.buttonBWMkrUnits.setText("nm")
        self.menuBWMkrUnits = QtWidgets.QMenu()
        self.menuBWMkrUnits.addAction("nm", self.BWMkrUnitsAction1)
        self.menuBWMkrUnits.addAction("um", self.BWMkrUnitsAction2)
        self.menuBWMkrUnits.addAction("Anq", self.BWMkrUnitsAction3)
        self.menuBWMkrUnits.addAction("GHz", self.BWMkrUnitsAction4)
        self.menuBWMkrUnits.addAction("THz", self.BWMkrUnitsAction5)
        self.buttonBWMkrUnits.setMenu(self.menuBWMkrUnits)
        self.buttonDeltaMkrUnits.setText("nm")
        self.menuDeltaMkrUnits = QtWidgets.QMenu()
        self.menuDeltaMkrUnits.addAction("nm", self.DeltaMkrUnitsAction1)
        self.menuDeltaMkrUnits.addAction("um", self.DeltaMkrUnitsAction2)
        self.menuDeltaMkrUnits.addAction("Anq", self.DeltaMkrUnitsAction3)
        self.menuDeltaMkrUnits.addAction("GHz", self.DeltaMkrUnitsAction4)
        self.menuDeltaMkrUnits.addAction("THz", self.DeltaMkrUnitsAction5)
        self.buttonDeltaMkrUnits.setMenu(self.menuDeltaMkrUnits)
        self.buttonMkrInterp.setText("On")
        self.menuMkrInterp = QtWidgets.QMenu()
        self.menuMkrInterp.addAction("On", self.MkrInterpAction1)
        self.menuMkrInterp.addAction("Off", self.MkrInterpAction2)
        self.buttonMkrInterp.setMenu(self.menuMkrInterp)
        self.buttonBWMkrInterp.setText("On")
        self.menuBWMkrInterp = QtWidgets.QMenu()
        self.menuBWMkrInterp.addAction("On", self.BWMkrInterpAction1)
        self.menuBWMkrInterp.addAction("Off", self.BWMkrInterpAction2)
        self.buttonBWMkrInterp.setMenu(self.menuBWMkrInterp)
        self.buttonUserMkrThresh.setText("On")
        self.menuUserMkrThresh = QtWidgets.QMenu()
        self.menuUserMkrThresh.addAction("On", self.UserMkrThreshAction1)
        self.menuUserMkrThresh.addAction("Off", self.UserMkrThreshAction2)
        self.buttonUserMkrThresh.setMenu(self.menuUserMkrThresh)
        self.buttonNoiseMkrBW.setText("0.1 nm")
        self.menuNoiseMkrBW = QtWidgets.QMenu()
        self.menuNoiseMkrBW.addAction("0.1 nm", self.NoiseMkrBWAction1)
        self.menuNoiseMkrBW.addAction("1.0 nm", self.NoiseMkrBWAction2)
        self.buttonNoiseMkrBW.setMenu(self.menuNoiseMkrBW)
        self.buttonPeakSrchSweep.setText("On")
        self.menuPeakSrchSweep = QtWidgets.QMenu()
        self.menuPeakSrchSweep.addAction("On", self.PeakSrchSweepAction1)
        self.menuPeakSrchSweep.addAction("Off", self.PeakSrchSweepAction2)
        self.buttonPeakSrchSweep.setMenu(self.menuPeakSrchSweep)
        self.buttonOSNR.setText("PM")
        self.menuOSNR = QtWidgets.QMenu()
        self.menuOSNR.addAction("PM", self.OSNRAction1)
        self.menuOSNR.addAction("Auto", self.OSNRAction2)
        self.menuOSNR.addAction("Manual", self.OSNRAction3)
        self.buttonOSNR.setMenu(self.menuOSNR)

    def NormMkrUnitsAction1(self):
        self.buttonNormMkrUnits.setText("nm")

    def NormMkrUnitsAction2(self):
        self.buttonNormMkrUnits.setText("um")

    def NormMkrUnitsAction3(self):
        self.buttonNormMkrUnits.setText("Anq")

    def NormMkrUnitsAction4(self):
        self.buttonNormMkrUnits.setText("GHz")

    def NormMkrUnitsAction5(self):
        self.buttonNormMkrUnits.setText("THz")

    def BWMkrUnitsAction1(self):
        self.buttonBWMkrUnits.setText("nm")

    def BWMkrUnitsAction2(self):
        self.buttonBWMkrUnits.setText("um")

    def BWMkrUnitsAction3(self):
        self.buttonBWMkrUnits.setText("Anq")

    def BWMkrUnitsAction4(self):
        self.buttonBWMkrUnits.setText("GHz")

    def BWMkrUnitsAction5(self):
        self.buttonBWMkrUnits.setText("THz")

    def DeltaMkrUnitsAction1(self):
        self.buttonDeltaMkrUnits.setText("nm")

    def DeltaMkrUnitsAction2(self):
        self.buttonDeltaMkrUnits.setText("um")

    def DeltaMkrUnitsAction3(self):
        self.buttonDeltaMkrUnits.setText("Anq")

    def DeltaMkrUnitsAction4(self):
        self.buttonDeltaMkrUnits.setText("GHz")

    def DeltaMkrUnitsAction5(self):
        self.buttonDeltaMkrUnits.setText("THz")

    def MkrInterpAction1(self):
        self.buttonMkrInterp.setText("On")

    def MkrInterpAction2(self):
        self.buttonMkrInterp.setText("Off")

    def BWMkrInterpAction1(self):
        self.buttonBWMkrInterp.setText("On")

    def BWMkrInterpAction2(self):
        self.buttonBWMkrInterp.setText("Off")

    def UserMkrThreshAction1(self):
        self.buttonUserMkrThresh.setText("On")

    def UserMkrThreshAction2(self):
        self.buttonUserMkrThresh.setText("Off")

    def NoiseMkrBWAction1(self):
        self.buttonNoiseMkrBW.setText("0.1 nm")

    def NoiseMkrBWAction2(self):
        self.buttonNoiseMkrBW.setText("1.0 nm")

    def PeakSrchSweepAction1(self):
        self.buttonPeakSrchSweep.setText("On")

    def PeakSrchSweepAction2(self):
        self.buttonPeakSrchSweep.setText("Off")

    def OSNRAction1(self):
        self.buttonOSNR.setText("PM")

    def OSNRAction2(self):
        self.buttonOSNR.setText("Auto")

    def OSNRAction3(self):
        self.buttonOSNR.setText("Manual")


class AdvancedLineMarkerWindow(QtWidgets.QDialog, Ui_advancedLineMarkerWindow):
    def __init__(self, parent=None):
        super(AdvancedLineMarkerWindow, self).__init__(parent)
        self.setupUi(self)

        self.buttonSweepLimit.setText("On")
        self.menuSweepLimit = QtWidgets.QMenu()
        self.menuSweepLimit.addAction("On", self.SweepLimitAction1)
        self.menuSweepLimit.addAction("Off", self.SweepLimitAction2)
        self.buttonSweepLimit.setMenu(self.menuSweepLimit)
        self.buttonSrchLimit.setText("On")
        self.menuSrchLimit = QtWidgets.QMenu()
        self.menuSrchLimit.addAction("On", self.SrchLimitAction1)
        self.menuSrchLimit.addAction("Off", self.SrchLimitAction2)
        self.buttonSrchLimit.setMenu(self.menuSrchLimit)
        self.buttonIntegLimit.setText("On")
        self.menuIntegLimit = QtWidgets.QMenu()
        self.menuIntegLimit.addAction("On", self.IntegLimitAction1)
        self.menuIntegLimit.addAction("Off", self.IntegLimitAction2)
        self.buttonIntegLimit.setMenu(self.menuIntegLimit)
        self.buttonTraceInteg.setText("On")
        self.menuTraceInteg = QtWidgets.QMenu()
        self.menuTraceInteg.addAction("On", self.TraceIntegAction1)
        self.menuTraceInteg.addAction("Off", self.TraceIntegAction2)
        self.buttonTraceInteg.setMenu(self.menuTraceInteg)

    def SweepLimitAction1(self):
        self.buttonSweepLimit.setText("On")

    def SweepLimitAction2(self):
        self.buttonSweepLimit.setText("Off")

    def SrchLimitAction1(self):
        self.buttonSrchLimit.setText("On")

    def SrchLimitAction2(self):
        self.buttonSrchLimit.setText("Off")

    def IntegLimitAction1(self):
        self.buttonIntegLimit.setText("On")

    def IntegLimitAction2(self):
        self.buttonIntegLimit.setText("Off")

    def TraceIntegAction1(self):
        self.buttonTraceInteg.setText("On")

    def TraceIntegAction2(self):
        self.buttonTraceInteg.setText("Off")


class TriggerModeWindow(QtWidgets.QDialog, Ui_triggerMode):
    def __init__(self, parent=None):
        super(TriggerModeWindow, self).__init__(parent)
        self.setupUi(self)


class SystemWindow(QtWidgets.QDialog, Ui_systemWindow):
    def __init__(self, parent=None):
        super(SystemWindow, self).__init__(parent)
        self.setupUi(self)
        
        self.buttonSigSource.setText("External")
        self.menuSigSource = QtWidgets.QMenu()
        self.menuSigSource.addAction("External", self.SigSourceAction1)
        self.menuSigSource.addAction("Calirator", self.SigSourceAction2)
        self.buttonSigSource.setMenu(self.menuSigSource)
        self.buttonWLRef.setText("Air")
        self.menuWLRef = QtWidgets.QMenu()
        self.menuWLRef.addAction("Air", self.WLRefAction1)
        self.menuWLRef.addAction("Vacuum", self.WLRefAction2)
        self.buttonWLRef.setMenu(self.menuWLRef)

    def SigSourceAction1(self):
        self.buttonSigSource.setText("External")

    def SigSourceAction2(self):
        self.buttonSigSource.setText("Calibrator")

    def WLRefAction1(self):
        self.buttonWLRef.setText("Air")

    def WLRefAction2(self):
        self.buttonWLRef.setText("Vacuum")


# Main window
class MainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)
        self.actionNew_Instrument.triggered.connect(self.instrumentSelectWindow)
        self.actionClose_Instrument.triggered.connect(self.closeTab)
        self.tabWidget.tabCloseRequested.connect(self.closeTab)
        self.tabCount = 0

    def instrumentSelectWindow(self):
        widget = InstrumentSelect(parent=self)
        widget.exec_()
        self.openInstrument(widget.selection)

    def openInstrument(self, device):
        if device == "AGILENT 86142B":
            indice = [i for i, s in enumerate(devices_info) if 'AGILENT 86142B' in s]
            indice = indice[0]
            instrument_address = address[indice]
            global my_instrument
            my_instrument = rm.open_resource('%s' %instrument_address)
            self.tab = Agilent86142B()
            global flag
            flag = 1
        elif device == "HEWLETT PACKARD 8157A":
            indice = [i for i, s in enumerate(devices_info) if 'HEWLETT PACKARD 8157A' in s]
            indice = indice[0]
            instrument_address = address[indice]
            global my_insturment
            my_instrument = rm.open_resource('%s' %instrument_address)
            self.tab = hp8157A()
        elif device == "":
            return
        self.tabCount += 1
        self.tabWidget.addTab(self.tab, "Inst %i" % (self.tabCount))

    def closeTab(self, currentIndex):
        currentQWidget = self.tabWidget.widget(currentIndex)
        currentQWidget.deleteLater()
        self.tabWidget.removeTab(currentIndex)
        self.tabCount -= 1


def main():
    app = QtWidgets.QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())
    

if __name__ == '__main__':
    main()
