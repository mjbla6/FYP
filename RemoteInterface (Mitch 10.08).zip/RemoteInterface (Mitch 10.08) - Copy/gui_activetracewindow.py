# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'activetracewindow.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_activeTraceWindow(object):
    def setupUi(self, activeTraceWindow):
        activeTraceWindow.setObjectName("activeTraceWindow")
        activeTraceWindow.resize(176, 300)
        self.verticalLayout = QtWidgets.QVBoxLayout(activeTraceWindow)
        self.verticalLayout.setObjectName("verticalLayout")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.checkBox_3 = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkBox_3.setObjectName("checkBox_3")
        self.verticalLayout_2.addWidget(self.checkBox_3)
        self.checkBox_2 = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkBox_2.setObjectName("checkBox_2")
        self.verticalLayout_2.addWidget(self.checkBox_2)
        self.checkBox = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkBox.setObjectName("checkBox")
        self.verticalLayout_2.addWidget(self.checkBox)
        self.checkBox_4 = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkBox_4.setObjectName("checkBox_4")
        self.verticalLayout_2.addWidget(self.checkBox_4)
        self.checkBox_5 = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkBox_5.setObjectName("checkBox_5")
        self.verticalLayout_2.addWidget(self.checkBox_5)
        self.checkBox_6 = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkBox_6.setObjectName("checkBox_6")
        self.verticalLayout_2.addWidget(self.checkBox_6)
        self.verticalLayout.addLayout(self.verticalLayout_2)
        self.buttonBox = QtWidgets.QDialogButtonBox(activeTraceWindow)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(activeTraceWindow)
        self.buttonBox.accepted.connect(activeTraceWindow.accept)
        self.buttonBox.rejected.connect(activeTraceWindow.reject)
        QtCore.QMetaObject.connectSlotsByName(activeTraceWindow)

    def retranslateUi(self, activeTraceWindow):
        _translate = QtCore.QCoreApplication.translate
        activeTraceWindow.setWindowTitle(_translate("activeTraceWindow", "Dialog"))
        self.checkBox_3.setText(_translate("activeTraceWindow", "Trace A"))
        self.checkBox_2.setText(_translate("activeTraceWindow", "Trace B"))
        self.checkBox.setText(_translate("activeTraceWindow", "Trace C"))
        self.checkBox_4.setText(_translate("activeTraceWindow", "Trace D"))
        self.checkBox_5.setText(_translate("activeTraceWindow", "Trace E"))
        self.checkBox_6.setText(_translate("activeTraceWindow", "Trace F"))

