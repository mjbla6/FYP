# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'checkdialog2.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_checkDialog2(object):
    def setupUi(self, checkDialog2):
        checkDialog2.setObjectName("checkDialog2")
        checkDialog2.resize(400, 100)
        self.verticalLayout = QtWidgets.QVBoxLayout(checkDialog2)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.checkBoxL = QtWidgets.QCheckBox(checkDialog2)
        self.checkBoxL.setObjectName("checkBoxL")
        self.horizontalLayout.addWidget(self.checkBoxL)
        self.checkBoxC = QtWidgets.QCheckBox(checkDialog2)
        self.checkBoxC.setObjectName("checkBoxC")
        self.horizontalLayout.addWidget(self.checkBoxC)
        self.checkBoxR = QtWidgets.QCheckBox(checkDialog2)
        self.checkBoxR.setObjectName("checkBoxR")
        self.horizontalLayout.addWidget(self.checkBoxR)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.buttonBox = QtWidgets.QDialogButtonBox(checkDialog2)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(checkDialog2)
        self.buttonBox.accepted.connect(checkDialog2.accept)
        self.buttonBox.rejected.connect(checkDialog2.reject)
        QtCore.QMetaObject.connectSlotsByName(checkDialog2)

    def retranslateUi(self, checkDialog2):
        _translate = QtCore.QCoreApplication.translate
        checkDialog2.setWindowTitle(_translate("checkDialog2", "Dialog"))
        self.checkBoxL.setText(_translate("checkDialog2", "CheckBox"))
        self.checkBoxC.setText(_translate("checkDialog2", "CheckBox"))
        self.checkBoxR.setText(_translate("checkDialog2", "CheckBox"))

