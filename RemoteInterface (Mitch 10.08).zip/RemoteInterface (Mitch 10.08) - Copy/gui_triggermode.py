# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'triggermode.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_triggerMode(object):
    def setupUi(self, triggerMode):
        triggerMode.setObjectName("triggerMode")
        triggerMode.resize(196, 300)
        self.gridLayout = QtWidgets.QGridLayout(triggerMode)
        self.gridLayout.setObjectName("gridLayout")
        self.buttonBox = QtWidgets.QDialogButtonBox(triggerMode)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.gridLayout.addWidget(self.buttonBox, 1, 1, 1, 1)
        self.listWidget = QtWidgets.QListWidget(triggerMode)
        self.listWidget.setObjectName("listWidget")
        item = QtWidgets.QListWidgetItem()
        self.listWidget.addItem(item)
        item = QtWidgets.QListWidgetItem()
        self.listWidget.addItem(item)
        item = QtWidgets.QListWidgetItem()
        self.listWidget.addItem(item)
        item = QtWidgets.QListWidgetItem()
        self.listWidget.addItem(item)
        item = QtWidgets.QListWidgetItem()
        self.listWidget.addItem(item)
        self.gridLayout.addWidget(self.listWidget, 0, 0, 1, 2)

        self.retranslateUi(triggerMode)
        self.buttonBox.accepted.connect(triggerMode.accept)
        self.buttonBox.rejected.connect(triggerMode.reject)
        QtCore.QMetaObject.connectSlotsByName(triggerMode)

    def retranslateUi(self, triggerMode):
        _translate = QtCore.QCoreApplication.translate
        triggerMode.setWindowTitle(_translate("triggerMode", "Trigger Mode"))
        __sortingEnabled = self.listWidget.isSortingEnabled()
        self.listWidget.setSortingEnabled(False)
        item = self.listWidget.item(0)
        item.setText(_translate("triggerMode", "Internal"))
        item = self.listWidget.item(1)
        item.setText(_translate("triggerMode", "Gated"))
        item = self.listWidget.item(2)
        item.setText(_translate("triggerMode", "External"))
        item = self.listWidget.item(3)
        item.setText(_translate("triggerMode", "ADC+"))
        item = self.listWidget.item(4)
        item.setText(_translate("triggerMode", "ADC-"))
        self.listWidget.setSortingEnabled(__sortingEnabled)

