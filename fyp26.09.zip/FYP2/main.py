# Remote Interface FYP 2018
# Mitch Blair & Isaac Naylor
#
# Last edit: 13/09/2018

## TODO: AMPLITUDE MENU -> Sensitivity [MAN] -> input dialog box needs conversion

from PyQt5 import QtCore, QtGui, QtWidgets
import sys
from gui_mainwindow import Ui_MainWindow
from gui_instrumentselect import Ui_instrumentSelect
from gui_inputdialog import Ui_inputDialog
from gui_agilent86142b import Ui_Agilent86142B
from gui_amplitudesetupwindow import Ui_amplitudeSetupWindow
from gui_wavelengthsetupwindow import Ui_wavelengthSetupWindow
from gui_activemarkerswindow import Ui_activeMarkersWindow
from gui_markersetupwindow import Ui_markerSetupWindow
from gui_advancedlinemarkerwindow import Ui_advancedLineMarkerWindow
from gui_newmarkerwindow import Ui_newMarkerWindow
from gui_systemwindow import Ui_systemWindow
from gui_hp8157a import Ui_HP8157A
from gui_aq4303b import Ui_AQ4303B
from threading import Thread, Event
import visa
import math
import numpy
import visa_manager
import runVisa
import conversions
import pyqtgraph as pg
import ast
import time, threading
from graphPlot import display



## VISA query to find available resources. Interacts with the visa_manager
## function to obtain information about the connected devices
rm = visa.ResourceManager()
resources =  rm.list_resources()
devices_info = visa_manager.devices()
address = visa_manager.GPIB_address()
num_devices = visa_manager.num_devices()

## Instrument select class adds in all available devices to the
## UI on start up and on click will start that machine process
class InstrumentSelect(QtWidgets.QDialog, Ui_instrumentSelect):
    def __init__(self, parent=None):
        super(InstrumentSelect, self).__init__(parent)
        self.setupUi(self)
        i = 0
        while i < num_devices:
            self.listWidget.addItem("%s" %devices_info[i])
            i += 1
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)
        self.buttonRefresh.clicked.connect(self.refresh)

    # refresh function will reload the devices connected
    def refresh(self):
        global devices_info
        global address
        global num_devices
        self.listWidget.clear()
        rm = visa.ResourceManager()
        resources =  rm.list_resources()
        visa_details = runVisa.returnVisa()
        devices_info = visa_details[0]
        
        address = visa_details[1]
        num_devices = visa_details[2]
        i = 0
        while i < num_devices:
            self.listWidget.addItem("%s" %devices_info[i])
            i += 1
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def onAccept(self):
        self.item = str(self.listWidget.currentItem())
        if self.item == 'None':
            self.selection = 0
            return self.selection
        else:
            self.selection = self.listWidget.currentItem().text()
            return self.selection

    def onReject(self):
        self.selection = ""
        return self.selection

## Predefining global variable
wavelength_name = "Wave"
amplitude_name = "Amp"
wavelength_units = ''
wavelength_units_display = ''
amplitude_units = ''
time_units = ''
my_instrument = ''
active_marker = ''
active_marker_matrix = ''
active_trace = ''
active_trace_num = ''
logLin = ''
autoMan =''
traceIntOnOff = ''
peakPit = ''
upDown = ''
markerBWOnOff =''
noiseMarkOnOff = ''
deltaMarkOnOff = ''
osnrMarkOnOff = ''
mkrTrc = ''
updateTraceOnOff = ''
viewTraceOnOff = ''
holdTraceNoneMinMax = ''
averagingOnOff = ''
resBwManAuto = ''
vidBwManAuto = ''
sweepTimeManAuto = ''
repeatSweepOnOff = ''
trigSyncLowHighPulse = ''
syncOutOnOff = ''
wavelengthOffset = ''
wavelengthStepSize = ''
wavelengthRefIn = ''
interval = 5
flag = ''
p1 = ''
num_points = ''
auto_ranging = ''
amplitude_correction = ''
amplitude_correction_mode = ''
Integration_Limit_1 = ''
Integration_Limit_2 = ''
Default_Math = ''
Trigger_Mode = ''
Power_Calibration = ''
Wavelength_Calibration = ''
trace_a_data = ''
trace_b_data = ''
trace_c_data = ''
trace_d_data = ''
trace_e_data = ''
trace_f_data = ''
marker_data_array = ''
frequency_units = 'kHz'


##class MyThread(Thread):
##    def __init__(self, event):
##        Thread.__init__(self)
##        self.stopped = event
##
##    def run(self):
##        while not self.stopped.wait(3):
##            print("Thread is running..")
##            print(flag)
##            if flag == 1:
##                print('running')
##                display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units,amplitude_units,num_points)

## Main class for the HP8157A machine
## TODO: move this out to a separate file
class hp8157A(QtWidgets.QWidget, Ui_HP8157A):
    def __init__(self, parent=None):
        super(hp8157A, self).__init__(parent)
        self.setupUi(self)

        att = my_instrument2.query("ATT?")
        self.spinBoxATT.setValue(float(att))
        cal = my_instrument2.query("CAL?")
        self.spinBoxCAL.setValue(float(cal))
        self.lcdAtt.display(float(att) + float(cal))
        wvl = my_instrument2.query("WVL?")
        wvl = float(wvl)
        wvl = wvl*(1000000000)
        wvl = int(wvl)
        self.spinBoxWL.setValue(wvl)
        D = my_instrument2.query("D?")
        D = int(D)
        if (D == 1):
            self.buttonDisable.setChecked(True)

        self.spinBoxATT.valueChanged.connect(self.valueChange)
        self.spinBoxCAL.valueChanged.connect(self.valueChange)
        self.spinBoxWL.valueChanged.connect(self.valueChange)
        self.buttonDisable.clicked.connect(self.unitEnable)

    def valueChange(self):
        self.lcdAtt.display(self.spinBoxATT.value() + self.spinBoxCAL.value())
        my_instrument2.write("WVL %i NM" % self.spinBoxWL.value())
        my_instrument2.write("CAL %f dB" % self.spinBoxCAL.value())
        my_instrument2.write("ATT %f dB" % self.spinBoxATT.value()) 

    def unitEnable(self):
        if self.buttonDisable.isChecked():
            my_instrument2.write("D1")
        else:
            my_instrument2.write("D0")

class AQ4303B(QtWidgets.QWidget, Ui_AQ4303B):
    def __init__(self, parent=None):
        super(AQ4303B, self).__init__(parent)
        self.setupUi(self)
        my_instrument3.write("B")
        my_instrument3.write("C")
        light = '270Hz'
        wavelength = '400-600'
        self.buttonWL.setText(wavelength)
        self.buttonLight.setText(light)

        self.WL = QtWidgets.QMenu()
        self.WL.addAction("400-600", self.WLAction1)
        self.WL.addAction("600-1000", self.WLAction2)
        self.WL.addAction("1000-1800", self.WLAction3)
        self.buttonWL.setMenu(self.WL)

        self.lightMenu = QtWidgets.QMenu()
        self.lightMenu.addAction("CW", self.lightMenuAction1)
        self.lightMenu.addAction("270Hz", self.lightMenuAction2)
        self.buttonLight.setMenu(self.lightMenu)

    def lightMenuAction1(self):
        self.buttonLight.setText("CW")
        my_instrument3.write("A")

    def lightMenuAction2(self):
        self.buttonLight.setText("270Hz")
        my_instrument3.write("B")

    def WLAction1(self):
        self.buttonWL.setText("400-600")
        my_instrument3.write("C")

    def WLAction2(self):
        self.buttonWL.setText("600-1000")
        my_instrument3.write("D")

    def WLAction3(self):
        self.buttonWL.setText("1000-1800")
        my_instrument3.write("E")

##my_event = Event()
##thread = MyThread(my_event)
##thread.start()

# Main class for the Agilent 86142B OSA
# TO DO: Move this out as a separate file
class Agilent86142B(QtWidgets.QWidget, Ui_Agilent86142B):
    def __init__(self, parent=None):
        super(Agilent86142B, self).__init__(parent)
        self.setupUi(self)
        self.setupInstrument()
        self.infoDisplay()
        my_instrument.timeout = 20000
        self.p1 = pg.PlotWidget()
        self.p1.showGrid(x=True, y=True)
        global ref_plot
        ref_plot = self.p1.plot(x=[], y=[])
        global line_1_plot
        line_1_plot = self.p1.plot(x=[], y=[])
        global line_2_plot
        line_2_plot = self.p1.plot(x=[], y=[])
        global thresh_plot
        thresh_plot = self.p1.plot(x=[], y=[])

        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        global Mkr1_plot
        global Mkr2_plot
        global Mkr3_plot
        global Mkr4_plot
        Mkr1_plot = self.p1.plot(x=[], y=[])
        Mkr2_plot = self.p1.plot(x=[], y=[])
        Mkr3_plot = self.p1.plot(x=[], y=[])
        Mkr4_plot = self.p1.plot(x=[], y=[])
        self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        self.threshPlot()
        self.wavelengthMenu()
         

        # Setup mouse events on graph
        mypen = pg.mkPen('y', width=1)
        self.curve = self.p1.plot(x=[], y=[], pen=mypen)
        self.curve.scene().sigMouseMoved.connect(self.onMouseMoved)
        self.p1.scene().sigMouseClicked.connect(self.onMouseClicked)

        # Active buttons
        self.buttonActMkrGbl.setText("Mkr %s" %active_marker)
        self.menuActMkrGbl = QtWidgets.QMenu()
        self.menuActMkrGbl.addAction("Mkr 1", self.ActMkrGbl1)
        self.menuActMkrGbl.addAction("Mkr 2", self.ActMkrGbl2)
        self.menuActMkrGbl.addAction("Mkr 3", self.ActMkrGbl3)
        self.menuActMkrGbl.addAction("Mkr 4", self.ActMkrGbl4)
        self.buttonActMkrGbl.setMenu(self.menuActMkrGbl)
        self.buttonActTrcGbl.setText("Trace %s" %active_trace[2])
        self.menuActTrcGbl = QtWidgets.QMenu()
        self.menuActTrcGbl.addAction("Trace A", self.ActTrcGbl1)
        self.menuActTrcGbl.addAction("Trace B", self.ActTrcGbl2)
        self.menuActTrcGbl.addAction("Trace C", self.ActTrcGbl3)
        self.menuActTrcGbl.addAction("Trace D", self.ActTrcGbl4)
        self.menuActTrcGbl.addAction("Trace E", self.ActTrcGbl5)
        self.menuActTrcGbl.addAction("Trace F", self.ActTrcGbl6)
        self.buttonActTrcGbl.setMenu(self.menuActTrcGbl)
        self.buttonSystem.clicked.connect(self.systemMenu)
        self.buttonDispDisable.setText("Off")
        self.menuDispDisable = QtWidgets.QMenu()
        self.menuDispDisable.addAction("On", self.DisableDispAction1)
        self.menuDispDisable.addAction("Off", self.DisableDispAction2)
        self.buttonDispDisable.setMenu(self.menuDispDisable)

        # Top menu buttons clicked
        self.buttonWavelength.clicked.connect(self.wavelengthMenu)
        self.buttonAmplitude.clicked.connect(self.amplitudeMenu)
        self.buttonMarkers.clicked.connect(self.markersMenu)
        self.buttonTraces.clicked.connect(self.tracesMenu)
        self.buttonBW.clicked.connect(self.bwMenu)

        # Bottom menu button clicked
        self.buttonAutoMeasure.clicked.connect(self.autoMeasure)
        self.buttonAutoAlign.clicked.connect(self.autoAlign)


    # TODO: can remove active_trace
    def traceDisplay(self, num_points, active_trace, xLabel, yLabel, xUnits, yUnits, trace_a_data, trace_b_data, trace_c_data,
                trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param, trace_d_param, trace_e_param, trace_f_param,
                     sweep):
        global trace_start
        global trace_stop
        global TRA_plot
        global TRB_plot
        global TRC_plot
        global TRD_plot
        global TRE_plot
        global TRF_plot
        global traceA
        global traceB
        global traceC
        global traceD
        global traceE
        global traceF
        global trace_x_values
        global trace_y_values
        
        self.p1.clear()
        self.p1.setLabel('left', '%s' %yLabel, units='%s' %yUnits)
        self.p1.setLabel('bottom', '%s' %xLabel, units='%s' %xUnits)

        if sweep == 1:
            my_instrument.write("INIT:CONT OFF")
            my_instrument.write("INIT:IMM;*OPC?") ## take sweep and wait for finish

        if trace_a_param[1] == "ON":
            trace_start = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STARt? TRA")) ## finds start of trace in right format
            trace_stop = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STOP? TRA")) ## finds end of trace in right format
            trace_y_values = ast.literal_eval(my_instrument.query("TRAC? TRA")) ## obtains trace data for y values (power)
            trace_x_values = numpy.linspace(trace_start,trace_stop,num_points) ## runs linspace function to create the equating x data points (wavelength)
            trace_data = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            traceA = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            TRA_plot = self.p1.plot(trace_data, pen='y')
            
        if trace_b_param[1] == "ON":
            trace_start = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STARt? TRB")) ## finds start of trace in right format
            trace_stop = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STOP? TRB")) ## finds end of trace in right format
            trace_y_values = ast.literal_eval(my_instrument.query("TRAC? TRB")) ## obtains trace data for y values (power)
            trace_x_values = numpy.linspace(trace_start,trace_stop,num_points) ## runs linspace function to create the equating x data points (wavelength)
            trace_data = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            traceB = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            TRB_plot = self.p1.plot(trace_data, pen='g')

        if trace_c_param[1] == "ON":
            trace_start = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STARt? TRC")) ## finds start of trace in right format
            trace_stop = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STOP? TRc")) ## finds end of trace in right format
            trace_y_values = ast.literal_eval(my_instrument.query("TRAC? TRC")) ## obtains trace data for y values (power)
            trace_x_values = numpy.linspace(trace_start,trace_stop,num_points) ## runs linspace function to create the equating x data points (wavelength)
            trace_data = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            traceC = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            TRC_plot = self.p1.plot(trace_data, pen='c')
            
        if trace_d_param[1] == "ON":
            trace_start = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STARt? TRD")) ## finds start of trace in right format
            trace_stop = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STOP? TRD")) ## finds end of trace in right format
            trace_y_values = ast.literal_eval(my_instrument.query("TRAC? TRD")) ## obtains trace data for y values (power)
            trace_x_values = numpy.linspace(trace_start,trace_stop,num_points) ## runs linspace function to create the equating x data points (wavelength)
            trace_data = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            traceD = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            TRD_plot = self.p1.plot(trace_data, pen='r')
            
        if trace_e_param[1] == "ON":
            trace_start = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STARt? TRE")) ## finds start of trace in right format
            trace_stop = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STOP? TRE")) ## finds end of trace in right format
            trace_y_values = ast.literal_eval(my_instrument.query("TRAC? TRE")) ## obtains trace data for y values (power)
            trace_x_values = numpy.linspace(trace_start,trace_stop,num_points) ## runs linspace function to create the equating x data points (wavelength)
            trace_data = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            traceE = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            TRE_plot = self.p1.plot(trace_data, pen='b')
            
        if trace_f_param[1] == "ON":
            trace_start = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STARt? TRF")) ## finds start of trace in right format
            trace_stop = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STOP? TRF")) ## finds end of trace in right format
            trace_y_values = ast.literal_eval(my_instrument.query("TRAC? TRF")) ## obtains trace data for y values (power)
            trace_x_values = numpy.linspace(trace_start,trace_stop,num_points) ## runs linspace function to create the equating x data points (wavelength)
            trace_data = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            traceF = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
            TRF_plot = self.p1.plot(trace_data, pen='m')

        frame_start = ast.literal_eval(my_instrument.query("SENSe:WAVelength:STARt?")) ## finds left hand side of display
        frame_stop = ast.literal_eval(my_instrument.query("SENSe:WAVelength:STOP?")) ## finds right hand side of display

        global ref_level
        global ref_plot

        # plotting the reference level
        self.p1.removeItem(ref_plot)
        ref_level = my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:RLEVel?")
        ref_level = conversions.str2float(ref_level,"dBm")
        x_ref = numpy.linspace(trace_start,trace_stop,10000)
        y_ref = numpy.ones(10000)
        y_ref = ref_level*y_ref
        ref_plot = self.p1.plot(x_ref, y_ref, pen='g')
        self.p1.setXRange(frame_start,frame_stop)
        self.graphLayout.addWidget(self.p1)

    # function to plot the line markers defined in the line markers menu
    def lineMarkerDisplay(self,line1,line2,lineMarkerOnOff):
        global line_1_plot
        global line_2_plot
        x_line_1 = float(line1)*0.000000001
        x_line_2 = float(line2)*0.000000001
        y_range = self.p1.viewRange()
        y_range = y_range[1]
        y_upper = y_range[1]
        y_lower = y_range[0]
        y_values = numpy.linspace(y_lower,y_upper,10000)
        x_values = numpy.ones(10000)
        x1 = x_values*x_line_1
        x2 = x_values*x_line_2
        if lineMarkerOnOff == 'On':
            self.p1.removeItem(line_1_plot)
            self.p1.removeItem(line_2_plot)
            line_1_plot = self.p1.plot(x1, y_values, pen='y')
            line_2_plot = self.p1.plot(x2, y_values, pen='y')
        elif lineMarkerOnOff == 'Off':
            self.p1.removeItem(line_1_plot)
            self.p1.removeItem(line_2_plot)
            line_1_plot = self.p1.plot(x=[], y=[])
            line_2_plot = self.p1.plot(x=[], y=[])

    # function to plot the user threshold defined in the marker setup menu
    def threshPlot(self):
        global mkrThreshOnOff
        global userMkrThresh
        global trace_start
        global trace_stop
        global thresh_plot
        if mkrThreshOnOff == 'ON':
            self.p1.removeItem(thresh_plot)
            thresh_level = userMkrThresh
            x_thresh = numpy.linspace(trace_start,trace_stop,10000)
            y_thresh = numpy.ones(10000)
            y_thresh = y_thresh*float(thresh_level)
            thresh_plot = self.p1.plot(x_thresh, y_thresh, pen='c')
        elif mkrThreshOnOff == 'OFF':
            self.p1.removeItem(thresh_plot)
            thresh_plot = self.p1.plot(x=[], y=[])

    # the following clear functions clear the corresponding marker displays at the top of the display      
    def clearTopText1(self):
        self.topLabel11.setText("")
        self.topLabel12.setText("")
        self.topLabel13.setText("")

    def clearTopText2(self):
        self.topLabel21.setText("")
        self.topLabel22.setText("")
        self.topLabel23.setText("")

    def clearTopText3(self):
        self.topLabel31.setText("")
        self.topLabel32.setText("")
        self.topLabel33.setText("")

    def clearTopText4(self):
        self.topLabel41.setText("")
        self.topLabel42.setText("")
        self.topLabel43.setText("")

    def clearTopText5(self):
        self.topLabel51.setText("")
        self.topLabel52.setText("")
        self.topLabel53.setText("")

    def clearTopText6(self):
        self.topLabel61.setText("")
        self.topLabel62.setText("")
        self.topLabel63.setText("")
        
    def ActMkrGbl1(self):
        self.buttonActMkrGbl.setText("Mkr 1")
        global active_marker
        active_marker = '1'
        global mkr_1_param
        mkr_1_param[0] = '1'
        global active_mkr_param
        active_mkr_param = mkr_1_param
        my_instrument.write("CALCulate:MARKer1:STATe ON")
        self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        self.mkr1Display()
        global active_BW_param
        active_BW_param = BW_1_param
        if mkr_1_param[3] == 'OFF' and mkr_1_param[4] == 'OFF' and mkr_1_param[5] == 'OFF' and mkr_1_param[6] == 'OFF':
            self.mkrCompDisplay()
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 2:
            self.moreMkrFunc()

    def ActMkrGbl2(self):
        self.buttonActMkrGbl.setText("Mkr 2")
        global active_marker
        active_marker = '2'
        global mkr_2_param
        mkr_2_param[0] = '1'
        global active_mkr_param
        active_mkr_param = mkr_2_param
        my_instrument.write("CALCulate:MARKer2:STATe ON")
        self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        self.mkr2Display()
        global active_BW_param
        active_BW_param = BW_2_param
        if mkr_2_param[3] == 'OFF' and mkr_2_param[4] == 'OFF' and mkr_2_param[5] == 'OFF' and mkr_2_param[6] == 'OFF':
            self.mkrCompDisplay()
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 2:
            self.moreMkrFunc()

    def ActMkrGbl3(self):
        self.buttonActMkrGbl.setText("Mkr 3")
        global active_marker
        active_marker = '3'
        global mkr_3_param
        mkr_3_param[0] = '1'
        global active_mkr_param
        active_mkr_param = mkr_3_param
        my_instrument.write("CALCulate:MARKer3:STATe ON")
        self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        self.mkr3Display()
        global active_BW_param
        active_BW_param = BW_3_param
        if mkr_3_param[3] == 'OFF' and mkr_3_param[4] == 'OFF' and mkr_3_param[5] == 'OFF' and mkr_3_param[6] == 'OFF':
            self.mkrCompDisplay()
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 2:
            self.moreMkrFunc()

    def ActMkrGbl4(self):
        self.buttonActMkrGbl.setText("Mkr 4")
        global active_marker
        active_marker = '4'
        global mkr_4_param
        mkr_4_param[0] = '1'
        global active_mkr_param
        active_mkr_param = mkr_4_param
        my_instrument.write("CALCulate:MARKer4:STATe ON")
        self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        self.mkr4Display()
        global active_BW_param
        active_BW_param = BW_4_param
        if mkr_4_param[3] == 'OFF' and mkr_4_param[4] == 'OFF' and mkr_4_param[5] == 'OFF' and mkr_4_param[6] == 'OFF':
            self.mkrCompDisplay()
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 2:
            self.moreMkrFunc()


    def ActTrcGbl1(self):
        self.buttonActTrcGbl.setText("Trace A")
        global active_trace
        active_trace = "TRA"
        global active_trace_num
        active_trace_num = '1'
        global trace_a_param
        trace_a_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_a_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()

    def ActTrcGbl2(self):
        self.buttonActTrcGbl.setText("Trace B")
        global active_trace
        active_trace = "TRB"
        global active_trace_num
        active_trace_num = '2'
        global trace_b_param
        trace_b_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_b_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()

    def ActTrcGbl3(self):
        self.buttonActTrcGbl.setText("Trace C")
        global active_trace
        active_trace = "TRC"
        global active_trace_num
        active_trace_num = '3'
        global trace_c_param
        trace_c_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_c_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()

    def ActTrcGbl4(self):
        self.buttonActTrcGbl.setText("Trace D")
        global active_trace
        active_trace = "TRD"
        global active_trace_num
        active_trace_num = '4'
        global trace_d_param
        trace_d_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_d_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()

    def ActTrcGbl5(self):
        self.buttonActTrcGbl.setText("Trace E")
        global active_trace
        active_trace = "TRE"
        global active_trace_num
        active_trace_num = '5'
        global trace_e_param
        trace_e_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_e_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()
            
    def ActTrcGbl6(self):
        self.buttonActTrcGbl.setText("Trace F")
        global active_trace
        active_trace = "TRF"
        global active_trace_num
        active_trace_num = '6'
        global trace_f_param
        trace_f_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_f_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()


    def updateMkrParam(self):
        global active_marker
        global active_mkr_param
        global mkr_1_param
        global mkr_2_param
        global mkr_3_param
        global mkr_4_param

        if active_marker == '1':
            mkr_1_param = active_mkr_param
            BW_1_param = active_BW_param
        if active_marker == '2':
            mkr_2_param = active_mkr_param
            BW_2_param = active_BW_param
        if active_marker == '3':
            mkr_3_param = active_mkr_param
            BW_3_param = active_BW_param
        if active_marker == '4':
            mkr_4_param = active_mkr_param
            BW_4_param = active_BW_param

    def updateTrcParam(self):
        global active_trace_num
        global trace_a_param
        global trace_b_param
        global trace_c_param
        global trace_d_param
        global trace_e_param
        global trace_f_param

        if active_trace_num == '1':
            trace_a_param = active_trace_param
        if active_trace_num == '2':
            trace_b_param = active_trace_param
        if active_trace_num == '3':
            trace_c_param = active_trace_param
        if active_trace_num == '4':
            trace_d_param = active_trace_param
        if active_trace_num == '5':
            trace_e_param = active_trace_param
        if active_trace_num == '6':
            trace_f_param = active_trace_param

    # function to use the left and right arrow keys to move the active marker left or right along the trace.
    # indent_margin variable defines how far the marker moves on each key press
    def keyPressEvent(self, event):
        key = event.key()
        modifier = event.key()
        markerY = my_instrument.query("CALCulate:MARKer%s:Y?" %active_marker)
        markerY = conversions.str2float(markerY, amplitude_units)
        if active_trace == "TRA":
            traceX = traceA[:,0]
            traceY = traceA[:,1]
        elif active_trace == "TRB":
            traceX = traceB[:,0]
            traceY = traceB[:,1]
        elif active_trace == "TRC":
            traceX = traceC[:,0]
            traceY = traceC[:,1]
        elif active_trace == "TRD":
            traceX = traceD[:,0]
            traceY = traceD[:,1]
        elif active_trace == "TRE":
            traceX = traceE[:,0]
            traceY = traceE[:,1]
        elif active_trace == "TRF":
            traceX = traceF[:,0]
            traceY = traceF[:,1]
        i = 0
        while i<len(traceY):
            if markerY == traceY[i]:
                index = i
                i = len(traceY)
            else:
                i = i+1
                
        indent_margin = 5
        if key == QtCore.Qt.Key_Left:
            index = index - indent_margin
            trace_x_val = str(conversions.str2float(traceX[index],wavelength_units))
            trace_y_val = str(conversions.str2float(traceY[index],amplitude_units))
            my_instrument.write("CALCulate:MARKer%s:X %s%s" %(active_marker,trace_x_val,wavelength_units))
            my_instrument.write("CALCulate:MARKer%s:Y %s%s" %(active_marker,trace_y_val,amplitude_units))
            self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
            if active_marker == "1":
                self.mkr1Display()
            elif active_marker == "2":
                self.mkr2Display()
            elif active_marker == "3":
                self.mkr3Display()
            elif active_marker == "4":
                self.mkr4Display()       
     
        if key == QtCore.Qt.Key_Right:
            index = index + indent_margin
            trace_x_val = str(conversions.str2float(traceX[index],wavelength_units))
            trace_y_val = str(conversions.str2float(traceY[index],amplitude_units))
            my_instrument.write("CALCulate:MARKer%s:X %s%s" %(active_marker,trace_x_val,wavelength_units))
            my_instrument.write("CALCulate:MARKer%s:Y %s%s" %(active_marker,trace_y_val,amplitude_units))
            self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
            if active_marker == "1":
                self.mkr1Display()
            elif active_marker == "2":
                self.mkr2Display()
            elif active_marker == "3":
                self.mkr3Display()
            elif active_marker == "4":
                self.mkr4Display()

        

    def onMouseMoved(self, point):
        global p
        p = self.p1.plotItem.vb.mapSceneToView(point)

    # onMouseClicked allows the user to place a marker on the trace with a mouse click.
    def onMouseClicked(self, event):
        global active_marker
        global active_trace
        buttons = event.button()
        if buttons == 1:
            widget = NewMarkerWindow(active_marker, active_trace, trace_a_param, trace_b_param, trace_c_param, trace_d_param, trace_e_param, trace_f_param)
            widget.exec_()
        if widget.selection != 0:
            global traceA
            global traceB
            global traceC
            global traceD
            global traceE
            global traceF
            global mkr_1_param
            global mkr_2_param
            global mkr_3_param
            global mkr_4_param

            if widget.trace == 'Trace A':
                self.ActTrcGbl1()
            if widget.trace == 'Trace B':
                self.ActTrcGbl2()
            if widget.trace == 'Trace C':
                self.ActTrcGbl3()
            if widget.trace == 'Trace D':
                self.ActTrcGbl4()
            if widget.trace == 'Trace E':
                self.ActTrcGbl5()
            if widget.trace == 'Trace F':
                self.ActTrcGbl6()

            if widget.marker == 'Mkr 1':
                active_marker = '1'
                mkr_1_param[0] = '1'
            if widget.marker == 'Mkr 2':
                active_marker = '2'
                mkr_2_param[0] = '1'
            if widget.marker == 'Mkr 3':
                active_marker = '3'
                mkr_3_param[0] = '1'
            if widget.marker == 'Mkr 4':
                active_marker = '4'
                mkr_4_param[0] = '1'

            error_thresh = 0.01
            if active_trace == 'TRA':
                trace_data = traceA
                self.ActTrcGbl1()
            if active_trace == 'TRB':
                trace_data = traceB
                self.ActTrcGbl2()
            if active_trace == 'TRC':
                trace_data = traceC
                self.ActTrcGbl3()
            if active_trace == 'TRD':
                trace_data = traceD
                self.ActTrcGbl4()
            if active_trace == 'TRE':
                trace_data = traceE
                self.ActTrcGbl5()
            if active_trace == 'TRF':
                trace_data = traceF
                self.ActTrcGbl6()
                
            trace_x = trace_data[:,0]
            trace_y = trace_data[:,1]
            for i in range(len(trace_x)):
                distance_x = abs(trace_x[i]-p.x())
                if distance_x < error_thresh:
                    mkr_index = i
                    error_thresh = distance_x

            marker_x_write = "CALCulate:MARKer%s:X %sm" %(active_marker,trace_x[mkr_index])
            marker_y_write = "CALCulate:MARKer%s:Y %s%s" %(active_marker,trace_y[mkr_index],amplitude_units)
            my_instrument.write(marker_x_write)
            my_instrument.write(marker_y_write)

            if active_marker == '1':
                self.buttonActMkrGbl.setText("Mkr 1")
                mkr_1_param[7] = active_trace
                self.mkr1Display()
            if active_marker == '2':
                self.buttonActMkrGbl.setText("Mkr 2")
                mkr_2_param[7] = active_trace
                self.mkr2Display()
            if active_marker == '3':
                self.buttonActMkrGbl.setText("Mkr 3")
                mkr_3_param[7] = active_trace
                self.mkr3Display()
            if active_marker == '4':
                self.buttonActMkrGbl.setText("Mkr 4")
                mkr_4_param[7] = active_trace
                self.mkr4Display()
        
            markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)

    # marker diplay is the main function to draw the markers on the display. The active marker will be shown in white
    # and the rest of the markers will be shown in green
    def markerDisplay(self, active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param):
        if wavelength_units == 'nm':
            conversion = 0.000000001
        if wavelength_units == 'um':
            conversion = 0.000001

        global mkr1Colour
        global mkr2Colour
        global mkr3Colour
        global mkr4Colour
        if active_marker == '1':
            mkr1Colour = 'w'
            mkr2Colour = 'g'
            mkr3Colour = 'g'
            mkr4Colour = 'g'
        if active_marker == '2':
            mkr1Colour = 'g'
            mkr2Colour = 'w'
            mkr3Colour = 'g'
            mkr4Colour = 'g'
        if active_marker == '3':
            mkr1Colour = 'g'
            mkr2Colour = 'g'
            mkr3Colour = 'w'
            mkr4Colour = 'g'
        if active_marker == '4':
            mkr1Colour = 'g'
            mkr2Colour = 'g'
            mkr3Colour = 'g'
            mkr4Colour = 'w'

        global Mkr1_plot
        global Mkr2_plot
        global Mkr3_plot
        global Mkr4_plot
##        if mkrExtraFlag == 1:
##            if osnrMarkOnOff == 'ON':
##                print('do things')
##            elif deltaMarkOnOff == 'ON':
##                print('do things')
##            elif noiseMarkOnOff == 'ON':
##                print('do things')
##            elif markerBWOnOff == 'ON':
##                print('do things')
##        else:
        if mkr_1_param[0] == '1':
            self.p1.removeItem(Mkr1_plot)
            x_data = mkr_1_param[1] * conversion
            y_data = mkr_1_param[2]
            Mkr1_plot = self.p1.plot([x_data],[y_data],symbol='d',symbolPen=mkr1Colour,symbolBrush=None)
        elif mkr_1_param[0] == '0':
            self.p1.removeItem(Mkr1_plot)
            Mkr1_plot = self.p1.plot(x=[], y=[])
        if mkr_2_param[0] == '1':
            self.p1.removeItem(Mkr2_plot)
            x_data = mkr_2_param[1] * conversion
            y_data = mkr_2_param[2]
            Mkr2_plot = self.p1.plot([x_data],[y_data],symbol='d',symbolPen=mkr2Colour,symbolBrush=None)
        elif mkr_2_param[0] == '0':
            self.p1.removeItem(Mkr2_plot)
            Mkr2_plot = self.p1.plot(x=[], y=[])
        if mkr_3_param[0] == '1':
            self.p1.removeItem(Mkr3_plot)
            x_data = mkr_3_param[1] * conversion
            y_data = mkr_3_param[2]
            Mkr3_plot = self.p1.plot([x_data],[y_data],symbol='d',symbolPen=mkr3Colour,symbolBrush=None)
        elif mkr_3_param[0] == '0':
            self.p1.removeItem(Mkr3_plot)
            Mkr3_plot = self.p1.plot(x=[], y=[])
        if mkr_4_param[0] == '1':
            self.p1.removeItem(Mkr4_plot)
            x_data = mkr_4_param[1] * conversion
            y_data = mkr_4_param[2]
            Mkr4_plot = self.p1.plot([x_data],[y_data],symbol='d',symbolPen=mkr4Colour,symbolBrush=None)
        elif mkr_4_param[0] == '0':
            self.p1.removeItem(Mkr4_plot)
            Mkr4_plot = self.p1.plot(x=[], y=[])

    def autoMeasure(self):
        my_instrument.write("DISPlay:WINDow:TRACe:ALL:SCALe:AUTO")

    def autoAlign(self):
        my_instrument.write("CALibration:ALIGn")

    def DisableDispAction1(self):
        self.buttonDispDisable.setText("On")
        my_instrument.write("DISPlay:WINDow OFF")

    def DisableDispAction2(self):
        self.buttonDispDisable.setText("Off")
        my_instrument.write("DISPlay:WINDow ON")

    def systemMenu(self):
        widget = SystemWindow()
        widget.exec_()

    
    ## Setup instrument is run at start up of the OSA to query the machine and
    ## determine initial values and settings
    def setupInstrument(self): 
        global menuFlag
        menuFlag = 0
    
        global active_marker
        global active_trace
        global active_trace_num
        #active_trace = "TRA"
        #active_trace_num = "1"
        #my_instrument.write("CALCulate:MARKer%s:TRACe TRA" %active_marker)

        global wavelength_units
        wavelength_units = "nm" 
        
        global wavelength_units_display
        if wavelength_units == 'nm' or wavelength_units == 'um':
            wavelength_units_display = 'm'
        elif wavelength_units == 'Ang':
            wavelength_units_display = 'Ang'
        else:
            wavelength_units_display = 'm'

        global logLin
        logLin = str(my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:SPACing?")).rstrip()

        global amplitude_units
        amplitude_units = str(my_instrument.query("UNIT:POW?")).rstrip()
        if amplitude_units == 'AUTO':
            amplitude_units = 'dB'
        else:
            amplitude_units  = 'W'

        global time_units
        time_units = 'us'

        global frequency_units
        frequency_units = 'kHz'

        global autoMan
        autoMan = str(my_instrument.query("SENSe:POWer:DC:RANGe:LOWer:AUTO?")).rstrip()
        if autoMan == "1":
            autoMan = "AUTO"
        elif autoMan == "0":
            autoMan = "MAN"

        global traceIntOnOff
        traceIntOnOff = str(my_instrument.query("CALCulate:TPOWer:STATe?")).rstrip()
        if traceIntOnOff == "1":
            traceIntOnOff = "ON"
        elif traceIntOnOff == "0":
            traceIntOnOff = "OFF"

        global peakPit
        peakPit = "PEAK"

        global upDown
        upDown = "Down"

        global search_flag
        search_flag = my_instrument.query("CALCulate:MARKer:SRANge:STATe?")
        if search_flag == '1':
            search_flag = 1
        else:
            search_flag = 0

        global sweep_flag
        sweep_flag = my_instrument.query("SENSe:WAVelength:SRANge:STATe?")
        if sweep_flag == '1':
            sweep_flag = 1
        else:
            sweep_flag = 0

        global sweep_limit
        sweep_limit = str(my_instrument.query("SENSe:WAVelength:SRANge:STATe?")).rstrip()
        if sweep_limit == '0':
            sweep_limit = 'Off'
        else:
            sweep_limit = 'On'

        global search_limit
        search_limit = str(my_instrument.query("CALCulate:MARKer:SRANge:STATe?")).rstrip()
        if search_limit == '0':
            search_limit = 'Off'
        else:
            search_limit = 'On'

        global integral_limit
        integral_limit = str(my_instrument.query("CALCulate:TPOWer:IRANge:STATe?")).rstrip()
        if integral_limit == '0':
            integral_limit = 'Off'
        else:
            integral_limit = 'On'

        global trace_integral
        trace_integral = str(my_instrument.query("CALCulate:TPOWer:STATe?")).rstrip()
        if trace_integral == '0':
            trace_integral = 'Off'
        else:
            trace_integral = 'On'

        global line1
        line1 = str(my_instrument.query("CALCulate:TPOWer:IRANge:LOWer?")).rstrip()
        line1 = str(conversions.str2float(line1, wavelength_units))

        global line2
        line2 = str(my_instrument.query("CALCulate:TPOWer:IRANge:UPPer?")).rstrip()
        line2 = str(conversions.str2float(line2, wavelength_units))

        global mkr_units
        mkr_units = 'nm'

        global BW_units
        BW_units = 'nm'

        global delta_units
        delta_units = 'nm'

        global mkrInterpOnOff
        mkrInterpOnOff = str(my_instrument.query("CALCulate:MARKer:INT?")).rstrip()
        if mkrInterpOnOff == '0':
            mkrInterpOnOff = 'OFF'
        elif mkrInterpOnOff == '1':
            mkrInterpOnOff = 'ON'

        global BWInterpOnOff
        BWInterpOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:BANDwidth:INT?" %active_marker)).rstrip()
        if BWInterpOnOff == '0':
            BWInterpOnOff = 'OFF'
        elif BWInterpOnOff == '1':
            BWInterpOnOff = 'ON'

        global mkrThreshOnOff
        mkrThreshOnOff = str(my_instrument.query("CALCulate:THReshold:STATe?")).rstrip()
        if mkrThreshOnOff == '0':
            mkrThreshOnOff = 'OFF'
        elif mkrThreshOnOff == '1':
            mkrThreshOnOff = 'ON'

        global userMkrThresh
        if mkrThreshOnOff == 'ON':
            userMkrThresh = str(my_instrument.query("CALCulate:THReshold?")).rstrip()
            userMkrThresh = str(conversions.str2float(userMkrThresh,'dB'))
        else:
            userMkrThresh = '0'

        global noiseMkrBW
        noiseMkrBW = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:NOISe:BANDwidth?" %active_marker)).rstrip()
        noiseMkrBW = str(conversions.str2float(noiseMkrBW,'nm'))

        global OSNRType
        OSNRType = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:OSNR:MODE?" %active_marker)).rstrip()

        global OSNROffset
        if OSNRType == 'MAN':
            OSNROffset = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:OSNR:OFFSet?" %active_marker)).rstrip()
        else:
            OSNROffset = '0'

        global peakExcur
        peakExcur = str(my_instrument.query("CALCulate:MARKer%s:PEXCursion:PEAK?" %active_marker)).rstrip()

        global pitExcur
        pitExcur = str(my_instrument.query("CALCulate:MARKer%s:PEXCursion:PIT?" %active_marker)).rstrip()

        global resBw
        value = my_instrument.query("SENSe:BANDwidth:RESolution?")
        resBw = conversions.str2float(value,"%s" %wavelength_units)

## REPLACE MARKER SECTION IN SETUP INSTRUMENT
## ------------------------------------------
##              MARKER PARAMETERS
## ------------------------------------------
        
        global mkrOnOff
        global markerBWOnOff
        global noiseMarkOnOff
        global deltaMarkOnOff
        global osnrMarkOnOff
        global mkrTrc
        global mkr_1_param
        global mkr_2_param
        global mkr_3_param
        global mkr_4_param
        global BW_1_param
        global BW_2_param
        global BW_3_param
        global BW_4_param
        global mkrExtraFlag
        ## mkr_x_param = [ON/OFF, X, Y, BWOnOff, NoiseOnOff, DeltaOnOff, OSNROnOff, TRACE]
        mkr_1_param = [0, 0, 0, '0', '0', '0', '0', '0']
        mkr_2_param = [0, 0, 0, '0', '0', '0', '0', '0']
        mkr_3_param = [0, 0, 0, '0', '0', '0', '0', '0']
        mkr_4_param = [0, 0, 0, '0', '0', '0', '0', '0']
        ## bw_x_param = [xL, XR, yL, yR, xDifference, mkrBWY]
        BW_1_param = [0, 0, 0, 0, 0, 0]
        BW_2_param = [0, 0, 0, 0, 0, 0]
        BW_3_param = [0, 0, 0, 0, 0, 0]
        BW_4_param = [0, 0, 0, 0, 0, 0]

        for i in range(1,5):
            if i == 1:
                itrac = "1"
            if i == 2:
                itrac = "2"
            if i == 3:
                itrac = "3"
            if i == 4:
                itrac = "4"

            mkrOnOff = str(my_instrument.query("CALCulate:MARKer%s:STATe?" %itrac)).rstrip()

            markerBWOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe?" %itrac)).rstrip()
            if markerBWOnOff == "1":
                markerBWOnOff = "ON"
            elif markerBWOnOff == "0":
                markerBWOnOff = "OFF"

            noiseMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:NOISe:STATe?" %itrac)).rstrip()
            if noiseMarkOnOff == "1":
                noiseMarkOnOff = "ON"
            elif noiseMarkOnOff == "0":
                noiseMarkOnOff = "OFF"

            deltaMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:DELTa:STATe?" %itrac)).rstrip()
            if deltaMarkOnOff == "1":
                deltaMarkOnOff = "ON"
            elif deltaMarkOnOff == "0":
                deltaMarkOnOff = "OFF"

            osnrMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:OSNR:STATe?" %itrac)).rstrip()
            if osnrMarkOnOff == "1":
                osnrMarkOnOff = "ON"
            elif osnrMarkOnOff == "0":
                osnrMarkOnOff = "OFF"

            

            mkrTrc = str(my_instrument.query("CALCulate:MARKer%s:TRACe?" %itrac)).rstrip()

            if itrac == '1':
                mkr_1_param[3] = markerBWOnOff
                mkr_1_param[4] = noiseMarkOnOff
                mkr_1_param[5] = deltaMarkOnOff
                mkr_1_param[6] = osnrMarkOnOff
                mkr_1_param[7] = mkrTrc
            if itrac == '2':
                mkr_2_param[3] = markerBWOnOff
                mkr_2_param[4] = noiseMarkOnOff
                mkr_2_param[5] = deltaMarkOnOff
                mkr_2_param[6] = osnrMarkOnOff
                mkr_2_param[7] = mkrTrc
            if itrac == '3':
                mkr_3_param[3] = markerBWOnOff
                mkr_3_param[4] = noiseMarkOnOff
                mkr_3_param[5] = deltaMarkOnOff
                mkr_3_param[6] = osnrMarkOnOff
                mkr_3_param[7] = mkrTrc
            if itrac == '4':
                mkr_4_param[3] = markerBWOnOff
                mkr_4_param[4] = noiseMarkOnOff
                mkr_4_param[5] = deltaMarkOnOff
                mkr_4_param[6] = osnrMarkOnOff
                mkr_4_param[7] = mkrTrc

            if itrac == '1':
                mkr_1_param[0] = mkrOnOff
                self.mkr1Display()
            if itrac == '2':
                mkr_2_param[0] = mkrOnOff
                self.mkr2Display()
            if itrac == '3':
                mkr_3_param[0] = mkrOnOff
                self.mkr3Display()
            if itrac == '4':
                mkr_4_param[0] = mkrOnOff
                self.mkr4Display()

        global active_mkr_param
        active_mkr_param = [0, 0, 0, '0', '0', '0', '0', '0']
        global active_BW_param
        active_BW_param = [0, 0, 0, 0, 0, 0]

        if mkr_1_param[0] == '1':
            active_marker = '1'
        if mkr_2_param[0] == '1':
            active_marker = '2'
        if mkr_3_param[0] == '1':
            active_marker = '3'
        if mkr_4_param[0] == '1':
            active_marker = '4'

        if active_marker == '1':
            active_mkr_param = mkr_1_param
            self.mkr1Display()
        if active_marker == '2':
            active_mkr_param = mkr_2_param
            self.mkr2Display()
        if active_marker == '3':
            active_mkr_param = mkr_3_param
            self.mkr3Display()
        if active_marker == '4':
            active_mkr_param = mkr_4_param
            self.mkr4Display()

        print('mkr1: %s' %mkr_1_param)
        print('mkr2: %s' %mkr_2_param)
        print('mkr3: %s' %mkr_3_param)
        print('mkr4: %s' %mkr_4_param)


## ------------------------------------------
##              TRACE PARAMETERS
## ------------------------------------------

        global updateTraceOnOff
        global viewTraceOnOff
        global holdTraceNoneMinMax
        global averagingOnOff
        global trace_a_param
        global trace_b_param
        global trace_c_param
        global trace_d_param
        global trace_e_param
        global trace_f_param
        global trace_a_data
        global trace_b_data
        global trace_c_data
        global trace_d_data
        global trace_e_data
        global trace_f_data

        for i in range(1,7):
            if i == 1:
                itrac = "TRA"
            if i == 2:
                itrac = "TRB"
            if i == 3:
                itrac = "TRC"
            if i == 4:
                itrac = "TRD"
            if i == 5:
                itrac = "TRE"
            if i == 6:
                itrac = "TRF"
                
            updateTraceOnOff = str(my_instrument.query("TRACe:FEED:CONTrol? %s" %itrac)).rstrip()
            if updateTraceOnOff == "ALW":
                updateTraceOnOff = "ON"
            elif updateTraceOnOff == "NEV":
                updateTraceOnOff = "OFF"

            viewTraceOnOff = str(my_instrument.query("DISPlay:WINDow:TRACe:STATe? %s" %itrac)).rstrip()
            if viewTraceOnOff == "1":
                viewTraceOnOff = "ON"
            elif viewTraceOnOff == "0":
                viewTraceOnOff = "OFF"

            holdTraceMax = str(my_instrument.query("CALCulate%s:MAXimum:STATe?" %i)).rstrip()
            holdTraceMin = str(my_instrument.query("CALCulate%s:MINimum:STATe?" %i)).rstrip()
            if holdTraceMax == "1" and holdTraceMin == "0":
                holdTraceNoneMinMax = "MAX"
            elif holdTraceMax == "0" and holdTraceMin == "1":
                holdTraceNoneMinMax = "MIN"
            else:
                holdTraceNoneMinMax = "NONE"

            averagingOnOff = str(my_instrument.query("CALCulate%s:AVERage:STATe?" %i)).rstrip()
            if averagingOnOff == "1":
                averagingOnOff = "ON"
            elif averagingOnOff == "0":
                averagingOnOff = "OFF"

            if i == 1:
                trace_a_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_a_param)
            if i == 2:
                trace_b_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_b_param)
            if i == 3:
                trace_c_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_c_param)
            if i == 4:
                trace_d_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_d_param)
            if i == 5:
                trace_e_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_e_param)
            if i == 6:
                trace_f_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_f_param)

        active_trace = active_mkr_param[7]
        
        if active_trace == 'TRA':
            active_trace_num = '1'
        if active_trace == 'TRB':
            active_trace_num = '2'
        if active_trace == 'TRC':
            active_trace_num = '3'
        if active_trace == 'TRD':
            active_trace_num = '4'
        if active_trace == 'TRE':
            active_trace_num = '5'
        if active_trace == 'TRF':
            active_trace_num = '6'
            
        global active_trace_param
        if active_trace_num == '1':
            active_trace_param = trace_a_param
        if active_trace_num == '2':
            active_trace_param = trace_b_param
        if active_trace_num == '3':
            active_trace_param = trace_c_param
        if active_trace_num == '4':
            active_trace_param = trace_d_param
        if active_trace_num == '5':
            active_trace_param = trace_e_param
        if active_trace_num == '6':
            active_trace_param = trace_f_param

## ------------------------------------------
##              OTHER PARAMETERS
## ------------------------------------------

        global resBwManAuto
        resBwManAuto = str(my_instrument.query("SENSe:BANDwidth:RESolution:AUTO?")).rstrip()
        if resBwManAuto == "1":
            resBwManAuto = "AUTO"
        elif resBwManAuto == "0":
            resBwManAuto = "MAN"

        global vidBwManAuto
        vidBwManAuto = str(my_instrument.query("SENSe:BANDwidth:VIDeo:AUTO?")).rstrip()
        if vidBwManAuto == "1":
            vidBwManAuto = "AUTO"
        elif vidBwManAuto == "0":
            vidBwManAuto = "MAN"

        global sweepTimeManAuto
        sweepTimeManAuto = str(my_instrument.query("SENSe:SWEep:TIME:AUTO?")).rstrip()
        if sweepTimeManAuto == "1":
            sweepTimeManAuto = "AUTO"
        elif sweepTimeManAuto == "0":
            sweepTimeManAuto = "MAN"

        global repeatSweepOnOff
        repeatSweepOnOff = str(my_instrument.query("INITiate:CONTinuous?")).rstrip()
        if repeatSweepOnOff == "1":
            repeatSweepOnOff = "ON"
        elif repeatSweepOnOff == "0":
            repeatSweepOnOff = "OFF"

        global trigSyncLowHighPulse
        trigSyncLowHighPulse = str(my_instrument.query("TRIGger:OUTPut?")).rstrip()
        if trigSyncLowHighPulse == "ON":
            trigSyncLowHighPulse = "HIGH"
        elif trigSyncLowHighPulse == "OFF":
            trigSyncLowHighPulse = "LOW"
        elif trigSyncLowHighPulse == "AUTO":
            trigSyncLowHighPulse = "PULSE"

        global syncOutOnOff
        syncOutOnOff = str(my_instrument.query("TRIGger:OUTPut:PULSe:STATe?")).rstrip()
        if syncOutOnOff == "1":
            syncOutOnOff = "ON"
        elif syncOutOnOff == "0":
            syncOutOnOff = "OFF"

        global wavelengthOffset
        wavelengthOffset = str(ast.literal_eval(my_instrument.query("SENSe:WAVelength:OFFSet?")))
        wavelengthOffset = str(conversions.str2float(wavelengthOffset, '%s' %wavelength_units))
        
        global wavelengthStepSize
        wavelengthStepSize = str(my_instrument.query("SENse:WAVelength:CENTer:STEP:INCRement?"))
        wavelengthStepSize = str(conversions.str2float(wavelengthStepSize, "%s" %wavelength_units))

        global wavelengthRefIn
        wavelengthRefIn = str(my_instrument.query("SENSe:CORRection:RVELocity:MEDium?")).rstrip()

        global num_points
        num_points = str(my_instrument.query("SENSe:SWEep:POINts?")).rstrip()

        global Trigger_Mode
        Trigger_Mode = str(my_instrument.query("TRIGger:SOURce?")).rstrip()
        if Trigger_Mode == "INT":
            Trigger_Mode = str(my_instrument.query("TRIGger:SLOPe?")).rstrip()
            if Trigger_Mode == "POS":
                Trigger_Mode = "ADC+"
            elif Trigger_Mode == "NEG":
                Trigger_Mode = "ADC-"
            else:
                Trigger_Mode = "Internal"
        else:
            Trigger_Mode = "External"

        global Power_Calibration
        Power_Calibration = str(my_instrument.query("CALibration:POWer:STATe?")).rstrip()

        global auto_ranging
        auto_ranging = str(ast.literal_eval(my_instrument.query("SENSe:POWer:DC:RANGe:AUTO?")))

        global auto_zero
        auto_zero = str(ast.literal_eval(my_instrument.query("CALibration:ZERO:AUTO?")))

        global amplitude_correction
        amplitude_correction = str(ast.literal_eval(my_instrument.query("SENSe:CORRection:CSET?")))

        global amplitude_correction_mode
        amplitude_correction_mode = str(ast.literal_eval(my_instrument.query("SENSe:CORRection:STATe?")))

        global auto_chop
        auto_chop = str(ast.literal_eval(my_instrument.query("SENSe:CHOP:STATe?")))

    def mkr1Display(self):
        global mkr_1_param
        global BW_1_param
        global resBw
        global noiseMrkBW
        ## mkr_x_param = [ON/OFF, X, Y, BWOnOff, NoiseOnOff, DeltaOnOff, OSNROnOff, TRACE]
        if mkr_1_param[0] == "1":
            markerX = conversions.str2float(str(my_instrument.query("CALCulate:MARKer1:X?").rstrip()), mkr_units)
            markerY = float(my_instrument.query("CALCulate:MARKer1:Y?"))
            trc = mkr_1_param[7]
            self.topLabel11.setText("Mkr 1 (%s)" %trc[2])
            self.topLabel12.setText("%.2f %s" %(markerX, mkr_units))
            self.topLabel13.setText("%.2f %s" %(markerY, amplitude_units))
            if active_marker == "1":
                if mkr_1_param[3] == "ON": ## works apart from needing to find mrkBWY on start up
                    ## BW Marker
                    xL = str(my_instrument.query("CALCulate:MARKer1:FUNCtion:BANDwidth:X:LEFT?").rstrip())
                    BWxL = conversions.str2float(xL, BW_units)
                    xR = str(my_instrument.query("CALCulate:MARKer1:FUNCtion:BANDwidth:X:RIGHt?").rstrip())
                    BWxR = conversions.str2float(xR, BW_units)
                    xC = str(my_instrument.query("CALCulate:MARKer1:FUNCtion:BANDwidth:X:CENTer?").rstrip())
                    BWxC = conversions.str2float(xC, BW_units)
                    mkrBWY = conversions.str2float(my_instrument.query("CALCulate:MARKer1:FUNCtion:BANDwidth:NDB?"),amplitude_units)                                                        
                    BWyL = mkr_1_param[2] + mkrBWY
                    BWyR = mkr_1_param[2] + mkrBWY
                    BWdiff = abs(BWxL-BWxR)
                    self.topLabel21.setText("Mkr 1L")
                    self.topLabel22.setText("%.2f %s" %(BWxL, BW_units))
                    self.topLabel23.setText("%.2f %s" %(BWyL, amplitude_units))
                    self.topLabel31.setText("Mkr 1R")
                    self.topLabel32.setText("%.2f %s" %(BWxR, BW_units))
                    self.topLabel33.setText("%.2f %s" %(BWyR, amplitude_units))
                    self.topLabel41.setText("BW")
                    self.topLabel42.setText("%.2f %s" %(BWdiff, BW_units))
                    self.topLabel43.setText("%.2f %s" %(mkrBWY, amplitude_units))
                    self.topLabel51.setText("CWL")
                    self.topLabel52.setText("%.2f %s" %(BWxC, BW_units))
                    self.topLabel53.setText("")
                    self.clearTopText6()
                    BW_1_param = [BWxL, BWxR, BWxC, BWyL, BWyR, mkrBWY]
                elif mkr_1_param[4] == "ON": ## works
                    ## Noise Marker
                    self.topLabel11.setText("NMkr 1(%s)" %trc[2])
                    ratio = math.log10(float(resBw)/float(noiseMkrBW))
                    ratio = markerY - 10*ratio ## TODO: this value seems to be out slightly
                    self.topLabel13.setText("%.2f %s/%snm" %(ratio, amplitude_units, noiseMkrBW))
                    self.clearTopText3()
                    self.clearTopText4()
                    self.clearTopText5()
                    self.clearTopText6()
                elif mkr_1_param[5] == "ON":
                    ## Delta Marker
                    self.topLabel11.setText("Delta Mkr 1")
                    self.topLabel12.setText("%.2f %s" %(float(delta_distance),wavelength_units))
                    deltaY = abs(mkr_1_param[2]) - abs(markerY)
                    self.topLabel13.setText("%.2f %s" %(deltaY,amplitude_units))
                    self.topLabel21.setText("Mkr 1 Ref")
                    self.topLabel22.setText("%.2f %s" %(mkr_1_param[1],wavelength_units))
                    self.topLabel23.setText("%.2f %s" %(mkr_1_param[2],amplitude_units))
                    self.topLabel31.setText("Mkr 1(%s)" %active_trace[2])
                    self.topLabel32.setText("%.2f %s" %(markerX,wavelength_units))
                    self.topLabel33.setText("%.2f %s" %(markerY,amplitude_units))
                    self.clearTopText4()
                    self.clearTopText5()
                    self.clearTopText6()
                elif mkr_1_param[6] == "ON": ## works
                    ## OSNR Marker
                    OSNRx = conversions.str2float(str(my_instrument.query("CALCulate:MARKer1:FUNCtion:OSNR:X:CENTer?").rstrip()), mkr_units)
                    OSNRy = float(my_instrument.query("CALCulate:MARKer1:FUNCtion:OSNR:Y:CENTer?"))
                    OSNRVal = float(my_instrument.query("CALCulate:MARKer1:FUNCtion:OSNR:RESult?"))
                    OSNRVal = conversions.str2float(OSNRVal,amplitude_units)
                    self.clearTopText2()
                    self.topLabel31.setText("Center")
                    self.topLabel32.setText("%.2f %s" %(OSNRx, mkr_units))
                    self.topLabel33.setText("%.2f %s" %(OSNRy, amplitude_units))
                    self.clearTopText4()
                    self.topLabel51.setText("OSNR")
                    self.topLabel52.setText("%0.2f %s/%snm" %(OSNRVal, amplitude_units, noiseMkrBW))
                    self.topLabel53.setText("")
                    self.clearTopText6()
        else:
            markerX = 0
            markerY = 0
            self.topLabel11.setText("")
            self.topLabel12.setText("")
            self.topLabel13.setText("")
        mkr_1_param[1] = markerX
        mkr_1_param[2] = markerY


    def mkr2Display(self):
        global mkr_2_param
        global BW_2_param
        global resBw
        global noiseMrkBW
        ## mkr_x_param = [ON/OFF, X, Y, BWOnOff, NoiseOnOff, DeltaOnOff, OSNROnOff, TRACE]
        if mkr_2_param[0] == "1":
            markerX = conversions.str2float(str(my_instrument.query("CALCulate:MARKer2:X?").rstrip()), mkr_units)
            markerY = float(my_instrument.query("CALCulate:MARKer2:Y?"))
            trc = mkr_2_param[7]
            self.topLabel21.setText("Mkr 2 (%s)" %trc[2])
            self.topLabel22.setText("%.2f %s" %(markerX, mkr_units))
            self.topLabel23.setText("%.2f %s" %(markerY, amplitude_units))
            if active_marker == "2":
                if mkr_2_param[3] == "ON": ## works apart from needing to find mrkBWY on start up
                    ## BW Marker
                    xL = str(my_instrument.query("CALCulate:MARKer2:FUNCtion:BANDwidth:X:LEFT?").rstrip())
                    BWxL = conversions.str2float(xL, BW_units)
                    xR = str(my_instrument.query("CALCulate:MARKer2:FUNCtion:BANDwidth:X:RIGHt?").rstrip())
                    BWxR = conversions.str2float(xR, BW_units)
                    xC = str(my_instrument.query("CALCulate:MARKer2:FUNCtion:BANDwidth:X:CENTer?").rstrip())
                    BWxC = conversions.str2float(xC, BW_units)
                    mkrBWY = conversions.str2float(my_instrument.query("CALCulate:MARKer2:FUNCtion:BANDwidth:NDB?"),amplitude_units)                                                        
                    BWyL = mkr_2_param[2] + mkrBWY
                    BWyR = mkr_2_param[2] + mkrBWY
                    BWdiff = abs(BWxL-BWxR)
                    self.topLabel11.setText("Mkr 2 (%s)" %trc[2])
                    self.topLabel12.setText("%.2f %s" %(markerX, mkr_units))
                    self.topLabel13.setText("%.2f %s" %(markerY, amplitude_units))
                    self.topLabel21.setText("Mkr 2L")
                    self.topLabel22.setText("%.2f %s" %(BWxL, BW_units))
                    self.topLabel23.setText("%.2f %s" %(BWyL, amplitude_units))
                    self.topLabel31.setText("Mkr 2R")
                    self.topLabel32.setText("%.2f %s" %(BWxR, BW_units))
                    self.topLabel33.setText("%.2f %s" %(BWyR, amplitude_units))
                    self.topLabel41.setText("BW")
                    self.topLabel42.setText("%.2f %s" %(BWdiff, BW_units))
                    self.topLabel43.setText("%.2f %s" %(mkrBWY, amplitude_units))
                    self.topLabel51.setText("CWL")
                    self.topLabel52.setText("%.2f %s" %(BWxC, BW_units))
                    self.topLabel53.setText("")
                    self.clearTopText6()
                    BW_2_param = [BWxL, BWxR, BWxC, BWyL, BWyR, mkrBWY]
                elif mkr_2_param[4] == "ON": ## works
                    ## Noise Marker
                    self.topLabel11.setText("NMkr 2(%s)" %trc[2])
                    ratio = math.log10(float(resBw)/float(noiseMkrBW))
                    ratio = markerY - 10*ratio ## TODO: this value seems to be out slightly
                    self.topLabel13.setText("%.2f %s/%snm" %(ratio, amplitude_units, noiseMkrBW))
                    self.clearTopText3()
                    self.clearTopText4()
                    self.clearTopText5()
                    self.clearTopText6()
                elif mkr_2_param[5] == "ON":
                    ## Delta Marker
                    self.topLabel11.setText("Delta Mkr 2")
                    self.topLabel12.setText("%.2f %s" %(float(delta_distance),wavelength_units))
                    deltaY = abs(mkr_2_param[2]) - abs(markerY)
                    self.topLabel13.setText("%.2f %s" %(deltaY,amplitude_units))
                    self.topLabel21.setText("Mkr 2 Ref")
                    self.topLabel22.setText("%.2f %s" %(mkr_2_param[1],wavelength_units))
                    self.topLabel23.setText("%.2f %s" %(mkr_2_param[2],amplitude_units))
                    self.topLabel31.setText("Mkr 2(%s)" %active_trace[2])
                    self.topLabel32.setText("%.2f %s" %(markerX,wavelength_units))
                    self.topLabel33.setText("%.2f %s" %(markerY,amplitude_units))
                    self.clearTopText4()
                    self.clearTopText5()
                    self.clearTopText6()
                elif mkr_2_param[6] == "ON": ## works
                    ## OSNR Marker
                    OSNRx = conversions.str2float(str(my_instrument.query("CALCulate:MARKer2:FUNCtion:OSNR:X:CENTer?").rstrip()), mkr_units)
                    OSNRy = float(my_instrument.query("CALCulate:MARKer2:FUNCtion:OSNR:Y:CENTer?"))
                    OSNRVal = float(my_instrument.query("CALCulate:MARKer2:FUNCtion:OSNR:RESult?"))
                    OSNRVal = conversions.str2float(OSNRVal,amplitude_units)
                    self.clearTopText2()
                    self.topLabel31.setText("Center")
                    self.topLabel32.setText("%.2f %s" %(OSNRx, mkr_units))
                    self.topLabel33.setText("%.2f %s" %(OSNRy, amplitude_units))
                    self.clearTopText4()
                    self.topLabel51.setText("OSNR")
                    self.topLabel52.setText("%0.2f %s/%snm" %(OSNRVal, amplitude_units, noiseMkrBW))
                    self.topLabel53.setText("")
                    self.clearTopText6()
        else:
            markerX = 0
            markerY = 0
            self.topLabel21.setText("")
            self.topLabel22.setText("")
            self.topLabel23.setText("")
        mkr_2_param[1] = markerX
        mkr_2_param[2] = markerY
        

    def mkr3Display(self):
        global mkr_3_param
        global BW_3_param
        global resBw
        global noiseMrkBW
        ## mkr_x_param = [ON/OFF, X, Y, BWOnOff, NoiseOnOff, DeltaOnOff, OSNROnOff, TRACE]
        if mkr_3_param[0] == "1":
            markerX = conversions.str2float(str(my_instrument.query("CALCulate:MARKer3:X?").rstrip()), mkr_units)
            markerY = float(my_instrument.query("CALCulate:MARKer3:Y?"))
            trc = mkr_3_param[7]
            self.topLabel41.setText("Mkr 3 (%s)" %trc[2])
            self.topLabel42.setText("%.2f %s" %(markerX, mkr_units))
            self.topLabel43.setText("%.2f %s" %(markerY, amplitude_units))
            if active_marker == "3":
                if mkr_3_param[3] == "ON": ## works apart from needing to find mrkBWY on start up
                    ## BW Marker
                    xL = str(my_instrument.query("CALCulate:MARKer3:FUNCtion:BANDwidth:X:LEFT?").rstrip())
                    BWxL = conversions.str2float(xL, BW_units)
                    xR = str(my_instrument.query("CALCulate:MARKer3:FUNCtion:BANDwidth:X:RIGHt?").rstrip())
                    BWxR = conversions.str2float(xR, BW_units)
                    xC = str(my_instrument.query("CALCulate:MARKer3:FUNCtion:BANDwidth:X:CENTer?").rstrip())
                    BWxC = conversions.str2float(xC, BW_units)
                    mkrBWY = conversions.str2float(my_instrument.query("CALCulate:MARKer3:FUNCtion:BANDwidth:NDB?"),amplitude_units)                                                        
                    BWyL = mkr_3_param[2] + mkrBWY
                    BWyR = mkr_3_param[2] + mkrBWY
                    BWdiff = abs(BWxL-BWxR)
                    self.topLabel11.setText("Mkr 3 (%s)" %trc[2])
                    self.topLabel12.setText("%.2f %s" %(markerX, mkr_units))
                    self.topLabel13.setText("%.2f %s" %(markerY, amplitude_units))
                    self.topLabel21.setText("Mkr 3L")
                    self.topLabel22.setText("%.2f %s" %(BWxL, BW_units))
                    self.topLabel23.setText("%.2f %s" %(BWyL, amplitude_units))
                    self.topLabel31.setText("Mkr 3R")
                    self.topLabel32.setText("%.2f %s" %(BWxR, BW_units))
                    self.topLabel33.setText("%.2f %s" %(BWyR, amplitude_units))
                    self.topLabel41.setText("BW")
                    self.topLabel42.setText("%.2f %s" %(BWdiff, BW_units))
                    self.topLabel43.setText("%.2f %s" %(mkrBWY, amplitude_units))
                    self.topLabel51.setText("CWL")
                    self.topLabel52.setText("%.2f %s" %(BWxC, BW_units))
                    self.topLabel53.setText("")
                    self.clearTopText6()
                    BW_3_param = [BWxL, BWxR, BWxC, BWyL, BWyR, mkrBWY]
                elif mkr_3_param[4] == "ON": ## works
                    ## Noise Marker
                    self.topLabel11.setText("NMkr 3(%s)" %trc[2])
                    ratio = math.log10(float(resBw)/float(noiseMkrBW))
                    ratio = markerY - 10*ratio ## TODO: this value seems to be out slightly
                    self.topLabel13.setText("%.2f %s/%snm" %(ratio, amplitude_units, noiseMkrBW))
                    self.clearTopText3()
                    self.clearTopText4()
                    self.clearTopText5()
                    self.clearTopText6()
                elif mkr_3_param[5] == "ON":
                    ## Delta Marker
                    self.topLabel11.setText("Delta Mkr 3")
                    self.topLabel12.setText("%.2f %s" %(float(delta_distance),wavelength_units))
                    deltaY = abs(mkr_3_param[2]) - abs(markerY)
                    self.topLabel13.setText("%.2f %s" %(deltaY,amplitude_units))
                    self.topLabel21.setText("Mkr 3 Ref")
                    self.topLabel22.setText("%.2f %s" %(mkr_3_param[1],wavelength_units))
                    self.topLabel23.setText("%.2f %s" %(mkr_3_param[2],amplitude_units))
                    self.topLabel31.setText("Mkr 3(%s)" %active_trace[2])
                    self.topLabel32.setText("%.2f %s" %(markerX,wavelength_units))
                    self.topLabel33.setText("%.2f %s" %(markerY,amplitude_units))
                    self.clearTopText4()
                    self.clearTopText5()
                    self.clearTopText6()
                elif mkr_3_param[6] == "ON": ## works
                    ## OSNR Marker
                    OSNRx = conversions.str2float(str(my_instrument.query("CALCulate:MARKer3:FUNCtion:OSNR:X:CENTer?").rstrip()), mkr_units)
                    OSNRy = float(my_instrument.query("CALCulate:MARKer3:FUNCtion:OSNR:Y:CENTer?"))
                    OSNRVal = float(my_instrument.query("CALCulate:MARKer3:FUNCtion:OSNR:RESult?"))
                    OSNRVal = conversions.str2float(OSNRVal,amplitude_units)
                    self.clearTopText2()
                    self.topLabel31.setText("Center")
                    self.topLabel32.setText("%.2f %s" %(OSNRx, mkr_units))
                    self.topLabel33.setText("%.2f %s" %(OSNRy, amplitude_units))
                    self.clearTopText4()
                    self.topLabel51.setText("OSNR")
                    self.topLabel52.setText("%0.2f %s/%snm" %(OSNRVal, amplitude_units, noiseMkrBW))
                    self.topLabel53.setText("")
                    self.clearTopText6()
        else:
            markerX = 0
            markerY = 0
            self.topLabel41.setText("")
            self.topLabel42.setText("")
            self.topLabel43.setText("")
        mkr_3_param[1] = markerX
        mkr_3_param[2] = markerY


    def mkr4Display(self):
        global mkr_4_param
        global BW_4_param
        global resBw
        global noiseMrkBW
        ## mkr_x_param = [ON/OFF, X, Y, BWOnOff, NoiseOnOff, DeltaOnOff, OSNROnOff, TRACE]
        if mkr_4_param[0] == "1":
            markerX = conversions.str2float(str(my_instrument.query("CALCulate:MARKer4:X?").rstrip()), mkr_units)
            markerY = float(my_instrument.query("CALCulate:MARKer4:Y?"))
            trc = mkr_4_param[7]
            self.topLabel51.setText("Mkr 4 (%s)" %trc[2])
            self.topLabel52.setText("%.2f %s" %(markerX, mkr_units))
            self.topLabel53.setText("%.2f %s" %(markerY, amplitude_units))
            if active_marker == "4":
                if mkr_4_param[3] == "ON": ## works apart from needing to find mrkBWY on start up
                    ## BW Marker
                    xL = str(my_instrument.query("CALCulate:MARKer4:FUNCtion:BANDwidth:X:LEFT?").rstrip())
                    BWxL = conversions.str2float(xL, BW_units)
                    xR = str(my_instrument.query("CALCulate:MARKer4:FUNCtion:BANDwidth:X:RIGHt?").rstrip())
                    BWxR = conversions.str2float(xR, BW_units)
                    xC = str(my_instrument.query("CALCulate:MARKer4:FUNCtion:BANDwidth:X:CENTer?").rstrip())
                    BWxC = conversions.str2float(xC, BW_units)
                    mkrBWY = conversions.str2float(my_instrument.query("CALCulate:MARKer4:FUNCtion:BANDwidth:NDB?"),amplitude_units)                                                        
                    BWyL = mkr_4_param[2] + mkrBWY
                    BWyR = mkr_4_param[2] + mkrBWY
                    BWdiff = abs(BWxL-BWxR)
                    self.topLabel11.setText("Mkr 4 (%s)" %trc[2])
                    self.topLabel12.setText("%.2f %s" %(markerX, mkr_units))
                    self.topLabel13.setText("%.2f %s" %(markerY, amplitude_units))
                    self.topLabel21.setText("Mkr 4L")
                    self.topLabel22.setText("%.2f %s" %(BWxL, BW_units))
                    self.topLabel23.setText("%.2f %s" %(BWyL, amplitude_units))
                    self.topLabel31.setText("Mkr 4R")
                    self.topLabel32.setText("%.2f %s" %(BWxR, BW_units))
                    self.topLabel33.setText("%.2f %s" %(BWyR, amplitude_units))
                    self.topLabel41.setText("BW")
                    self.topLabel42.setText("%.2f %s" %(BWdiff, BW_units))
                    self.topLabel43.setText("%.2f %s" %(mkrBWY, amplitude_units))
                    self.topLabel51.setText("CWL")
                    self.topLabel52.setText("%.2f %s" %(BWxC, BW_units))
                    self.topLabel53.setText("")
                    self.clearTopText6()
                    BW_4_param = [BWxL, BWxR, BWxC, BWyL, BWyR, mkrBWY]
                elif mkr_4_param[4] == "ON": ## works
                    ## Noise Marker
                    self.topLabel11.setText("NMkr 4(%s)" %trc[2])
                    ratio = math.log10(float(resBw)/float(noiseMkrBW))
                    ratio = markerY - 10*ratio ## TODO: this value seems to be out slightly
                    self.topLabel13.setText("%.2f %s/%snm" %(ratio, amplitude_units, noiseMkrBW))
                    self.clearTopText3()
                    self.clearTopText4()
                    self.clearTopText5()
                    self.clearTopText6()
                elif mkr_4_param[5] == "ON":
                    ## Delta Marker
                    self.topLabel11.setText("Delta Mkr 4")
                    self.topLabel12.setText("%.2f %s" %(float(delta_distance),wavelength_units))
                    deltaY = abs(mkr_4_param[2]) - abs(markerY)
                    self.topLabel13.setText("%.2f %s" %(deltaY,amplitude_units))
                    self.topLabel21.setText("Mkr 4 Ref")
                    self.topLabel22.setText("%.2f %s" %(mkr_4_param[1],wavelength_units))
                    self.topLabel23.setText("%.2f %s" %(mkr_4_param[2],amplitude_units))
                    self.topLabel31.setText("Mkr 4(%s)" %active_trace[2])
                    self.topLabel32.setText("%.2f %s" %(markerX,wavelength_units))
                    self.topLabel33.setText("%.2f %s" %(markerY,amplitude_units))
                    self.clearTopText4()
                    self.clearTopText5()
                    self.clearTopText6()
                elif mkr_4_param[6] == "ON": ## works
                    ## OSNR Marker
                    OSNRx = conversions.str2float(str(my_instrument.query("CALCulate:MARKer4:FUNCtion:OSNR:X:CENTer?").rstrip()), mkr_units)
                    OSNRy = float(my_instrument.query("CALCulate:MARKer4:FUNCtion:OSNR:Y:CENTer?"))
                    OSNRVal = float(my_instrument.query("CALCulate:MARKer4:FUNCtion:OSNR:RESult?"))
                    OSNRVal = conversions.str2float(OSNRVal,amplitude_units)
                    self.clearTopText2()
                    self.topLabel31.setText("Center")
                    self.topLabel32.setText("%.2f %s" %(OSNRx, mkr_units))
                    self.topLabel33.setText("%.2f %s" %(OSNRy, amplitude_units))
                    self.clearTopText4()
                    self.topLabel51.setText("OSNR")
                    self.topLabel52.setText("%0.2f %s/%snm" %(OSNRVal, amplitude_units, noiseMkrBW))
                    self.topLabel53.setText("")
                    self.clearTopText6()
        else:
            markerX = 0
            markerY = 0
            self.topLabel51.setText("")
            self.topLabel52.setText("")
            self.topLabel53.setText("")
        mkr_4_param[1] = markerX
        mkr_4_param[2] = markerY


    def mkrCompDisplay(self):
        global mkr_1_param
        global mkr_2_param
        global mkr_3_param
        global mkr_4_param

        if mkr_1_param[0] == "1":
            if mkr_2_param[0] == "1":
                self.topLabel31.setText("Mkr 2-1")
                markerDiffWL = mkr_2_param[1]-mkr_1_param[1]
                markerDiffAmp = mkr_2_param[2]-mkr_1_param[2]
                self.topLabel32.setText("%.2f %s" %(markerDiffWL,wavelength_units))
                self.topLabel33.setText("%.2f %s" %(markerDiffAmp,amplitude_units))
            else:
                self.topLabel31.setText("")
                self.topLabel32.setText("")
                self.topLabel33.setText("")
        else:
            self.topLabel31.setText("")
            self.topLabel32.setText("")
            self.topLabel33.setText("")

        if mkr_3_param[0] == "1":
            if mkr_4_param[0] == "1":
                self.topLabel61.setText("Mkr 4-3")
                markerDiffWL = mkr_4_param[1]-mkr_3_param[1]
                markerDiffAmp = mkr_4_param[2]-mkr_3_param[2]
                self.topLabel62.setText("%.2f %s" %(markerDiffWL,wavelength_units))
                self.topLabel63.setText("%.2f %s" %(markerDiffAmp,amplitude_units))
            else:
                self.topLabel61.setText("")
                self.topLabel62.setText("")
                self.topLabel63.setText("")
        else:
            self.topLabel61.setText("")
            self.topLabel62.setText("")
            self.topLabel63.setText("")

    def infoDisplay(self):
        self.btmLabel21.setText("%.2f %s" %(resBw, wavelength_units))

        global vidBw
        value = my_instrument.query("SENSe:BANDwidth:VIDeo?")
        vidBw = conversions.str2float(value,"%s" %frequency_units)
        self.btmLabel22.setText("%.2f %s" %(vidBw, frequency_units))

        global sensitivity
        value = str(my_instrument.query("SENSe:POWer:DC:RANGe:LOWer?"))
        sensitivity = float(value)
        self.btmLabel41.setText("%.2f dBm" %sensitivity)

        global sweepTime
        value = my_instrument.query("SENSe:SWEep:TIME?")
        sweepTime = float(value)
        self.btmLabel42.setText("%.3f s" %sweepTime)

        self.btmLabel61.setText("%s" %wavelengthRefIn)
        self.btmLabel62.setText("%s" %active_trace_param[3])

   
    ## Function to clear sub-menu ready to add next menu
    def clearLayout(self, layout):
        if layout != None:
            while layout.count():
                child = layout.takeAt(0)
                if child.widget() is not None:
                    child.widget().deleteLater()
                elif child.layout() is not None:
                    clearLayout(child.layout())

    ## Wavelength sub-menu
    ## The wavelength menu buttons are defined here. On click the
    ## buttons will load the associated function from below
    def wavelengthMenu(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonCenterWL = QtWidgets.QPushButton("Center WL", self)
        self.subButtonLayout.addWidget(self.buttonCenterWL)
        self.buttonSpan = QtWidgets.QPushButton("Span", self)
        self.subButtonLayout.addWidget(self.buttonSpan)
        self.buttonStartWL = QtWidgets.QPushButton("Start WL", self)
        self.subButtonLayout.addWidget(self.buttonStartWL)
        self.buttonStopWL = QtWidgets.QPushButton("Stop WL", self)
        self.subButtonLayout.addWidget(self.buttonStopWL)
        self.buttonPeakToCenter = QtWidgets.QPushButton("Peak To Center", self)
        self.subButtonLayout.addWidget(self.buttonPeakToCenter)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonWavelengthSetup = QtWidgets.QPushButton("Wavelength Setup", self)
        self.subButtonLayout.addWidget(self.buttonWavelengthSetup)

        self.buttonCenterWL.clicked.connect(self.centerWL)
        self.buttonSpan.clicked.connect(self.span)
        self.buttonStartWL.clicked.connect(self.startWL)
        self.buttonStopWL.clicked.connect(self.stopWL)
        self.buttonPeakToCenter.clicked.connect(self.peakToCenter)
        self.buttonWavelengthSetup.clicked.connect(self.wavelengthSetupWindow)
        

    def centerWL(self): ## works
        value = my_instrument.query("SENSe:WAVelength:CENTer?")
        current_value = str(conversions.str2float(value,"%s"%wavelength_units))
        widget = InputDialog("Center WL", "%s" %wavelength_units, current_value) 
        widget.exec_()
        sweep = 0
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:CENTer " + "%s%s" %(widget.userInput,wavelength_units)
            my_instrument.write(wavelength)
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        
    def span(self): ## works
        value = my_instrument.query("SENSe:WAVelength:SPAN?")
        current_value = str(conversions.str2float(value,"%s"%wavelength_units))
        widget = InputDialog("Span", "%s" %wavelength_units, current_value)
        widget.exec_()
        sweep = 0
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:SPAN " + "%s%s" %(widget.userInput,wavelength_units)
            my_instrument.write(wavelength)
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def startWL(self): ## works
        value = my_instrument.query("SENSe:WAVelength:STARt?")
        current_value = str(conversions.str2float(value,"%s" %wavelength_units))
        widget = InputDialog("Start WL", "%s" %wavelength_units, current_value)
        widget.exec_()
        sweep = 0
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:STARt " + "%s%s" %(widget.userInput,wavelength_units)
            my_instrument.write(wavelength)
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def stopWL(self): ## works
        value = my_instrument.query("SENSe:WAVelength:STOP?")
        current_value = str(conversions.str2float(value,"%s" %wavelength_units))
        widget = InputDialog("Stop WL", "%s" %wavelength_units, current_value)
        widget.exec_()
        sweep = 0
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:STOP " + "%s%s" %(widget.userInput,wavelength_units)
            my_instrument.write(wavelength)
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def peakToCenter(self): ## works
        my_instrument.write("CALCulate:MARK:SCENter")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def wavelengthSetupWindow(self): ## works
        widget = WavelengthSetup(parent=self)
        widget.exec_()

    # Amplitude sub-menu
    def amplitudeMenu(self): ## TODO: fix amplitude units when log/lin
        self.clearLayout(self.subButtonLayout)
        global logLin    
        global autoMan
        global traceIntOnOff
        self.buttonRefLvl = QtWidgets.QPushButton("Reference Level", self)
        self.subButtonLayout.addWidget(self.buttonRefLvl)
        self.buttonScaleDiv = QtWidgets.QPushButton("Scale/Div", self)
        self.subButtonLayout.addWidget(self.buttonScaleDiv)
        self.buttonDispMode = QtWidgets.QPushButton("Display Mode [%s]" %logLin, self)
        self.menuDispMode = QtWidgets.QMenu()
        self.menuDispMode.addAction("LOG", self.DispModeAction1)
        self.menuDispMode.addAction("LIN", self.DispModeAction2)
        self.buttonDispMode.setMenu(self.menuDispMode)
        self.subButtonLayout.addWidget(self.buttonDispMode)
        self.buttonSensitivity = QtWidgets.QPushButton("Sensitivity [%s]" %autoMan, self)
        self.menuSensitivity = QtWidgets.QMenu()
        self.menuSensitivity.addAction("AUTO", self.SensitivityAction1)
        self.menuSensitivity.addAction("MAN", self.SensitivityAction2)
        self.buttonSensitivity.setMenu(self.menuSensitivity)
        self.subButtonLayout.addWidget(self.buttonSensitivity)
        self.buttonPeakToRefLvl = QtWidgets.QPushButton("Peak To Ref Level", self)
        self.subButtonLayout.addWidget(self.buttonPeakToRefLvl)
        self.buttonTraceInteg = QtWidgets.QPushButton("Trace Integ [%s]" %traceIntOnOff, self)
        self.menuTraceInteg = QtWidgets.QMenu()
        self.menuTraceInteg.addAction("On", self.TraceIntegAction1)
        self.menuTraceInteg.addAction("Off", self.TraceIntegAction2)
        self.buttonTraceInteg.setMenu(self.menuTraceInteg)
        self.subButtonLayout.addWidget(self.buttonTraceInteg)
        self.buttonAmplitudeSetup = QtWidgets.QPushButton("Amplitude Setup", self)
        self.subButtonLayout.addWidget(self.buttonAmplitudeSetup)

        self.buttonRefLvl.clicked.connect(self.refLVL)
        self.buttonScaleDiv.clicked.connect(self.scaleDiv)
        self.buttonPeakToRefLvl.clicked.connect(self.peakToRefLvl)
        self.buttonAmplitudeSetup.clicked.connect(self.amplitudeSetupWindow)

    def refLVL(self): 
        value = my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:RLEVel?")
        current_value = str(conversions.str2float(value,"%s" %amplitude_units))
        widget = InputDialog("Reference Level", "%s" %amplitude_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            level = "DISPlay:WINDow:TRACe:Y:SCALe:RLEVel " + "%sdBm" %widget.userInput
            my_instrument.write(level)
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def scaleDiv(self): ## works
        global amplitude_units
        value = my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:PDIVision?")
        current_value = str(conversions.str2float(value,"%s" %amplitude_units))
        widget = InputDialog("Scale/Div", "%s" %amplitude_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            scale = "DISPlay:WINDow:TRACe:Y:SCALe:PDIVision " + "%s%s" %(widget.userInput,amplitude_units)
            my_instrument.write(scale)
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def DispModeAction1(self): ## works
        self.buttonDispMode.setText("Display Mode [LOG]")
        my_instrument.write("DISPlay:WINDow:TRACe:Y:SCALe:SPACing LOG")
        amplitude_units = str(my_instrument.query("UNIT:POW?")).rstrip()
        if amplitude_units == 'AUTO':
                amplitude_units = 'dB'
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def DispModeAction2(self): ## works
        self.buttonDispMode.setText("Display Mode [LIN]")
        my_instrument.write("DISPlay:WINDow:TRACe:Y:SCALe:SPACing LIN")
        amplitude_units = str(my_instrument.query("UNIT:POW?")).rstrip()
        if amplitude_units == 'AUTO':
            amplitude_units = 'W'
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)    
            
    def SensitivityAction1(self): ## works
        self.buttonSensitivity.setText("Sensitivity [AUTO]")
        my_instrument.write("SENSe:POWer:DC:RANGe:LOWer:AUTO ON")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        autoMan = 'AUTO'
                
    def SensitivityAction2(self): ## works
        global sensitivity
        sensitivity = str(my_instrument.query("SENSe:POWer:DC:RANGe:LOWer?"))
        widget = InputDialog("Sensitivity", "%s" %amplitude_units, sensitivity)
        widget.exec_()
        if widget.userInput != 0:
            my_instrument.write("SENSe:POWer:DC:RANGe:LOWer:AUTO OFF")
            sensitivityStr = "SENSe:POWer:DC:RANGe:LOWer " + "%s%s" %(widget.userInput,amplitude_units) #may be wavelength units)
            my_instrument.write(sensitivityStr)
            self.buttonSensitivity.setText("Sensitivity [MAN]")
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
            autoMan = 'MAN'     

    def peakToRefLvl(self): ## works
        my_instrument.write("CALCulate:MARKer:SRLevel")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def TraceIntegAction1(self):
        self.buttonTraceInteg.setText("Trace Integ [ON]")
        my_instrument.write("CALCulate%s:TPOWer:STATe ON" %active_trace_num)
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        traceIntOnOff = 'ON'

    def TraceIntegAction2(self): ## works
        self.buttonTraceInteg.setText("Trace Integ [OFF]")
        my_instrument.write("CALCulate%s:TPOWer:STATe OFF" %active_trace_num)
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        traceIntOnOff = 'OFF'

    def amplitudeSetupWindow(self): ## works
        widget = AmplitudeSetup()
        widget.exec_()

    # Markers sub-menu
    def markersMenu(self):
        global menuFlag
        menuFlag = 1

        self.clearLayout(self.subButtonLayout)    

        self.buttonActMrks = QtWidgets.QPushButton("Displayed Markers", self)
        self.subButtonLayout.addWidget(self.buttonActMrks)
        self.buttonPeakSrch = QtWidgets.QPushButton("Peak Search", self)
        self.subButtonLayout.addWidget(self.buttonPeakSrch)
        self.buttonMkrToCen = QtWidgets.QPushButton("Marker %s to Center" %active_marker, self)
        self.subButtonLayout.addWidget(self.buttonMkrToCen)
        self.buttonMkrToRefLvl = QtWidgets.QPushButton("Marker %s To Ref Level" %active_marker, self)
        self.subButtonLayout.addWidget(self.buttonMkrToRefLvl)
        self.buttonMkrSetup = QtWidgets.QPushButton("Marker Setup", self)
        self.subButtonLayout.addWidget(self.buttonMkrSetup)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonMoreMkrFunc = QtWidgets.QPushButton("More Marker Functons", self)
        self.subButtonLayout.addWidget(self.buttonMoreMkrFunc)

        self.buttonActMrks.clicked.connect(self.actMrks)
        self.buttonPeakSrch.clicked.connect(self.peakSrch)
        self.buttonMkrToCen.clicked.connect(self.mrkToCen)
        self.buttonMkrToRefLvl.clicked.connect(self.mkrToRefLvl)
        self.buttonMkrSetup.clicked.connect(self.mkrSetup)
        self.buttonMoreMkrFunc.clicked.connect(self.moreMkrFunc)

    def actMrks(self):
        widget = ActiveMarkersWindow()
        widget.exec_()
        if widget.markerReturn == 1:
            self.mkr1Display()
            self.mkr2Display()
            self.mkr3Display()
            self.mkr4Display()
            self.mkrCompDisplay()
            self.buttonActMkrGbl.setText("Mkr %s" %active_marker)
            self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)

    def peakSrch(self):  ## works
        # no sweep
        my_instrument.write("CALCulate:MARKer%s:MAXimum" %active_marker)
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def mrkToCen(self): ## works
        # no sweep
        my_instrument.write("CALCulate:MARKer%s:SCENter" %active_marker)
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def mkrToRefLvl(self): ## works
        # no sweep
        my_instrument.write("CALCulate:MARKer%s:SRLevel" %active_marker)
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def mkrSetup(self):
        widget = MarkerSetup("%s" %active_marker)
        widget.exec_()
        self.threshPlot()
        

    def moreMkrFunc(self):
        global menuFlag
        menuFlag = 2

        self.clearLayout(self.subButtonLayout)    

        self.buttonMkrSrchMenu = QtWidgets.QPushButton("Marker Search Menu", self)
        self.subButtonLayout.addWidget(self.buttonMkrSrchMenu)
        self.buttonMkrBW = QtWidgets.QPushButton("Marker %s Bandwidth [%s]" %(active_marker, active_mkr_param[3]), self)
        self.buttonMkrBW.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonMkrBW)
        self.buttonNoiseMkr = QtWidgets.QPushButton("Noise Marker %s [%s]" %(active_marker, active_mkr_param[4]), self)
        self.buttonNoiseMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonNoiseMkr)
        self.buttonDeltaMkr = QtWidgets.QPushButton("Delta Marker %s [%s]" %(active_marker, active_mkr_param[5]), self)
        self.buttonDeltaMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonDeltaMkr)
        self.buttonOSNRMkr = QtWidgets.QPushButton("OSNR Marker %s [%s]" %(active_marker, active_mkr_param[6]), self)
        self.buttonOSNRMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonOSNRMkr)
        self.buttonLineMkrMenu = QtWidgets.QPushButton("Line Marker Menu", self)
        self.subButtonLayout.addWidget(self.buttonLineMkrMenu)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonMkrSrchMenu.clicked.connect(self.mkrSrchMenu)
        self.buttonMkrBW.clicked.connect(self.mkrBWOnOff)
        self.buttonNoiseMkr.clicked.connect(self.noiseMkr)
        self.buttonDeltaMkr.clicked.connect(self.deltaMkr)
        self.buttonOSNRMkr.clicked.connect(self.OSNRMkr)
        self.buttonLineMkrMenu.clicked.connect(self.lineMkrMenu)
        self.buttonPrevMenu.clicked.connect(self.markersMenu)

    def mkrSrchMenu(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonSrchMode = QtWidgets.QPushButton("Search Mode [%s]" %peakPit, self)
        self.buttonSrchMode.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonSrchMode)
        self.buttonPeakSrch = QtWidgets.QPushButton("%s Search" %peakPit, self)
        self.subButtonLayout.addWidget(self.buttonPeakSrch)
        self.buttonNextPeakDown = QtWidgets.QPushButton("Next %s %s" %(peakPit,upDown), self)
        self.subButtonLayout.addWidget(self.buttonNextPeakDown)
        self.buttonNextPeakLeft = QtWidgets.QPushButton("Next %s Left" %peakPit, self)
        self.subButtonLayout.addWidget(self.buttonNextPeakLeft)
        self.buttonNextPeakRight = QtWidgets.QPushButton("Next %s Right" %peakPit, self)
        self.subButtonLayout.addWidget(self.buttonNextPeakRight)
        self.buttonActMrks = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonActMrks)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonSrchMode.clicked.connect(self.srchMode)
        self.buttonPeakSrch.clicked.connect(self.peakSrch)
        self.buttonNextPeakDown.clicked.connect(self.nextDown)
        self.buttonNextPeakLeft.clicked.connect(self.nextLeft)
        self.buttonNextPeakRight.clicked.connect(self.nextRight)
        self.buttonPrevMenu.clicked.connect(self.moreMkrFunc)

    def srchMode(self): ## works
        global peakPit
        global upDown
        if peakPit == "PEAK":
            upDown = "Up"
            self.buttonSrchMode.setText("Search Mode [PIT]")
            self.buttonPeakSrch.setText("Pit Search")
            self.buttonNextPeakDown.setText("Next Pit Up")
            self.buttonNextPeakLeft.setText("Next Pit Left")
            self.buttonNextPeakRight.setText("Next Pit Right")
            peakPit = "PIT"
        elif peakPit == "PIT":
            upDown = "Down"
            self.buttonSrchMode.setText("Search Mode [PEAK]")
            self.buttonPeakSrch.setText("Peak Search")
            self.buttonNextPeakDown.setText("Next Peak Down")
            self.buttonNextPeakLeft.setText("Next Peak Left")
            self.buttonNextPeakRight.setText("Next Peak Right")
            peakPit = "PEAK"

    def peakSrch(self): ## works
        # no sweep
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX" %active_marker)
            self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN" %active_marker)
            self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)

    def nextDown(self): ## works
        # no sweep
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX:NEXT" %active_marker)
            self.markerDisplay(self, active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN:NEXT" %active_marker)
            self.markerDisplay(self, active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
            
    def nextLeft(self): ## works
        # no sweep
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX:LEFT" %active_marker)
            self.markerDisplay(self, active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN:LEFT" %active_marker)
            self.markerDisplay(self, active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)

    def nextRight(self): ## works
        # no sweep
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX:RIGH" %active_marker)
            self.markerDisplay(self, active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN:RIGH" %active_marker)
            self.markerDisplay(self, active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        
    def mkrBWOnOff(self): ## works
        # no sweep
        global mrkBWY
        markerBWOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe?" %active_marker)).rstrip()
        if markerBWOnOff == "1":
            self.buttonMkrBW.setText("Marker %s Bandwidth [OFF]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe OFF" %active_marker)
            active_mkr_param[3] = 'OFF'
            self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        elif markerBWOnOff == "0":
            self.buttonMkrBW.setText("Marker %s Bandwidth [ON]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe ON" %active_marker)
            widget = InputDialog("Marker BW", "dB", str(active_BW_param[5]))
            widget.exec_()
            if widget.userInput != 0:
                active_BW_param[5] = widget.userInput
                bw = "CALC:MARK%s:FUNC:BAND:NDB " %active_marker + "%sdB" %widget.userInput
                active_mkr_param[3] = 'ON'
                my_instrument.write(bw)
                self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        self.updateMkrParam()
        self.mkr1Display()
        self.mkr2Display()
        self.mkr3Display()
        self.mkr4Display()
        self.mkrCompDisplay()
        if active_marker == '1':
            self.mkr1Display()
        if active_marker == '2':
            self.mkr2Display()
        if active_marker == '3':
            self.mkr3Display()
        if active_marker == '4':
            self.mkr4Display()
                
    def noiseMkr(self): ## works
        # no sweep
        noiseMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:NOISe:STATe?" %active_marker)).rstrip()
        if noiseMarkOnOff == "1":
            self.buttonNoiseMkr.setText("Noise Marker %s [OFF]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:NOISe:STATe OFF" %active_marker)
            active_mkr_param[4] = 'OFF'
            self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
            ## NEW FUNCTION THAT DOESN'T DO EXTRA MARKERS
        elif noiseMarkOnOff == "0":
            self.buttonNoiseMkr.setText("Noise Marker %s [ON]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:NOISe:STATe ON" %active_marker)
            active_mkr_param[4] = 'ON'
            self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
            if active_marker == '1':
                self.mkr1Display()
            if active_marker == '2':
                self.mkr2Display()
            if active_marker == '3':
                self.mkr3Display()
            if active_marker == '4':
                self.mkr4Display()
        self.updateMkrParam()

    def deltaMkr(self): ## works
        # no sweep
        deltaMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:DELTa:STATe?" %active_marker)).rstrip()
        if deltaMarkOnOff == "1":
            self.buttonDeltaMkr.setText("Delta Marker %s [OFF]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:DELTa:STATe OFF" %active_marker)
            active_mkr_param[5] = 'OFF'
            self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        elif deltaMarkOnOff == "0":
            self.buttonDeltaMkr.setText("Delta Marker %s [ON]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:DELTa:STATe ON" %active_marker)
            widget = InputDialog("Delta Marker", "nm", '0')
            widget.exec_()
            if widget.userInput != 0:
                global delta_distance
                delta_distance = widget.userInput
                active_mkr_param[5] = 'ON'
                my_instrument.write("CALC:MARK%s:FUNC:DELTa:X:OFFset %s%s" %(active_marker,delta_distance,wavelength_units))
                self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        self.updateMkrParam()
        if active_marker == '1':
            self.mkr1Display()
        if active_marker == '2':
            self.mkr2Display()
        if active_marker == '3':
            self.mkr3Display()
        if active_marker == '4':
            self.mkr4Display()
            

    def OSNRMkr(self): ## works
        # no sweep
        osnrMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:OSNR:STATe?" %active_marker)).rstrip()
        if osnrMarkOnOff == "1":
            self.buttonOSNRMkr.setText("OSNR Marker %s [OFF]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:OSNR:STATe OFF" %active_marker)
            active_mkr_param[6] = 'OFF'
            self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        elif osnrMarkOnOff == "0":
            self.buttonOSNRMkr.setText("OSNR Marker %s [ON]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:OSNR:STATe ON" %active_marker)
            active_mkr_param[6] = 'ON'
            self.markerDisplay(active_marker, mkr_1_param, mkr_2_param, mkr_3_param, mkr_4_param)
        self.updateMkrParam()
        if active_marker == '1':
            self.mkr1Display()
        if active_marker == '2':
            self.mkr2Display()
        if active_marker == '3':
            self.mkr3Display()
        if active_marker == '4':
            self.mkr4Display()

    ## works
    def lineMkrMenu(self):
        self.clearLayout(self.subButtonLayout)
        global lineMarkerOnOff
        global line1
        global line2
        self.buttonWLLineMkr1 = QtWidgets.QPushButton("Wavelength Line Mkr 1", self)
        self.subButtonLayout.addWidget(self.buttonWLLineMkr1)
        self.buttonWLLineMkr2 = QtWidgets.QPushButton("Wavelength Line Mkr 2", self)
        self.subButtonLayout.addWidget(self.buttonWLLineMkr2)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonLineMkrsOff = QtWidgets.QPushButton("Line Markers Off", self)
        self.subButtonLayout.addWidget(self.buttonLineMkrsOff)
        self.buttonAdvLineMkrFunc = QtWidgets.QPushButton("Advanved Line Marker Functions", self)
        self.subButtonLayout.addWidget(self.buttonAdvLineMkrFunc)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonWLLineMkr1.clicked.connect(self.WLLineMkr1)
        self.buttonWLLineMkr2.clicked.connect(self.WLLineMkr2)
        self.buttonLineMkrsOff.clicked.connect(self.lineMkrsOff)
        self.buttonAdvLineMkrFunc.clicked.connect(self.advLineMkrFunc)
        self.buttonPrevMenu.clicked.connect(self.moreMkrFunc)

    def WLLineMkr1(self):
        global line1
        Integration_Limit_1 = str(my_instrument.query("CALCulate:TPOWer:IRANge:LOWer?")).rstrip()
        Integration_Limit_1 = str(conversions.str2float(Integration_Limit_1, wavelength_units))
        widget = InputDialog("Wavelenth Line Mkr 1", "%s" %wavelength_units, Integration_Limit_1)
        widget.exec_()
        if widget.userInput != 0:
            Integration_Limit_1 = str(widget.userInput).rstrip()
            line1 = Integration_Limit_1
            my_instrument.write("CALCulate:TPOWer:IRANge:LOWer %s%s" %(Integration_Limit_1,wavelength_units))
            if search_flag == 1:
                my_instrument.write("CALCulate:MARKer:SRANge:LOWer %s%s" %(Integration_Limit_1,wavelength_units))
            if sweep_flag == 1:
                my_instrument.write("SENSe:WAVelength:SRANge:LOWer %s%s" %(Integration_Limit_1,wavelength_units))
            lineMarkerOnOff = 'On'
            self.lineMarkerDisplay(line1,line2,lineMarkerOnOff)
            
            
    def WLLineMkr2(self):
        global line2
        Integration_Limit_2 = str(my_instrument.query("CALCulate:TPOWer:IRANge:UPPer?")).rstrip()
        Integration_Limit_2 = str(conversions.str2float(Integration_Limit_2, wavelength_units))
        widget = InputDialog("Wavelenth Line Mkr 2", "%s" %wavelength_units, Integration_Limit_2)
        widget.exec_()
        if widget.userInput != 0:
            Integration_Limit_2 = str(widget.userInput).rstrip()
            line2 = Integration_Limit_2
            my_instrument.write("CALCulate:TPOWer:IRANge:UPPer %s%s" %(Integration_Limit_2,wavelength_units))
            if search_flag == 1:
                my_instrument.write("CALCulate:MARKer:SRANge:UPPer %s%s" %(Integration_Limit_1,wavelength_units))
            if sweep_flag == 1:
                my_instrument.write("SENSe:WAVelength:SRANge:UPPer %s%s" %(Integration_Limit_1,wavelength_units))
            lineMarkerOnOff = 'On'
            self.lineMarkerDisplay(line1,line2,lineMarkerOnOff)

    def lineMkrsOff(self):
        global sweep_limit
        global search_limit
        global integral_limit
        global trace_integral
        my_instrument.write("CALCulate:MARKer:SRANge OFF")
        my_instrument.write("CALCulate:TPOWer:IRANge OFF")
        my_instrument.write("SENSe:WAVelength:SRANge OFF")
        my_instrument.write("CALCulate:TPOWer:STATe OFF")
        sweep_limit = 'Off'
        search_limit = 'Off'
        integral_limit = 'Off'
        trace_integral = 'Off'
        lineMarkerOnOff = 'Off'
        self.lineMarkerDisplay(line1,line2,lineMarkerOnOff)

    def advLineMkrFunc(self): ## works
        widget = AdvancedLineMarkerWindow()
        widget.exec_()
        self.lineMarkerDisplay(line1,line2,lineMarkerOnOff)

    # Trace sub-menu
    def tracesMenu(self):
        global menuFlag
        menuFlag = 3

        self.clearLayout(self.subButtonLayout)
        
        self.buttonUpdtTrce = QtWidgets.QPushButton("Update Trace %s [%s]" %(active_trace[2], active_trace_param[0]), self)
        self.menuUpdtTrce = QtWidgets.QMenu()
        self.menuUpdtTrce.addAction("On", self.UpdtTrceAction1)
        self.menuUpdtTrce.addAction("Off", self.UpdtTrceAction2)
        self.buttonUpdtTrce.setMenu(self.menuUpdtTrce)
        self.subButtonLayout.addWidget(self.buttonUpdtTrce)
        self.buttonViewTrce = QtWidgets.QPushButton("View Trace %s [%s]" %(active_trace[2],active_trace_param[1]), self)
        self.menuViewTrce = QtWidgets.QMenu()
        self.menuViewTrce.addAction("On", self.ViewTrceAction1)
        self.menuViewTrce.addAction("Off", self.ViewTrceAction2)
        self.buttonViewTrce.setMenu(self.menuViewTrce)
        self.subButtonLayout.addWidget(self.buttonViewTrce)
        self.buttonHoldTrce = QtWidgets.QPushButton("Hold Trace %s [%s]" %(active_trace[2],active_trace_param[2]), self)
        self.menuHoldTrce = QtWidgets.QMenu()
        self.menuHoldTrce.addAction("None", self.HoldTrceAction1)
        self.menuHoldTrce.addAction("Min", self.HoldTrceAction2)
        self.menuHoldTrce.addAction("Max", self.HoldTrceAction3)
        self.buttonHoldTrce.setMenu(self.menuHoldTrce)
        self.subButtonLayout.addWidget(self.buttonHoldTrce)
        self.buttonTrceMath = QtWidgets.QPushButton("Trace Math", self)
        self.subButtonLayout.addWidget(self.buttonTrceMath)
        self.buttonAveraging = QtWidgets.QPushButton("Averaging %s [%s]" %(active_trace[2],active_trace_param[3]), self)
        self.menuAveraging = QtWidgets.QMenu()
        self.menuAveraging.addAction("On", self.AveragingAction1)
        self.menuAveraging.addAction("Off", self.AveragingAction2)
        self.buttonAveraging.setMenu(self.menuAveraging)
        self.subButtonLayout.addWidget(self.buttonAveraging)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonTrceSetup = QtWidgets.QPushButton("Trace Setup", self)
        self.subButtonLayout.addWidget(self.buttonTrceSetup)

        self.buttonTrceMath.clicked.connect(self.trceMath)
        self.buttonTrceSetup.clicked.connect(self.trceSetup)

    def UpdtTrceAction1(self): ## works
        # sweep
        self.buttonUpdtTrce.setText("Update Trace %s [ON]" %active_trace[2])
        my_instrument.write("TRACe:FEED:CONTrol %s,ALW" %active_trace)
        active_trace_param[0] == 'ON'
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        self.updateTrcParam()

    def UpdtTrceAction2(self): ## works
        # no sweep
        self.buttonUpdtTrce.setText("Update Trace %s [OFF]" %active_trace[2])
        my_instrument.write("TRACe:FEED:CONTrol %s,NEV" %active_trace)
        active_trace_param[0] = 'OFF'
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        self.updateTrcParam()

    def ViewTrceAction1(self): ## works
        # potential sweep
        self.buttonViewTrce.setText("View Trace %s [ON]" %active_trace[2])
        my_instrument.write("DISPlay:WINDow:TRACe:STATe %s,ON" %active_trace)
        active_trace_param[1] = "ON"
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        self.updateTrcParam()

    def ViewTrceAction2(self): ## works
        # no sweep
        global TRA_plot
        self.buttonViewTrce.setText("View Trace %s [OFF]" %active_trace[2])
        my_instrument.write("DISPlay:WINDow:TRACe:STATe %s,OFF" %active_trace)
        active_trace_param[1] = "OFF"
        if active_trace == "TRA":
            self.p1.removeItem(TRA_plot)
        if active_trace == "TRB":
            self.p1.removeItem(TRB_plot)
        if active_trace == "TRC":
            self.p1.removeItem(TRC_plot)
        if active_trace == "TRD":
            self.p1.removeItem(TRD_plot)
        if active_trace == "TRE":
            self.p1.removeItem(TRE_plot)
        if active_trace == "TRF":
            self.p1.removeItem(TRF_plot)
        self.updateTrcParam()
            
    def HoldTrceAction1(self): ## works
        # not sure sweep
        self.buttonHoldTrce.setText("Hold Trace %s [NONE]" %active_trace[2])
        my_instrument.write("CALCulate%s:MAXimum:STATe OFF" %active_trace_num)
        my_instrument.write("CALCulate%s:MINimum:STATe OFF" %active_trace_num)
        active_trace_param[2] = 'NONE'
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        self.updateTrcParam()

    def HoldTrceAction2(self): ## works
        # not sure sweep
        self.buttonHoldTrce.setText("Hold Trace %s [MIN]" %active_trace[2])
        my_instrument.write("CALCulate%s:MINimum:STATe ON" %active_trace_num)
        active_trace_param[2] = 'MIN'
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        self.updateTrcParam()

    def HoldTrceAction3(self): ## works
        # not sure sweep
        self.buttonHoldTrce.setText("Hold Trace %s [MAX]" %active_trace[2])
        my_instrument.write("CALCulate%s:MAXimum:STATe ON" %active_trace_num)
        active_trace_param[2] = 'MAX'
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        self.updateTrcParam()


    def trceMath(self):
        self.clearLayout(self.subButtonLayout)

        self.buttonDefMathTrcC = QtWidgets.QPushButton("Default Math Trace C", self)
        self.menuTrcMathC = QtWidgets.QMenu()
        self.menuTrcMathC.addAction("Log: C = A-B", self.TrcMathCAction1)
        self.menuTrcMathC.addAction("Log: C = A+B", self.TrcMathCAction2)
        self.menuTrcMathC.addAction("Lin: C = A-B", self.TrcMathCAction3)
        self.menuTrcMathC.addAction("Lin: C = A+B", self.TrcMathCAction4)
        self.menuTrcMathC.addAction("Trace C Math Off", self.TrcMathCAction5)
        self.buttonDefMathTrcC.setMenu(self.menuTrcMathC)
        self.subButtonLayout.addWidget(self.buttonDefMathTrcC)
        self.buttonDefMathTrcF = QtWidgets.QPushButton("Default Math Trace F", self)
        self.menuTrcMathF = QtWidgets.QMenu()
        self.menuTrcMathF.addAction("Log: F = C-D", self.TrcMathFAction1)
        self.menuTrcMathF.addAction("Trace F Math Off", self.TrcMathFAction2)
        self.buttonDefMathTrcF.setMenu(self.menuTrcMathF)
        self.subButtonLayout.addWidget(self.buttonDefMathTrcF)
        self.buttonExchMenu = QtWidgets.QPushButton("Exchange Menu", self)
        self.menuExchange = QtWidgets.QMenu()
        self.menuExchange.addAction("A Exchange B", self.ExchangeAction1)
        self.menuExchange.addAction("B Exchange C", self.ExchangeAction2)
        self.menuExchange.addAction("C Exchange A", self.ExchangeAction3)
        self.menuExchange.addAction("D Exchange A", self.ExchangeAction4)
        self.menuExchange.addAction("E Exchange A", self.ExchangeAction5)
        self.menuExchange.addAction("F Exchange A", self.ExchangeAction6)
        self.buttonExchMenu.setMenu(self.menuExchange)
        self.subButtonLayout.addWidget(self.buttonExchMenu)
        self.buttonTrceOffset = QtWidgets.QPushButton("Trace Offset", self)
        self.subButtonLayout.addWidget(self.buttonTrceOffset)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonAllMathOff = QtWidgets.QPushButton("All Math Off", self)
        self.subButtonLayout.addWidget(self.buttonAllMathOff)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonTrceOffset.clicked.connect(self.trceOffset)
        self.buttonAllMathOff.clicked.connect(self.allMathOff)
        self.buttonPrevMenu.clicked.connect(self.tracesMenu)
        self.buttonPrevMenu.clicked.connect(self.tracesMenu)

    def TrcMathCAction1(self):
        # sweep
        my_instrument.write("CALCulate3:MATH:STATe ON")
        my_instrument.write("CALCulate3:MATH:EXPRession (TRA / TRB)")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def TrcMathCAction2(self):
        # sweep
        my_instrument.write("CALCulate3:MATH:STATe ON")
        my_instrument.write("CALCulate3:MATH:EXPRession (TRA * TRB)")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def TrcMathCAction3(self):
        # sweep
        my_instrument.write("CALCulate3:MATH:STATe ON")
        my_instrument.write("CALCulate3:MATH:EXPRession (TRA - TRB)")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def TrcMathCAction4(self):
        # sweep
        my_instrument.write("CALCulate3:MATH:STATe ON")
        my_instrument.write("CALCulate3:MATH:EXPRession (TRA + TRB)")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def TrcMathCAction5(self):
        my_instrument.write("CALCulate3:MATH:STATe OFF")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def TrcMathFAction1(self):
        # sweep
        my_instrument.write("CALCulate6:MATH:STATe ON")
        my_instrument.write("CALCulate6:MATH:EXPRession (TRC / TRD)")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def TrcMathFAction2(self):
        my_instrument.write("CALCulate6:MATH:STATe OFF")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ExchangeAction1(self):
        # sweep
        my_instrument.write("TRACe:EXCHange TRA,TRB")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ExchangeAction2(self):
        # sweep
        my_instrument.write("TRACe:EXCHange TRB,TRC")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ExchangeAction3(self):
        # sweep
        my_instrument.write("TRACe:EXCHange TRC,TRA")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ExchangeAction4(self):
        # sweep
        my_instrument.write("TRACe:EXCHange TRD,TRA")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ExchangeAction5(self):
        # sweep
        my_instrument.write("TRACe:EXCHange TRE,TRA")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ExchangeAction6(self):
        # sweep
        my_instrument.write("TRACe:EXCHange TRF,TRA")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def trceOffset(self):
        # sweep
        Trace_Offset = str(my_instrument.query("CALCulate%s:OFFSet?" %active_trace_num)).rstrip()
        Trace_Offset = str(conversions.str2float(Trace_Offset, amplitude_units))
        widget = InputDialog("Trace %s Offset" %active_trace_num, "%s" %amplitude_units, Trace_Offset)
        widget.exec_()
        if widget.userInput != 0:
            Trace_Offset = str(widget.userInput).rstrip()
            my_instrument.write("CALCulate%s:OFFSet %s" %(Integration_Limit_2,Trace_Offset))

    def allMathOff(self):
        # no sweep
        my_instrument.write("CALCulate:MATH:STATe OFF")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def AveragingAction1(self): ## works
        # no sweep
        self.buttonAveraging.setText("Averaging [ON]")
        my_instrument.write("CALCulate:AVERage:STATe ON")
        active_trace_param[3] = "ON"
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        self.updateTrcParam()

    def AveragingAction2(self): ## works
        # no sweep
        self.buttonAveraging.setText("Averaging [OFF]")
        my_instrument.write("CALCulate:AVERage:STATe OFF")
        active_trace_param[3] = "OFF"
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        self.updateTrcParam()

    def trceSetup(self): ## works
        # sweep
        num_points = str(my_instrument.query("SENSe:SWEep:POINts?")).rstrip()
        widget = InputDialog("Trace Setup", "Sweep Points", num_points[1:5])
        widget.exec_()
        if widget.userInput != 0:
            num_points = "SENSe:SWEep:POINts " + "%s" %widget.userInput
            my_instrument.write(num_points)
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    # Bandwidth/Sweep sub-menu
    def bwMenu(self):
        global resBwManAuto
        global repeatSweepOnOff
        self.clearLayout(self.subButtonLayout)    

        self.buttonResBW = QtWidgets.QPushButton("Res BW [%s]" %resBwManAuto, self)
        self.menuResBw = QtWidgets.QMenu()
        self.menuResBw.addAction("Auto", self.ResBWAction1)
        self.menuResBw.addAction("Manual", self.ResBWAction2)
        self.buttonResBW.setMenu(self.menuResBw)
        self.subButtonLayout.addWidget(self.buttonResBW)
        self.buttonVidBW = QtWidgets.QPushButton("Video BW [%s]" %vidBwManAuto, self)
        self.menuVidBW = QtWidgets.QMenu()
        self.menuVidBW.addAction("Auto", self.VidBWAction1)
        self.menuVidBW.addAction("Manual", self.VidBWAction2)
        self.buttonVidBW.setMenu(self.menuVidBW)
        self.subButtonLayout.addWidget(self.buttonVidBW)
        self.buttonSweepTime = QtWidgets.QPushButton("Sweep Time [%s]" %sweepTimeManAuto, self)
        self.menuSweepTime = QtWidgets.QMenu()
        self.menuSweepTime.addAction("Auto", self.SweepTimeAction1)
        self.menuSweepTime.addAction("Manual", self.SweepTimeAction2)
        self.buttonSweepTime.setMenu(self.menuSweepTime)
        self.subButtonLayout.addWidget(self.buttonSweepTime)
        self.buttonRptSweep = QtWidgets.QPushButton("Repeat Sweep [%s]" %repeatSweepOnOff, self)
        self.menuRptSweep = QtWidgets.QMenu()
        self.menuRptSweep.addAction("On", self.RptSweepAction1)
        self.menuRptSweep.addAction("Off", self.RptSweepAction2)
        self.buttonRptSweep.setMenu(self.menuRptSweep)
        self.subButtonLayout.addWidget(self.buttonRptSweep)
        self.buttonSnglSweep = QtWidgets.QPushButton("Single Sweep", self)
        self.subButtonLayout.addWidget(self.buttonSnglSweep)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonMoreBWFunc = QtWidgets.QPushButton("More BW/Sweep Functions", self)
        self.subButtonLayout.addWidget(self.buttonMoreBWFunc)

        self.buttonSnglSweep.clicked.connect(self.snglSweep)
        self.buttonMoreBWFunc.clicked.connect(self.moreBWFunc)

    def ResBWAction1(self):
        # no sweep
        self.buttonResBW.setText("Res BW [AUTO]")
        my_instrument.write("SENSe:BANDwidth:RESolution:AUTO 1")
        resBwManAuto = "1"
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ResBWAction2(self):
        # no sweep
        global resBwManAuto
        resBwManAuto = str(my_instrument.query("SENSe:BANDwidth:RESolution:AUTO?")).rstrip()
        widget = InputDialog("Res BW", "%s" %wavelength_units, str(resBw))
        widget.exec_()
        if widget.userInput != 0:
            self.buttonResBW.setText("Res BW [MAN]")
            bandwidth = "SENSe:BANDwidth:RESolution " + "%s%s" %(widget.userInput,wavelength_units) #may be wrong unit
            my_instrument.write(bandwidth)
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def VidBWAction1(self):
        # no sweep
        self.buttonVidBW.setText("Video BW [AUTO]")
        my_instrument.write("SENSe:BANDwidth:VIDeo:AUTO 1")
        global vidBwManAuto
        vidBwManAuto = "1"
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def VidBWAction2(self):
        # no sweep
        global vidBwManAuto
        vidBwManAuto = str(my_instrument.query("SENSe:BANDwidth:VIDeo:AUTO?")).rstrip()
        widget = InputDialog("Video BW", "%s" %frequency_units, str(vidBw))
        widget.exec_()
        if widget.userInput != 0:
            self.buttonVidBW.setText("Video BW [MAN]")
            bandwidth = "SENSe:BANDwidth:VIDeo " + "%s%s" %(widget.userInput,frequency_units) #may be wrong unit
            my_instrument.write(bandwidth)
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def SweepTimeAction1(self):
        # no sweep
        self.buttonSweepTime.setText("Sweep Time [AUTO]")
        my_instrument.write("SENSe:SWEep:TIME:AUTO 1")
        global sweepTimeManAuto
        sweepTimeManAuto = "1"

    def SweepTimeAction2(self):
        # no sweep
        global sweepTimeManAuto
        sweepTimeManAuto = str(my_instrument.query("SENSe:SWEep:TIME:AUTO?")).rstrip()
        widget = InputDialog("Sweep Time", "s", str(sweepTime))
        widget.exec_()
        if widget.userInput != 0:
            self.buttonSweepTime.setText("Sweep Time [MAN]")
            stime = "SENSe:SWEep:TIME " + "%ss" %widget.userInput
            my_instrument.write(stime)
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def RptSweepAction1(self): ## works
        # continuous sweep
        self.buttonRptSweep.setText("Repeat Sweep [ON]")
        my_instrument.write("INITiate:CONTinuous 1")
        repeatSweepOnOff = "ON"

    def RptSweepAction2(self): ## works
        # no sweep
        self.buttonRptSweep.setText("Repeat Sweep [OFF]")
        my_instrument.write("INITiate:CONTinuous 0")
        repeatSweepOnOff = "OFF"

    def snglSweep(self):
        # sweep
        sweep = 1
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    ## TODO: CHECK TRIG MODES
    def moreBWFunc(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonTrigMode = QtWidgets.QPushButton("Trigger Mode [%s]" %Trigger_Mode, self)
        self.menuTrigMode = QtWidgets.QMenu()
        self.menuTrigMode.addAction("Internal", self.TrigModeAction1)
        self.menuTrigMode.addAction("Gated", self.TrigModeAction2)
        self.menuTrigMode.addAction("External", self.TrigModeAction3)
        self.menuTrigMode.addAction("ADC+", self.TrigModeAction4)
        self.menuTrigMode.addAction("ADC-", self.TrigModeAction5)
        self.buttonTrigMode.setMenu(self.menuTrigMode)
        self.subButtonLayout.addWidget(self.buttonTrigMode)
        self.buttonTrigDelay = QtWidgets.QPushButton("Trigger Delay", self)
        self.subButtonLayout.addWidget(self.buttonTrigDelay)
        self.buttonADCTrigSync = QtWidgets.QPushButton("ADC Trig Sync [%s]" %trigSyncLowHighPulse, self)
        self.menuADCTrig = QtWidgets.QMenu()
        self.menuADCTrig.addAction("Low", self.ADCTrigAction1)
        self.menuADCTrig.addAction("High", self.ADCTrigAction2)
        self.menuADCTrig.addAction("Pulse", self.ADCTrigAction3)
        self.buttonADCTrigSync.setMenu(self.menuADCTrig)
        self.subButtonLayout.addWidget(self.buttonADCTrigSync)
        self.buttonADCSyncOut = QtWidgets.QPushButton("ADC Sync Out [%s]" %syncOutOnOff, self)
        self.buttonADCSyncOut.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonADCSyncOut)
        self.buttonADCSyncOutDuty = QtWidgets.QPushButton("ADC Sync Out Duty Cycle", self)
        self.subButtonLayout.addWidget(self.buttonADCSyncOutDuty)
        self.buttonADCSyncOutPulse = QtWidgets.QPushButton("ADC Sync Out Pulse Width", self)
        self.subButtonLayout.addWidget(self.buttonADCSyncOutPulse)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonTrigDelay.clicked.connect(self.trigDelay)
        self.buttonADCSyncOut.clicked.connect(self.ADCSyncOut)
        self.buttonADCSyncOutDuty.clicked.connect(self.ADCSyncOutDuty)
        self.buttonADCSyncOutPulse.clicked.connect(self.ADCSyncOutPulse)
        self.buttonPrevMenu.clicked.connect(self.bwMenu)

    def TrigModeAction1(self):
        # no sweep
        self.buttonTrigMode.setText("Trigger Mode [Internal]")
        Trigger_Mode = "Internal"
        my_instrument.write("TRIGger:SOURce INT")

    def TrigModeAction2(self):
        # no sweep
        self.buttonTrigMode.setText("Trigger Mode [Gated]")

    def TrigModeAction3(self):
        # no sweep
        self.buttonTrigMode.setText("Trigger Mode [External]")
        Trigger_Mode = "External"
        my_instrument.write("TRIGger:SOURce EXT")

    def TrigModeAction4(self):
        # no sweep
        self.buttonTrigMode.setText("Trigger Mode [ADC+]")
        Trigger_Mode = "ADC+"
        my_instrument.write("TRIGger:SLOPe POS")

    def TrigModeAction5(self):
        # no sweep
        self.buttonTrigMode.setText("Trigger Mode [ADC-]")
        Trigger_Mode = "ADC-"
        my_instrument.write("TRIGger:SLOPe NEG")

    ## TODO: need to make time dynamic
    def trigDelay(self): ## works
        # no sweep
        value = my_instrument.query("TRIGger:DELay?")
        current_value = str(conversions.str2float(value,"us")) 
        widget = InputDialog("Trigger Delay", "us", current_value)
        widget.exec_()
        if widget.userInput != 0:
            delay = "TRIGger:DELay " + "%sus" %widget.userInput
            my_instrument.write(delay)
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ADCTrigAction1(self):
        # no sweep
        self.buttonADCTrigSync.setText("ADC Trig Sync [LOW]")
        my_instrument.write("TRIGger:OUTPut OFF")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ADCTrigAction2(self):
        # no sweep
        self.buttonADCTrigSync.setText("ADC Trig Sync [HIGH]")
        my_instrument.write("TRIGger:OUTPut ON")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ADCTrigAction3(self):
        # no sweep
        self.buttonADCTrigSync.setText("ADC Trig Sync [PULSE]")
        my_instrument.write("TRIGger:OUTPut AUTO")
        sweep = 0
        self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ADCSyncOut(self):
        # no sweep
        syncOutOnOff = str(my_instrument.query("TRIGger:OUTPut:PULSe:STATe?")).rstrip()
        if syncOutOnOff == "0":
            self.buttonADCSyncOut.setText("ADC Sync Out [ON]")
            my_instrument.write("TRIGger:OUTPut:PULSe:STATe 1")
            syncOutOnOff = "1"
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)
        elif syncOutOnOff == "1":
            self.buttonADCSyncOut.setText("ADC Sync Out [OFF]")
            my_instrument.write("TRIGger:OUTPut:PULSe:STATe 0")
            syncOutOnOff = "0"
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ADCSyncOutDuty(self):
        # no sweep
        value = my_instrument.query("TRIGger:OUTPut:PULSe:DCYCle?")
        current_value = str(conversions.str2float(value,"%")) ##TODO: no value here?
        widget = InputDialog("ADC Sync Out Duty Cycle", "%", current_value)
        widget.exec_()
        if widget.userInput != 0:
            duty_cycle = "TRIGger:OUTPut:PULSe:DCYCle " + "%s" %widget.userInput
            my_instrument.write(duty_cycle)
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)

    def ADCSyncOutPulse(self):
        # no sweep
        value = my_instrument.query("TRIGger:OUTPut:PULSe:WIDTh?")
        current_value = str(conversions.str2float(value,"us")) 
        widget = InputDialog("ADC Sync Out Pulse Width", "us", current_value)
        widget.exec_()
        if widget.userInput != 0:
            pulse_width = "TRIGger:OUTPut:PULSe:WIDTh " + "%sus" %widget.userInput
            my_instrument.write(pulse_width)
            sweep = 0
            self.traceDisplay( num_points, active_trace, wavelength_name, amplitude_name, wavelength_units_display, amplitude_units,
                         trace_a_data, trace_b_data, trace_c_data, trace_d_data, trace_e_data, trace_f_data, trace_a_param, trace_b_param, trace_c_param,
                         trace_d_param, trace_e_param, trace_f_param, sweep)


## The input dialog class is used throught the agilent class to allow the
## user to input values into menu options
class InputDialog(QtWidgets.QDialog, Ui_inputDialog):
    def __init__(self, title, unit, value, parent=None):
        super(InputDialog, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle(title)
        self.label.setText(unit)
        self.lineEdit.setText(value)
        validator = QtGui.QDoubleValidator()
        self.lineEdit.setValidator(validator)
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)
        global flag
        flag = 0

    def onAccept(self):
        self.userInput = self.lineEdit.text()
        global flag
        flag = 1
        return self.userInput
        
    def onReject(self):
        self.userInput = 0
        global flag
        flag = 1
        return self.userInput
    

class ActiveMarkersWindow(QtWidgets.QDialog, Ui_activeMarkersWindow):
    def __init__(self, parent=None):
        super(ActiveMarkersWindow, self).__init__(parent)
        self.setupUi(self)
        if float(my_instrument.query("CALCulate:MARKer1:STATe?")) == 1:
            self.checkMkr1.setChecked(True)
        if float(my_instrument.query("CALCulate:MARKer2:STATe?")) == 1:
            self.checkMkr2.setChecked(True)
        if float(my_instrument.query("CALCulate:MARKer3:STATe?")) == 1:
            self.checkMkr3.setChecked(True)
        if float(my_instrument.query("CALCulate:MARKer4:STATe?")) == 1:
            self.checkMkr4.setChecked(True)

        self.buttonAllOff.clicked.connect(self.allMkrsOff)
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def allMkrsOff(self):
        self.checkMkr1.setChecked(False)
        self.checkMkr2.setChecked(False)
        self.checkMkr3.setChecked(False)
        self.checkMkr4.setChecked(False)

    def onAccept(self):
        global mkr_1_param
        global mkr_2_param
        global mkr_3_param
        global mkr_4_param
        if self.checkMkr1.isChecked() == True:
            my_instrument.write("CALCulate:MARKer1:STATe ON")
            mkr_1_param[0] = "1"
        if self.checkMkr1.isChecked() == False:
            my_instrument.write("CALCulate:MARKer1:STATe OFF")
            mkr_1_param[0] = "0"
        if self.checkMkr2.isChecked() == True:
            my_instrument.write("CALCulate:MARKer2:STATe ON")
            mkr_2_param[0] = "1"
        if self.checkMkr2.isChecked() == False:
            my_instrument.write("CALCulate:MARKer2:STATe OFF")
            mkr_2_param[0] = "0"
        if self.checkMkr3.isChecked() == True:
            my_instrument.write("CALCulate:MARKer3:STATe ON")
            mkr_3_param[0] = "1"
        if self.checkMkr3.isChecked() == False:
            my_instrument.write("CALCulate:MARKer3:STATe OFF")
            mkr_3_param[0] = "0"
        if self.checkMkr4.isChecked() == True:
            my_instrument.write("CALCulate:MARKer4:STATe ON")
            mkr_4_param[0] = "1"
        if self.checkMkr4.isChecked() == False:
            my_instrument.write("CALCulate:MARKer4:STATe OFF")
            mkr_4_param[0] = "0"

        global active_marker
        if mkr_1_param[0] == '1':
            active_marker = '1'
        if mkr_2_param[0] == '1':
            active_marker = '2'
        if mkr_3_param[0] == '1':
            active_marker = '3'
        if mkr_4_param[0] == '1':
            active_marker = '4'

        self.markerReturn = 1
        return self.markerReturn

    def onReject(self):
        self.markerReturn = 0
        return self.markerReturn

## TODO: Factory/User power cal selection #TODO: check variable placement in load up
class AmplitudeSetup(QtWidgets.QDialog, Ui_amplitudeSetupWindow):
    def __init__(self, parent=None):
        super(AmplitudeSetup, self).__init__(parent)
        self.setupUi(self)
        global auto_ranging
        global auto_zero
        global auto_chop
        global amplitude_correction_mode
        if amplitude_units == 'dB':
            amp_units_display = 'Auto'
        else:
            amp_units_display = 'W'
        self.buttonAmpUnits.setText("%s" %amp_units_display)
        self.menuAmpUnits = QtWidgets.QMenu()
        self.menuAmpUnits.addAction("Auto", self.AmpUnitsAction1)
        self.menuAmpUnits.addAction("W", self.AmpUnitsAction2)
        self.buttonAmpUnits.setMenu(self.menuAmpUnits)
        if auto_ranging == '1':
            auto_range_display = 'On'
        elif auto_ranging == '0':
            auto_range_display = 'Off'
        self.buttonAutoRang.setText("%s" %auto_range_display)
        self.menuAutoRang = QtWidgets.QMenu()
        self.menuAutoRang.addAction("On", self.AutoRangAction1)
        self.menuAutoRang.addAction("Off", self.AutoRangAction2)
        self.buttonAutoRang.setMenu(self.menuAutoRang)
        if auto_zero == '1':
            auto_zero_display = 'On'
        elif auto_zero == '0':
            auto_zero_display = 'Off'
        self.buttonAutoZero.setText("%s" %auto_zero_display)
        self.menuAutoZero = QtWidgets.QMenu()
        self.menuAutoZero.addAction("On", self.AutoZeroAction1)
        self.menuAutoZero.addAction("Off", self.AutoZeroAction2)
        if auto_chop == '1':
            auto_chop_display = 'On'
        elif auto_chop == '0':
            auto_chop_display = 'Off'
        self.buttonAutoZero.setMenu(self.menuAutoZero)
        self.buttonAutoChop.setText("%s" %auto_chop_display)
        self.menuAutoChop = QtWidgets.QMenu()
        self.menuAutoChop.addAction("On", self.AutoChopAction1)
        self.menuAutoChop.addAction("Off", self.AutoChopAction2)
        self.buttonAutoChop.setMenu(self.menuAutoChop)
        self.buttonPowCal.setText("Factory")
        self.menuPowCal = QtWidgets.QMenu()
        self.menuPowCal.addAction("User", self.PowCalAction1)
        self.menuPowCal.addAction("Factory", self.PowCalAction2)
        self.buttonPowCal.setMenu(self.menuPowCal)
        self.buttonAmpCorr.setText("%s" %amplitude_correction)
        self.menuAmpCorr = QtWidgets.QMenu()
        self.menuAmpCorr.addAction("1", self.AmpCorrAction1)
        self.menuAmpCorr.addAction("2", self.AmpCorrAction2)
        self.menuAmpCorr.addAction("3", self.AmpCorrAction3)
        self.menuAmpCorr.addAction("4", self.AmpCorrAction4)
        if amplitude_correction_mode == '1':
            amplitude_correction_mode = 'On'
        elif amplitude_correction_mode == '0':
            amplitude_correction_mode = 'Off'
        self.buttonAmpCorr.setMenu(self.menuAmpCorr)
        self.buttonAmpCorrMode.setText("%s" %amplitude_correction_mode)
        self.menuAmpCorrMode = QtWidgets.QMenu()
        self.menuAmpCorrMode.addAction("On", self.AmpCorrModeAction1)
        self.menuAmpCorrMode.addAction("Off", self.AmpCorrModeAction2)
        self.buttonAmpCorrMode.setMenu(self.menuAmpCorrMode)

        # Populate text fields
        self.labelUserPowCal.setText(str(my_instrument.query("CALibration:POWer:DATE?")).rstrip())

        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def AmpUnitsAction1(self):
        self.buttonAmpUnits.setText("Auto")

    def AmpUnitsAction2(self):
        self.buttonAmpUnits.setText("W")

    def AutoRangAction1(self):
        self.buttonAutoRang.setText("On")

    def AutoRangAction2(self):
        self.buttonAutoRang.setText("Off")

    def AutoZeroAction1(self):
        self.buttonAutoZero.setText("On")

    def AutoZeroAction2(self):
        self.buttonAutoZero.setText("Off")

    def AutoChopAction1(self):
        self.buttonAutoChop.setText("On")

    def AutoChopAction2(self):
        self.buttonAutoChop.setText("Off")

    def PowCalAction1(self):
        self.buttonPowCal.setText("User")

    def PowCalAction2(self):
        self.buttonPowCal.setText("Factory")

    def AmpCorrAction1(self):
        self.buttonAmpCorr.setText("1")

    def AmpCorrAction2(self):
        self.buttonAmpCorr.setText("2")

    def AmpCorrAction3(self):
        self.buttonAmpCorr.setText("3")

    def AmpCorrAction4(self):
        self.buttonAmpCorr.setText("4")

    def AmpCorrModeAction1(self):
        self.buttonAmpCorrMode.setText("On")

    def AmpCorrModeAction2(self):
        self.buttonAmpCorrMode.setText("Off")

    def onAccept(self):
        global logLin
        global amplitude_units

        if self.buttonAmpUnits.text() == "Auto":
            amplitude_units = 'dB'
        else:
            amplitude_units = 'W'

        if self.buttonAutoRang.text() == "On":
            my_instrument.write("SENSe:POWer:DC:RANGe:AUTO ON")
        else:
            my_instrument.write("SENSe:POWer:DC:RANGe:AUTO OFF")

        if self.buttonAutoZero.text() == 'On':
            my_instrument.write("CALibration:ZERO:AUTO 1")
        else:
            my_instrument.write("CALibration:ZERO:AUTO 0")

        if self.buttonAutoChop.text() == 'On':
            my_instrument.write("SENSe:CHOP:STATe 1")
        else:
            my_instrument.write("SENSe:CHOP:STATe 0")

        amplitude_correction = str(self.buttonAmpCorr.text())
        my_instrument.write("SENSe:CORRection:CSET %s" %amplitude_correction)

        amplitude_correction_mode = str(self.buttonAmpCorrMode.text())
        my_instrument.write("SENSe:CORRection:STATe %s" %amplitude_correction_mode)

        return 
        
    def onReject(self):
        return


class WavelengthSetup(QtWidgets.QDialog, Ui_wavelengthSetupWindow): ## Complete
    def __init__(self, parent=None):
        super(WavelengthSetup, self).__init__(parent)
        self.setupUi(self)
        
        wavelengthOffset = str(ast.literal_eval(my_instrument.query("SENSe:WAVelength:OFFSet?")))
        wavelengthStepSize = str(ast.literal_eval(my_instrument.query("SENse:WAVelength:CENTer:STEP:INCRement?")))
        wavelengthOffset = str(conversions.str2float(wavelengthOffset, '%s' %wavelength_units))
        wavelengthStepSize = str(conversions.str2float(wavelengthStepSize, '%s' %wavelength_units))
        self.buttonWLUnits.setText("%s" %wavelength_units)
        self.menuWLUnits = QtWidgets.QMenu()
        self.menuWLUnits.addAction("nm", self.WLUnitsAction1)
        self.menuWLUnits.addAction("um", self.WLUnitsAction2)
        self.menuWLUnits.addAction("Ang", self.WLUnitsAction3)
        self.buttonWLUnits.setMenu(self.menuWLUnits)
        self.lineWLOffset.setText("%s" %wavelengthOffset)
        self.label_3.setText("%s" %wavelength_units)
        self.label_5.setText("%s" %wavelength_units)
        self.lineWLStep.setText("%s" %wavelengthStepSize)
        self.buttonWLRef.setText("%s" %wavelengthRefIn)
        self.menuWLRef = QtWidgets.QMenu()
        self.menuWLRef.addAction("AIR", self.WLRefAction1)
        self.menuWLRef.addAction("VAC", self.WLRefAction2)
        self.buttonWLRef.setMenu(self.menuWLRef)

        # Prevent user input of non doubles
        validator = QtGui.QDoubleValidator()
        self.lineWLOffset.setValidator(validator)
        self.lineWLStep.setValidator(validator)

        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def WLUnitsAction1(self):
        self.buttonWLUnits.setText("nm")
        global wavelength_units
        wavelength_units = "nm"
        wavelength_units_display = 'm'

    def WLUnitsAction2(self):
        self.buttonWLUnits.setText("um")
        global wavelength_units
        wavelength_units = "um"
        wavelength_units_display = 'm'

    def WLUnitsAction3(self):
        self.buttonWLUnits.setText("Ang")
        global wavelength_units
        wavelength_units = "Ang"
        wavelength_units_display = 'Ang'

    def WLRefAction1(self):
        self.buttonWLRef.setText("AIR")

    def WLRefAction2(self):
        self.buttonWLRef.setText("VAC")

    def onAccept(self):
        if self.buttonWLUnits.text() == "nm":
            wavelength_units = "nm"
            wavelength_units_display = 'm'
        elif self.buttonWLUnits.text() == "um":
            wavelength_units = "um"
            wavelength_units_display = 'm'
        else:
            wavelength_units = "Ang"
            wavelength_units_display = 'Ang'

        wavelengthOffset = str(self.lineWLOffset.text())
        wavelengthStepSize = str(self.lineWLStep.text())
        wavOff = "SENSe:WAVelength:OFFSet " + "%s%s" %(wavelengthOffset,wavelength_units)
        wavStep = "SENse:WAVelength:CENTer:STEP:INCRement " + "%s%s" %(wavelengthStepSize,wavelength_units)
        my_instrument.write(wavOff)
        my_instrument.write(wavStep)
        global wavelengthRefIn
        
        if self.buttonWLRef.text() == "AIR":
            my_instrument.write("SENSe:CORRection:RVELocity:MEDium AIR")

            wavelengthRefIn = "AIR"
        else:
            my_instrument.write("SENSe:CORRection:RVELocity:MEDium VAC")
            wavelengthRefIn = "VAC" 
        return

    def onReject(self):
        return


class MarkerSetup(QtWidgets.QDialog, Ui_markerSetupWindow):
    def __init__(self, MkrNo, parent=None):
        super(MarkerSetup, self).__init__(parent)
        self.setupUi(self)

        global mkr_units
        global BW_units
        global delta_units
        global mkrInterpOnOff
        global BWInterpOnOff
        global mkrThreshOnOff
        global noiseMkrBW
        global OSNRType
        global OSNROffset
        global peakExcur
        global pitExcur
        global userMkrThresh
        global active_marker
        global validator

        self.buttonNormMkrUnits.setText("%s" %mkr_units)
        self.menuNormMkrUnits = QtWidgets.QMenu()
        self.menuNormMkrUnits.addAction("nm", self.NormMkrUnitsAction1)
        self.menuNormMkrUnits.addAction("um", self.NormMkrUnitsAction2)
        self.menuNormMkrUnits.addAction("Ang", self.NormMkrUnitsAction3)
        self.menuNormMkrUnits.addAction("GHz", self.NormMkrUnitsAction4)
        self.menuNormMkrUnits.addAction("THz", self.NormMkrUnitsAction5)
        self.buttonNormMkrUnits.setMenu(self.menuNormMkrUnits)
        self.buttonBWMkrUnits.setText("%s" %BW_units)
        self.menuBWMkrUnits = QtWidgets.QMenu()
        self.menuBWMkrUnits.addAction("nm", self.BWMkrUnitsAction1)
        self.menuBWMkrUnits.addAction("um", self.BWMkrUnitsAction2)
        self.menuBWMkrUnits.addAction("Ang", self.BWMkrUnitsAction3)
        self.menuBWMkrUnits.addAction("GHz", self.BWMkrUnitsAction4)
        self.menuBWMkrUnits.addAction("THz", self.BWMkrUnitsAction5)
        self.buttonBWMkrUnits.setMenu(self.menuBWMkrUnits)
        self.buttonDeltaMkrUnits.setText("%s" %delta_units)
        self.menuDeltaMkrUnits = QtWidgets.QMenu()
        self.menuDeltaMkrUnits.addAction("nm", self.DeltaMkrUnitsAction1)
        self.menuDeltaMkrUnits.addAction("um", self.DeltaMkrUnitsAction2)
        self.menuDeltaMkrUnits.addAction("Ang", self.DeltaMkrUnitsAction3)
        self.menuDeltaMkrUnits.addAction("GHz", self.DeltaMkrUnitsAction4)
        self.menuDeltaMkrUnits.addAction("THz", self.DeltaMkrUnitsAction5)
        self.buttonDeltaMkrUnits.setMenu(self.menuDeltaMkrUnits)
        self.buttonMkrInterp.setText("%s" %mkrInterpOnOff)
        self.menuMkrInterp = QtWidgets.QMenu()
        self.menuMkrInterp.addAction("ON", self.MkrInterpAction1)
        self.menuMkrInterp.addAction("OFF", self.MkrInterpAction2)
        self.buttonMkrInterp.setMenu(self.menuMkrInterp)
        self.buttonBWMkrInterp.setText("%s" %BWInterpOnOff)
        self.menuBWMkrInterp = QtWidgets.QMenu()
        self.menuBWMkrInterp.addAction("ON", self.BWMkrInterpAction1)
        self.menuBWMkrInterp.addAction("OFF", self.BWMkrInterpAction2)
        self.buttonBWMkrInterp.setMenu(self.menuBWMkrInterp)
        self.buttonUserMkrThresh.setText("%s" %mkrThreshOnOff)
        self.menuUserMkrThresh = QtWidgets.QMenu()
        self.menuUserMkrThresh.addAction("ON", self.UserMkrThreshAction1)
        self.menuUserMkrThresh.addAction("OFF", self.UserMkrThreshAction2)
        self.buttonUserMkrThresh.setMenu(self.menuUserMkrThresh)
        self.buttonNoiseMkrBW.setText("%s nm" %noiseMkrBW)
        self.menuNoiseMkrBW = QtWidgets.QMenu()
        self.menuNoiseMkrBW.addAction("0.1 nm", self.NoiseMkrBWAction1)
        self.menuNoiseMkrBW.addAction("1.0 nm", self.NoiseMkrBWAction2)
        self.buttonNoiseMkrBW.setMenu(self.menuNoiseMkrBW)
        self.buttonOSNR.setText("%s" %OSNRType)
        self.menuOSNR = QtWidgets.QMenu()
        self.menuOSNR.addAction("PIT", self.OSNRAction1)
        self.menuOSNR.addAction("Auto", self.OSNRAction2)
        self.menuOSNR.addAction("Manual", self.OSNRAction3)
        self.buttonOSNR.setMenu(self.menuOSNR)
        peakExcur = str(conversions.str2float(peakExcur,'dB'))
        self.linePeakExcur.setText("%s" %peakExcur)
        pitExcur = str(conversions.str2float(pitExcur,'dB'))
        self.linePitExcur.setText("%s" %pitExcur)
        validator = QtGui.QDoubleValidator()
        if OSNRType == 'MAN':
            self.lineOSNR.setText("%s" %OSNROffset)
            self.lineOSNR.setValidator(validator)
        else:
            self.lineOSNR.setText("DISABLED")
        if mkrThreshOnOff == 'ON':
            self.lineSrchThresh.setText("%s" %userMkrThresh)
            self.lineSrchThresh.setValidator(validator)
        else:
            self.lineSrchThresh.setText("DISABLED")

        # Prevent user input of non doubles
        validator = QtGui.QDoubleValidator()
        self.linePeakExcur.setValidator(validator)
        self.linePitExcur.setValidator(validator)

        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def NormMkrUnitsAction1(self):
        self.buttonNormMkrUnits.setText("nm")

    def NormMkrUnitsAction2(self):
        self.buttonNormMkrUnits.setText("um")

    def NormMkrUnitsAction3(self):
        self.buttonNormMkrUnits.setText("Ang")

    def NormMkrUnitsAction4(self):
        self.buttonNormMkrUnits.setText("GHz")

    def NormMkrUnitsAction5(self):
        self.buttonNormMkrUnits.setText("THz")

    def BWMkrUnitsAction1(self):
        self.buttonBWMkrUnits.setText("nm")

    def BWMkrUnitsAction2(self):
        self.buttonBWMkrUnits.setText("um")

    def BWMkrUnitsAction3(self):
        self.buttonBWMkrUnits.setText("Ang")

    def BWMkrUnitsAction4(self):
        self.buttonBWMkrUnits.setText("GHz")

    def BWMkrUnitsAction5(self):
        self.buttonBWMkrUnits.setText("THz")

    def DeltaMkrUnitsAction1(self):
        self.buttonDeltaMkrUnits.setText("nm")

    def DeltaMkrUnitsAction2(self):
        self.buttonDeltaMkrUnits.setText("um")

    def DeltaMkrUnitsAction3(self):
        self.buttonDeltaMkrUnits.setText("Ang")

    def DeltaMkrUnitsAction4(self):
        self.buttonDeltaMkrUnits.setText("GHz")

    def DeltaMkrUnitsAction5(self):
        self.buttonDeltaMkrUnits.setText("THz")

    def MkrInterpAction1(self):
        self.buttonMkrInterp.setText("ON")

    def MkrInterpAction2(self):
        self.buttonMkrInterp.setText("OFF")

    def BWMkrInterpAction1(self):
        self.buttonBWMkrInterp.setText("ON")

    def BWMkrInterpAction2(self):
        self.buttonBWMkrInterp.setText("OFF")

    def UserMkrThreshAction1(self):
        self.buttonUserMkrThresh.setText("ON")
        self.lineSrchThresh.setText("%s" %userMkrThresh)
        self.lineSrchThresh.setValidator(validator)

    def UserMkrThreshAction2(self):
        self.buttonUserMkrThresh.setText("OFF")
        self.lineSrchThresh.setText("DISABLED")

    def NoiseMkrBWAction1(self):
        self.buttonNoiseMkrBW.setText("0.1 nm")

    def NoiseMkrBWAction2(self):
        self.buttonNoiseMkrBW.setText("1.0 nm")

    def OSNRAction1(self):
        self.buttonOSNR.setText("PIT")
        self.lineOSNR.setText("DISABLED")

    def OSNRAction2(self):
        self.buttonOSNR.setText("AUTO")
        self.lineOSNR.setText("DISABLED")

    def OSNRAction3(self):
        self.buttonOSNR.setText("MAN")
        self.lineOSNR.setText("%s" %OSNROffset)
        self.lineOSNR.setValidator(validator)

    def onAccept(self):
        global mkr_units
        global BW_units
        global delta_units
        global mkrInterpOnOff
        global BWInterpOnOff
        global mkrThreshOnOff
        global noiseMkrBW
        global OSNRType
        global OSNROffset
        global peakExcur
        global pitExcur
        global userMkrThresh
        global active_marker
        mkr_units = self.buttonNormMkrUnits.text()
        delta_units = self.buttonDeltaMkrUnits.text()
        BW_units = self.buttonBWMkrUnits.text()

        if self.buttonMkrInterp.text() == "ON":
            mkrInterpOnOff = 'ON'
            my_instrument.write("CALCulate:MARKer%s:INT 1" %active_marker)
        else:
            mkrInterpOnOff = 'OFF'
            my_instrument.write("CALCulate:MARKer%s:INT 0" %active_marker)

        if self.buttonBWMkrInterp.text() == "ON":
            BWInterpOnOff = 'ON'
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:BANDwidth:INT 1" %active_marker)
        else:
            BWInterpOnOff = 'OFF'
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:BANDwidth:INT 0" %active_marker)

        peakExcur = str(self.linePeakExcur.text()).rstrip()
        

        my_instrument.write("CALCulate:MARKer%s:PEXCursion:PEAK %sdB" %(active_marker,peakExcur))

        pitExcur = str(self.linePitExcur.text()).rstrip()
        my_instrument.write("CALCulate:MARKer%s:PEXCursion:PIT %sdB" %(active_marker,pitExcur))

        if self.buttonUserMkrThresh.text() == "ON":
            mkrThreshOnOff = 'ON'
            my_instrument.write("CALCulate:THReshold:STATe 1")
            userMkrThresh = str(self.lineSrchThresh.text()).rstrip()
            my_instrument.write("CALCulate:THReshold %sdBm" %userMkrThresh)
        else:
            mkrThreshOnOff = 'OFF'
            my_instrument.write("CALCulate:THReshold:STATe 0")

        if self.buttonNoiseMkrBW.text() == "0.1 nm":
            noiseMkrBW = '0.1'
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:NOISe:BANDwidth 0.1nm" %active_marker)
        else:
            noiseMkrBW = '1.0'
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:NOISe:BANDwidth 1nm" %active_marker)

        if self.buttonOSNR.text() == "MAN":
            OSNRType = 'MAN'
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:OSNR:MODE %s" %(active_marker, OSNRType))
            OSNROffset = str(self.lineOSNR.text()).rstrip()
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:OSNR:OFFSet %snm" %(active_marker, OSNROffset))
        elif self.buttonOSNR.text() == "AUTO":
            OSNRType = 'AUTO'
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:OSNR:MODE %s" %(active_marker, OSNRType))
        else:
            OSNRType = 'PIT'
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:OSNR:MODE %s" %(active_marker, OSNRType))


    def onReject(self):
        return


class AdvancedLineMarkerWindow(QtWidgets.QDialog, Ui_advancedLineMarkerWindow):
    def __init__(self, parent=None):
        super(AdvancedLineMarkerWindow, self).__init__(parent)
        global search_limit
        global sweep_limit
        global integral_limit
        global trace_integral
        self.setupUi(self)

        self.buttonSweepLimit.setText("%s" %sweep_limit)
        self.menuSweepLimit = QtWidgets.QMenu()
        self.menuSweepLimit.addAction("On", self.SweepLimitAction1)
        self.menuSweepLimit.addAction("Off", self.SweepLimitAction2)
        self.buttonSweepLimit.setMenu(self.menuSweepLimit)
        self.buttonSrchLimit.setText("%s" %search_limit)
        self.menuSrchLimit = QtWidgets.QMenu()
        self.menuSrchLimit.addAction("On", self.SrchLimitAction1)
        self.menuSrchLimit.addAction("Off", self.SrchLimitAction2)
        self.buttonSrchLimit.setMenu(self.menuSrchLimit)
        self.buttonIntegLimit.setText("%s" %integral_limit)
        self.menuIntegLimit = QtWidgets.QMenu()
        self.menuIntegLimit.addAction("On", self.IntegLimitAction1)
        self.menuIntegLimit.addAction("Off", self.IntegLimitAction2)
        self.buttonIntegLimit.setMenu(self.menuIntegLimit)
        self.buttonTraceInteg.setText("%s" %trace_integral)
        self.menuTraceInteg = QtWidgets.QMenu()
        self.menuTraceInteg.addAction("On", self.TraceIntegAction1)
        self.menuTraceInteg.addAction("Off", self.TraceIntegAction2)
        self.buttonTraceInteg.setMenu(self.menuTraceInteg)

        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def SweepLimitAction1(self):
        self.buttonSweepLimit.setText("On")

    def SweepLimitAction2(self):
        self.buttonSweepLimit.setText("Off")

    def SrchLimitAction1(self):
        self.buttonSrchLimit.setText("On")

    def SrchLimitAction2(self):
        self.buttonSrchLimit.setText("Off")

    def IntegLimitAction1(self):
        self.buttonIntegLimit.setText("On")

    def IntegLimitAction2(self):
        self.buttonIntegLimit.setText("Off")

    def TraceIntegAction1(self):
        self.buttonTraceInteg.setText("On")

    def TraceIntegAction2(self):
        self.buttonTraceInteg.setText("Off")

    def onAccept(self):
        global search_limit
        global sweep_limit
        global integral_limit
        global trace_integral
        global lineMarkerOnOff
        if self.buttonSweepLimit.text() == 'On':
            my_instrument.write("SENSe:WAVelength:SRANge:STATe ON")
            self.buttonSweepLimit.setText("On")
            sweep_limit = 'On'
            sweep_flag = '1'
        elif self.buttonSweepLimit.text() == 'Off':
            my_instrument.write("SENSe:WAVelength:SRANge:STATe OFF")
            self.buttonSweepLimit.setText("Off")
            sweep_limit = 'Off'
            sweep_flag = '0'

        if self.buttonSrchLimit.text() == 'On':
            my_instrument.write("CALCulate:MARKer:SRANge:STATe ON")
            self.buttonSrchLimit.setText("On")
            search_limit = 'On'
            search_flag = '1'
        elif self.buttonSrchLimit.text() == 'Off':
            my_instrument.write("CALCulate:MARKer:SRANge:STATe OFF")
            self.buttonSrchLimit.setText("Off")
            search_limit = 'Off'
            search_flag = '0'

        if self.buttonIntegLimit.text() == 'On':
            my_instrument.write("CALCulate:TPOWer:IRANge:STATe ON")
            self.buttonIntegLimit.setText("On")
            integral_limit = 'On'
        elif self.buttonIntegLimit.text() == 'Off':
            my_instrument.write("CALCulate:TPOWer:IRANge:STATe OFF")
            self.buttonIntegLimit.setText("Off")
            integral_limit = 'Off'

        if self.buttonTraceInteg.text() == 'On':
            my_instrument.write("CALCulate:TPOWer:STATe ON")
            self.buttonTraceInteg.setText("On")
            trace_integral = 'On'
        elif self.buttonTraceInteg.text() == 'Off':
            my_instrument.write("CALCulate:TPOWer:STATe OFF")
            self.buttonTraceInteg.setText("Off")
            trace_integral = 'Off'

        if sweep_limit == 'On' or search_limit == 'On' or integral_limit == 'On' or trace_integral == 'On':
            print('in on of on')
            lineMarkerOnOff = 'On'

        else:
            lineMarkerOnOff = 'Off'


    def onReject(self):
        return


class SystemWindow(QtWidgets.QDialog, Ui_systemWindow):
    def __init__(self, parent=None):
        super(SystemWindow, self).__init__(parent)
        self.setupUi(self)
        
        self.buttonSigSource.setText("External")
        self.menuSigSource = QtWidgets.QMenu()
        self.menuSigSource.addAction("External", self.SigSourceAction1)
        self.menuSigSource.addAction("Calibrator", self.SigSourceAction2)
        self.buttonSigSource.setMenu(self.menuSigSource)
        self.buttonWLRef.setText("%s" %wavelengthRefIn)
        self.menuWLRef = QtWidgets.QMenu()
        self.menuWLRef.addAction("Air", self.WLRefAction1)
        self.menuWLRef.addAction("Vacuum", self.WLRefAction2)
        self.buttonWLRef.setMenu(self.menuWLRef)

        # Populate text fields
        self.labelFacPowCal.setText(str(my_instrument.query("CALibration:DATE?")).rstrip())
        self.labelUserPowCal.setText(str(my_instrument.query("CALibration:POWer:DATE?")).rstrip())
        self.lineCalPower.setText("%s" %Power_Calibration)
        self.lineCalWL.setText("%s" %Power_Calibration)

        self.labelFacWLCal.setText(str(my_instrument.query("CALibration:DATE?")).rstrip()) 
        self.labelUserWLCal.setText(str(my_instrument.query("CALibration:WAVelength:DATE?")).rstrip())

        self.firmwareLabel.setText(str(my_instrument.query("*IDN?")).rstrip())

        # Prevent user input of non doubles
        validator = QtGui.QDoubleValidator()
        self.lineCalWL.setValidator(validator)
        self.lineCalPower.setValidator(validator)  
        self.lineSetCalWL.setValidator(validator) 

        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)   

    def SigSourceAction1(self):
        self.buttonSigSource.setText("External")

    def SigSourceAction2(self):
        self.buttonSigSource.setText("Calibrator")

    def WLRefAction1(self):
        self.buttonWLRef.setText("Air")

    def WLRefAction2(self):
        self.buttonWLRef.setText("Vacuum")

    def onAccept(self):
        if self.buttonWLRef.text() == "AIR":
            my_instrument.write("SENSe:CORRection:RVELocity:MEDium AIR")
            wavelengthRefIn = "AIR"
            self.buttonWLRef.setText("AIR")
        else:
            my_instrument.write("SENSe:CORRection:RVELocity:MEDium VAC")
            wavelengthRefIn = "VAC"
            self.buttonWLRef.setText("VAC")
        return

    def onReject(self):
        return

class NewMarkerWindow(QtWidgets.QDialog, Ui_newMarkerWindow):
        def __init__(self, active_marker, active_trace, trace_a_param, trace_b_param, trace_c_param, trace_d_param, trace_e_param, trace_f_param, parent=None):
                super(NewMarkerWindow, self).__init__(parent)
                self.setupUi(self)

                self.buttonMkrSel.setText("Mkr %s" %active_marker)
                self.menuMkrSel = QtWidgets.QMenu()
                self.menuMkrSel.addAction("Mkr 1", self.MkrSelAction1)
                self.menuMkrSel.addAction("Mkr 2", self.MkrSelAction2)
                self.menuMkrSel.addAction("Mkr 3", self.MkrSelAction3)
                self.menuMkrSel.addAction("Mkr 4", self.MkrSelAction4)
                self.buttonMkrSel.setMenu(self.menuMkrSel)
                self.buttonTrcSel.setText("Trace %s" %active_trace[2])
                self.menuTrcSel = QtWidgets.QMenu()
                if trace_a_param[1] == 'ON':
                    self.menuTrcSel.addAction("Trace A", self.TrcSelAction1)
                if trace_b_param[1] == 'ON':
                    self.menuTrcSel.addAction("Trace B", self.TrcSelAction2)
                if trace_c_param[1] == 'ON':
                    self.menuTrcSel.addAction("Trace C", self.TrcSelAction3)
                if trace_d_param[1] == 'ON':
                    self.menuTrcSel.addAction("Trace D", self.TrcSelAction4)
                if trace_e_param[1] == 'ON':
                    self.menuTrcSel.addAction("Trace E", self.TrcSelAction5)
                if trace_f_param[1] == 'ON':
                    self.menuTrcSel.addAction("Trace F", self.TrcSelAction6)
                self.buttonTrcSel.setMenu(self.menuTrcSel)

                self.accepted.connect(self.onAccept)
                self.rejected.connect(self.onReject)

        def MkrSelAction1(self):
                self.buttonMkrSel.setText("Mkr 1")

        def MkrSelAction2(self):
                self.buttonMkrSel.setText("Mkr 2")

        def MkrSelAction3(self):
                self.buttonMkrSel.setText("Mkr 3")

        def MkrSelAction4(self):
                self.buttonMkrSel.setText("Mkr 4")

        def TrcSelAction1(self):
                self.buttonTrcSel.setText("Trace A")

        def TrcSelAction2(self):
                self.buttonTrcSel.setText("Trace B")

        def TrcSelAction3(self):
                self.buttonTrcSel.setText("Trace C")

        def TrcSelAction4(self):
                self.buttonTrcSel.setText("Trace D")

        def TrcSelAction5(self):
                self.buttonTrcSel.setText("Trace E")

        def TrcSelAction6(self):
                self.buttonTrcSel.setText("Trace F")

        def onAccept(self):
                self.marker = self.buttonMkrSel.text()
                self.trace = self.buttonTrcSel.text()
                self.selection = 1
                return self.marker, self.trace, self.selection

        def onReject(self):
                self.selection = 0
                return self.selection


# Main window
class MainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)
        self.actionNew_Instrument.triggered.connect(self.instrumentSelectWindow)
        self.actionClose_Instrument.triggered.connect(self.closeTab)
        self.tabWidget.tabCloseRequested.connect(self.closeTab)

    def instrumentSelectWindow(self):
        widget = InstrumentSelect(parent=self)
        widget.exec_()
        if widget.selection != 0:
                self.openInstrument(widget.selection)

    def openInstrument(self, device):
        if device == "AGILENT 86142B":
            indice = [i for i, s in enumerate(devices_info) if 'AGILENT 86142B' in s]
            print(indice)
            indice = indice[0]
            instrument_address = address[indice]
            global my_instrument
            my_instrument = rm.open_resource('%s' %instrument_address)
            self.tab = Agilent86142B()
            global flag
            flag = 1
        elif device == "HEWLETT PACKARD 8157A":
            indice = [i for i, s in enumerate(devices_info) if 'HEWLETT PACKARD 8157A' in s]
            indice = indice[0]
            instrument_address = address[indice]
            global my_insturment2
            my_instrument2 = rm.open_resource('%s' %instrument_address)
            self.tab = hp8157A()
        elif device == "ANDO AQ-4303":
            indice = [i for i, s in enumerate(devices_info) if 'ANDO AQ-4303' in s]
            print(indice)
            indice = indice[0]
            print(indice)
            instrument_address = address[indice]
            global my_instrument3
            my_instrument3 = rm.open_resource('%s' %instrument_address)
            self.tab = AQ4303B()
        elif device == "":
            return
        self.tabWidget.addTab(self.tab, "%s" %device)

    def closeTab(self, currentIndex):
        currentQWidget = self.tabWidget.widget(currentIndex)
        currentQWidget.deleteLater()
        self.tabWidget.removeTab(currentIndex)


def main():
    app = QtWidgets.QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())
    

if __name__ == '__main__':
    main()
