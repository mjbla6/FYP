# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindowalt.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 500)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(MainWindow.sizePolicy().hasHeightForWidth())
        MainWindow.setSizePolicy(sizePolicy)
        MainWindow.setMaximumSize(QtCore.QSize(1920, 1080))
        self.centralWidget = QtWidgets.QWidget(MainWindow)
        self.centralWidget.setObjectName("centralWidget")
        self.gridLayout = QtWidgets.QGridLayout(self.centralWidget)
        self.gridLayout.setContentsMargins(11, 11, 11, 11)
        self.gridLayout.setSpacing(6)
        self.gridLayout.setObjectName("gridLayout")
        MainWindow.setCentralWidget(self.centralWidget)
        self.mainToolBar = QtWidgets.QToolBar(MainWindow)
        self.mainToolBar.setObjectName("mainToolBar")
        MainWindow.addToolBar(QtCore.Qt.TopToolBarArea, self.mainToolBar)
        self.statusBar = QtWidgets.QStatusBar(MainWindow)
        self.statusBar.setObjectName("statusBar")
        MainWindow.setStatusBar(self.statusBar)
        self.menuBar = QtWidgets.QMenuBar(MainWindow)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 800, 22))
        self.menuBar.setObjectName("menuBar")
        self.menu_File = QtWidgets.QMenu(self.menuBar)
        self.menu_File.setObjectName("menu_File")
        self.menuInstrument = QtWidgets.QMenu(self.menuBar)
        self.menuInstrument.setObjectName("menuInstrument")
        self.menuExport = QtWidgets.QMenu(self.menuInstrument)
        self.menuExport.setObjectName("menuExport")
        self.menuImport = QtWidgets.QMenu(self.menuInstrument)
        self.menuImport.setObjectName("menuImport")
        MainWindow.setMenuBar(self.menuBar)
        self.actionNew_Instrument = QtWidgets.QAction(MainWindow)
        self.actionNew_Instrument.setObjectName("actionNew_Instrument")
        self.actionRaw_Data = QtWidgets.QAction(MainWindow)
        self.actionRaw_Data.setObjectName("actionRaw_Data")
        self.actionGraphical = QtWidgets.QAction(MainWindow)
        self.actionGraphical.setObjectName("actionGraphical")
        self.actionRaw_Data_2 = QtWidgets.QAction(MainWindow)
        self.actionRaw_Data_2.setObjectName("actionRaw_Data_2")
        self.actionClose_Instrument = QtWidgets.QAction(MainWindow)
        self.actionClose_Instrument.setObjectName("actionClose_Instrument")
        self.menu_File.addAction(self.actionNew_Instrument)
        self.menu_File.addAction(self.actionClose_Instrument)
        self.menu_File.addSeparator()
        self.menuExport.addAction(self.actionRaw_Data)
        self.menuExport.addAction(self.actionGraphical)
        self.menuImport.addAction(self.actionRaw_Data_2)
        self.menuInstrument.addAction(self.menuImport.menuAction())
        self.menuInstrument.addAction(self.menuExport.menuAction())
        self.menuBar.addAction(self.menu_File.menuAction())
        self.menuBar.addAction(self.menuInstrument.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.menu_File.setTitle(_translate("MainWindow", "&File"))
        self.menuInstrument.setTitle(_translate("MainWindow", "Instrument"))
        self.menuExport.setTitle(_translate("MainWindow", "Export..."))
        self.menuImport.setTitle(_translate("MainWindow", "Import..."))
        self.actionNew_Instrument.setText(_translate("MainWindow", "New Instrument"))
        self.actionNew_Instrument.setShortcut(_translate("MainWindow", "Ctrl+N"))
        self.actionRaw_Data.setText(_translate("MainWindow", "Raw Data"))
        self.actionGraphical.setText(_translate("MainWindow", "Graphical"))
        self.actionRaw_Data_2.setText(_translate("MainWindow", "Raw Data"))
        self.actionClose_Instrument.setText(_translate("MainWindow", "Close Instrument"))
        self.actionClose_Instrument.setShortcut(_translate("MainWindow", "Ctrl+W"))

