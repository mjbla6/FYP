# Remote Interface FYP 2018
# Mitch Blair & Isaac Naylor
#
# Last edit: 13/09/2018

## TODO: WAVELENGTH MENU -> Wavelength Setup -> Centre Wavelength Step Size (not displayed correcty)
## TODO: AMPLITUDE MENU -> Sensitivity [MAN] -> input dialog box needs conversion
## TODO: MARKER SETUP MENU

from PyQt5 import QtCore, QtGui, QtWidgets
import sys
from gui_mainwindow import Ui_MainWindow
from gui_instrumentselect import Ui_instrumentSelect
from gui_inputdialog import Ui_inputDialog
from gui_agilent86142b import Ui_Agilent86142B
from gui_amplitudesetupwindow import Ui_amplitudeSetupWindow
from gui_wavelengthsetupwindow import Ui_wavelengthSetupWindow
from gui_activemarkerswindow import Ui_activeMarkersWindow
from gui_markersetupwindow import Ui_markerSetupWindow
from gui_advancedlinemarkerwindow import Ui_advancedLineMarkerWindow
from gui_systemwindow import Ui_systemWindow
from gui_hp8157a import Ui_HP8157A
from gui_aq4303b import Ui_AQ4303B
from threading import Thread, Event
import visa
import math
import numpy
import visa_manager
import conversions
import pyqtgraph as pg
import ast
import time, threading
from graphPlot import display

## VISA query to find available resources. Interacts with the visa_manager
## function to obtain information about the connected devices
rm = visa.ResourceManager()
resources =  rm.list_resources()
devices_info = visa_manager.devices()
address = visa_manager.GPIB_address()
num_devices = visa_manager.num_devices()

## Instrument select class adds in all available devices to the
## UI on start up and on click will start that machine process
class InstrumentSelect(QtWidgets.QDialog, Ui_instrumentSelect):
    def __init__(self, parent=None):
        super(InstrumentSelect, self).__init__(parent)
        self.setupUi(self)
        i = 0
        while i < num_devices:
            self.listWidget.addItem("%s" %devices_info[i])
            i += 1
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def onAccept(self):
    	self.item = str(self.listWidget.currentItem())
    	if self.item == 'None':
    		self.selection = 0
    		return self.selection
    	else:
    		self.selection = self.listWidget.currentItem().text()
    		return self.selection

    def onReject(self):
        self.selection = ""
        return self.selection

## Predefining global variable
wavelength_name = "Wave"
amplitude_name = "Amp"
wavelength_units = ''
wavelength_units_display = ''
amplitude_units = ''
time_units = ''
my_instrument = ''
active_marker = ''
active_marker_matrix = ''
active_trace = ''
active_trace_num = ''
logLin = ''
autoMan =''
traceIntOnOff = ''
peakPit = ''
upDown = ''
markerBWOnOff =''
noiseMarkOnOff = ''
deltaMarkOnOff = ''
osnrMarkOnOff = ''
mkrTrc = ''
updateTraceOnOff = ''
viewTraceOnOff = ''
holdTraceNoneMinMax = ''
averagingOnOff = ''
resBwManAuto = ''
vidBwManAuto = ''
sweepTimeManAuto = ''
repeatSweepOnOff = ''
trigSyncLowHighPulse = ''
syncOutOnOff = ''
wavelengthOffset = ''
wavelengthStepSize = ''
wavelengthRefIn = ''
interval = 5
flag = ''
p1 = ''
num_points = ''
auto_ranging = ''
amplitude_correction = ''
amplitude_correction_mode = ''
Integration_Limit_1 = ''
Integration_Limit_2 = ''
Default_Math = ''
Trigger_Mode = ''
Power_Calibration = ''
Wavelength_Calibration = ''
trace_a_data = ''
trace_b_data = ''
trace_c_data = ''
trace_d_data = ''
trace_e_data = ''
trace_f_data = ''
marker_data_array = ''
frequency_units = 'kHz'

##class MyThread(Thread):
##    def __init__(self, event):
##        Thread.__init__(self)
##        self.stopped = event
##
##    def run(self):
##        while not self.stopped.wait(3):
##            print("Thread is running..")
##            print(flag)
##            if flag == 1:
##                print('running')
##                display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units,amplitude_units,num_points)

## Main class for the HP8157A machine
## TODO: move this out to a separate file
class hp8157A(QtWidgets.QWidget, Ui_HP8157A):
    def __init__(self, parent=None):
        super(hp8157A, self).__init__(parent)
        self.setupUi(self)

        att = my_instrument2.query("ATT?")
        self.spinBoxATT.setValue(float(att))
        cal = my_instrument2.query("CAL?")
        self.spinBoxCAL.setValue(float(cal))
        self.lcdAtt.display(float(att) + float(cal))
        wvl = my_instrument2.query("WVL?")
        wvl = float(wvl)
        wvl = wvl*(1000000000)
        wvl = int(wvl)
        self.spinBoxWL.setValue(wvl)
        D = my_instrument2.query("D?")
        D = int(D)
        if (D == 1):
            self.buttonDisable.setChecked(True)

        self.spinBoxATT.valueChanged.connect(self.valueChange)
        self.spinBoxCAL.valueChanged.connect(self.valueChange)
        self.spinBoxWL.valueChanged.connect(self.valueChange)
        self.buttonDisable.clicked.connect(self.unitEnable)

    def valueChange(self):
        self.lcdAtt.display(self.spinBoxATT.value() + self.spinBoxCAL.value())
        my_instrument2.write("WVL %i NM" % self.spinBoxWL.value())
        my_instrument2.write("CAL %f dB" % self.spinBoxCAL.value())
        my_instrument2.write("ATT %f dB" % self.spinBoxATT.value()) 

    def unitEnable(self):
        if self.buttonDisable.isChecked():
            my_instrument2.write("D1")
        else:
            my_instrument2.write("D0")

class AQ4303B(QtWidgets.QWidget, Ui_AQ4303B):
    def __init__(self, parent=None):
        super(AQ4303B, self).__init__(parent)
        self.setupUi(self)
        my_instrument3.write("B")
        my_instrument3.write("C")
        light = '270Hz'
        wavelength = '400-600'
        self.buttonWL.setText(wavelength)
        self.buttonLight.setText(light)

        self.WL = QtWidgets.QMenu()
        self.WL.addAction("400-600", self.WLAction1)
        self.WL.addAction("600-1000", self.WLAction2)
        self.WL.addAction("1000-1800", self.WLAction3)
        self.buttonWL.setMenu(self.WL)

        self.lightMenu = QtWidgets.QMenu()
        self.lightMenu.addAction("CW", self.lightMenuAction1)
        self.lightMenu.addAction("270Hz", self.lightMenuAction2)
        self.buttonLight.setMenu(self.lightMenu)

    def lightMenuAction1(self):
        self.buttonLight.setText("CW")
        my_instrument3.write("A")

    def lightMenuAction2(self):
        self.buttonLight.setText("270Hz")
        my_instrument3.write("B")

    def WLAction1(self):
        self.buttonWL.setText("400-600")
        my_instrument3.write("C")

    def WLAction2(self):
        self.buttonWL.setText("600-1000")
        my_instrument3.write("D")

    def WLAction3(self):
        self.buttonWL.setText("1000-1800")
        my_instrument3.write("E")

##my_event = Event()
##thread = MyThread(my_event)
##thread.start()

# Main class for the Agilent 86142B OSA
# TO DO: Move this out as a separate file
class Agilent86142B(QtWidgets.QWidget, Ui_Agilent86142B):
    def __init__(self, parent=None):
        super(Agilent86142B, self).__init__(parent)
        self.setupUi(self)
        self.setupInstrument()
        self.infoDisplay()
        my_instrument.timeout = 20000
        #self.plot = pg.GraphicsWindow()
        #self.p1 = self.plot.addPlot()
        self.p1 = pg.PlotWidget()
        self.p1.showGrid(x=True, y=True)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.wavelengthMenu()

        # Setup mouse events on graph
        mypen = pg.mkPen('y', width=1)
        self.curve = self.p1.plot(x=[], y=[], pen=mypen)
        self.curve.scene().sigMouseMoved.connect(self.onMouseMoved)
        self.p1.scene().sigMouseClicked.connect(self.onMouseClicked)

        # Active buttons
        self.buttonActMkrGbl.setText("Mkr %s" %active_marker)
        self.menuActMkrGbl = QtWidgets.QMenu()
        self.menuActMkrGbl.addAction("Mkr 1", self.ActMkrGbl1)
        self.menuActMkrGbl.addAction("Mkr 2", self.ActMkrGbl2)
        self.menuActMkrGbl.addAction("Mkr 3", self.ActMkrGbl3)
        self.menuActMkrGbl.addAction("Mkr 4", self.ActMkrGbl4)
        self.buttonActMkrGbl.setMenu(self.menuActMkrGbl)
        self.buttonActTrcGbl.setText("Trace %s" %active_trace[2])
        self.menuActTrcGbl = QtWidgets.QMenu()
        self.menuActTrcGbl.addAction("Trace A", self.ActTrcGbl1)
        self.menuActTrcGbl.addAction("Trace B", self.ActTrcGbl2)
        self.menuActTrcGbl.addAction("Trace C", self.ActTrcGbl3)
        self.menuActTrcGbl.addAction("Trace D", self.ActTrcGbl4)
        self.menuActTrcGbl.addAction("Trace E", self.ActTrcGbl5)
        self.menuActTrcGbl.addAction("Trace F", self.ActTrcGbl6)
        self.buttonActTrcGbl.setMenu(self.menuActTrcGbl)
        self.buttonSystem.clicked.connect(self.systemMenu)
        self.buttonDispDisable.setText("Off")
        self.menuDispDisable = QtWidgets.QMenu()
        self.menuDispDisable.addAction("On", self.DisableDispAction1)
        self.menuDispDisable.addAction("Off", self.DisableDispAction2)
        self.buttonDispDisable.setMenu(self.menuDispDisable)

        # Top menu buttons clicked
        self.buttonWavelength.clicked.connect(self.wavelengthMenu)
        self.buttonAmplitude.clicked.connect(self.amplitudeMenu)
        self.buttonMarkers.clicked.connect(self.markersMenu)
        self.buttonTraces.clicked.connect(self.tracesMenu)
        self.buttonBW.clicked.connect(self.bwMenu)

        # Bottom menu button clicked
        self.buttonAutoMeasure.clicked.connect(self.autoMeasure)
        self.buttonAutoAlign.clicked.connect(self.autoAlign)

    def ActMkrGbl1(self):
        self.buttonActMkrGbl.setText("Mkr 1")
        global active_marker
        active_marker = '1'
        global mkr_1_param
        mkr_1_param[0] = '1'
        global active_mkr_param
        active_mkr_param = mkr_1_param
        my_instrument.write("CALCulate:MARKer1:STATe ON")
        self.mkr1Display()
        self.mkrCompDisplay()
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 2:
            self.moreMkrFunc()

    def ActMkrGbl2(self):
        self.buttonActMkrGbl.setText("Mkr 2")
        global active_marker
        active_marker = '2'
        global mkr_2_param
        mkr_2_param[0] = '1'
        global active_mkr_param
        active_mkr_param = mkr_2_param
        my_instrument.write("CALCulate:MARKer2:STATe ON")
        self.mkr2Display()
        self.mkrCompDisplay()
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 2:
            self.moreMkrFunc()

    def ActMkrGbl3(self):
        self.buttonActMkrGbl.setText("Mkr 3")
        global active_marker
        active_marker = '3'
        global mkr_3_param
        mkr_3_param[0] = '1'
        global active_mkr_param
        active_mkr_param = mkr_3_param
        my_instrument.write("CALCulate:MARKer3:STATe ON")
        self.mkr3Display()
        self.mkrCompDisplay()
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 2:
            self.moreMkrFunc()

    def ActMkrGbl4(self):
        self.buttonActMkrGbl.setText("Mkr 4")
        global active_marker
        active_marker = '4'
        global mkr_4_param
        mkr_4_param[0] = '1'
        global active_mkr_param
        active_mkr_param = mkr_4_param
        my_instrument.write("CALCulate:MARKer4:STATe ON")
        self.mkr4Display()
        self.mkrCompDisplay()
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 2:
            self.moreMkrFunc()

    def ActTrcGbl1(self):
        self.buttonActTrcGbl.setText("Trace A")
        global active_trace
        active_trace = "TRA"
        global active_trace_num
        active_trace_num = '1'
        global trace_a_param
        trace_a_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_a_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()
        #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
        #        trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ActTrcGbl2(self):
        self.buttonActTrcGbl.setText("Trace B")
        global active_trace
        active_trace = "TRB"
        global active_trace_num
        active_trace_num = '2'
        global trace_b_param
        trace_b_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_b_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()
        #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
        #        trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ActTrcGbl3(self):
        self.buttonActTrcGbl.setText("Trace C")
        global active_trace
        active_trace = "TRC"
        global active_trace_num
        active_trace_num = '3'
        global trace_c_param
        trace_c_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_c_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()
        #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
        #        trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ActTrcGbl4(self):
        self.buttonActTrcGbl.setText("Trace D")
        global active_trace
        active_trace = "TRD"
        global active_trace_num
        active_trace_num = '4'
        global trace_d_param
        trace_d_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_d_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()
        #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
        #        trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ActTrcGbl5(self):
        self.buttonActTrcGbl.setText("Trace E")
        global active_trace
        active_trace = "TRE"
        global active_trace_num
        active_trace_num = '5'
        global trace_e_param
        trace_e_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_e_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()
        #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
        #        trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ActTrcGbl6(self):
        self.buttonActTrcGbl.setText("Trace F")
        global active_trace
        active_trace = "TRF"
        global active_trace_num
        active_trace_num = '6'
        global trace_f_param
        trace_f_param[1] = 'ON'
        global active_trace_param
        active_trace_param = trace_f_param
        global menuFlag
        if menuFlag == 1:
            self.markersMenu()
        if menuFlag == 3:
            self.tracesMenu()
        #display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
        #        trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def updateMkrParam(self):
        global active_marker
        global active_mkr_param
        global mkr_1_param
        global mkr_2_param
        global mkr_3_param
        global mkr_4_param

        if active_marker == '1':
            mkr_1_param = active_mkr_param
        if active_marker == '2':
            mkr_2_param = active_mkr_param
        if active_marker == '3':
            mkr_3_param = active_mkr_param
        if active_marker == '4':
            mkr_4_param = active_mkr_param

    def updateTrcParam(self):
        global active_trace_num
        global trace_a_param
        global trace_b_param
        global trace_c_param
        global trace_d_param
        global trace_e_param
        global trace_f_param

        if active_trace_num == '1':
            trace_a_param = active_trace_param
        if active_trace_num == '2':
            trace_b_param = active_trace_param
        if active_trace_num == '3':
            trace_c_param = active_trace_param
        if active_trace_num == '4':
            trace_d_param = active_trace_param
        if active_trace_num == '5':
            trace_e_param = active_trace_param
        if active_trace_num == '6':
            trace_f_param = active_trace_param

    def onMouseMoved(self, point):
    	global p
    	p = self.p1.plotItem.vb.mapSceneToView(point)

    def onMouseClicked(self, event):
    	buttons = event.button()
    	if buttons == 1:
    		print("Left Click")
    		print("{}-{}".format(p.x(), p.y()))
    		self.dot = self.p1.plot([p.x()], [p.y()], symbol='o')
    	else:
    		print("Right Click")

    def autoMeasure(self):
        my_instrument.write("DISPlay:WINDow:TRACe:ALL:SCALe:AUTO")

    def autoAlign(self):
        my_instrument.write("CALibration:ALIGn")

    def DisableDispAction1(self):
        self.buttonDispDisable.setText("On")
        my_instrument.write("DISPlay:WINDow OFF")

    def DisableDispAction2(self):
        self.buttonDispDisable.setText("Off")
        my_instrument.write("DISPlay:WINDow ON")

    def systemMenu(self):
        widget = SystemWindow()
        widget.exec_()

    
    ## Setup instrument is run at start up of the OSA to query the machine and
    ## determine initial values and settings
    def setupInstrument(self): 
        global menuFlag
        menuFlag = 0

        global active_marker
        active_marker = '1'

        global active_trace
        global active_trace_num
        active_trace = "TRA"
        active_trace_num = "1"
        my_instrument.write("CALCulate:MARKer%s:TRACe TRA" %active_marker)

        global wavelength_units
        wavelength_units = "nm" 
        
        global wavelength_units_display
        if wavelength_units == 'nm' or wavelength_units == 'um':
            wavelength_units_display = 'm'
        elif wavelength_units == 'Ang':
            wavelength_units_display = 'Ang'
        else:
            wavelength_units_display = 'm'

        global logLin
        logLin = str(my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:SPACing?")).rstrip()

        global amplitude_units
        amplitude_units = str(my_instrument.query("UNIT:POW?")).rstrip()
        if amplitude_units == 'AUTO':
            amplitude_units = 'dB'
        else:
            amplitude_units  = 'W'

        global time_units
        time_units = 'us'

        global frequency_units
        frequency_units = 'kHz'

        global autoMan
        autoMan = str(my_instrument.query("SENSe:POWer:DC:RANGe:LOWer:AUTO?")).rstrip()
        if autoMan == "1":
            autoMan = "AUTO"
        elif autoMan == "0":
            autoMan = "MAN"

        global traceIntOnOff
        traceIntOnOff = str(my_instrument.query("CALCulate:TPOWer:STATe?")).rstrip()
        if traceIntOnOff == "1":
            traceIntOnOff = "ON"
        elif traceIntOnOff == "0":
            traceIntOnOff = "OFF"

        global peakPit
        peakPit = "PEAK"

        global upDown
        upDown = "Down"

## ------------------------------------------
##              MARKER PARAMETERS
## ------------------------------------------
        
        global mkrOnOff
        global markerBWOnOff
        global noiseMarkOnOff
        global deltaMarkOnOff
        global osnrMarkOnOff
        global mkrTrc
        global mkr_1_param
        global mkr_2_param
        global mkr_3_param
        global mkr_4_param
        mkr_1_param = [0, 0, 0, '0', '0', '0', '0', '0']
        mkr_2_param = [0, 0, 0, '0', '0', '0', '0', '0']
        mkr_3_param = [0, 0, 0, '0', '0', '0', '0', '0']
        mkr_4_param = [0, 0, 0, '0', '0', '0', '0', '0']

        for i in range(1,5):
            if i == 1:
                itrac = "1"
            if i == 2:
                itrac = "2"
            if i == 3:
                itrac = "3"
            if i == 4:
                itrac = "4"

            mkrOnOff = str(my_instrument.query("CALCulate:MARKer%s:STATe?" %itrac)).rstrip()

            markerBWOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe?" %itrac)).rstrip()
            if markerBWOnOff == "1":
                markerBWOnOff = "ON"
            elif markerBWOnOff == "0":
                markerBWOnOff = "OFF"

            noiseMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:NOISe:STATe?" %itrac)).rstrip()
            if noiseMarkOnOff == "1":
                noiseMarkOnOff = "ON"
            elif noiseMarkOnOff == "0":
                noiseMarkOnOff = "OFF"

            deltaMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:DELTa:STATe?" %itrac)).rstrip()
            if deltaMarkOnOff == "1":
                deltaMarkOnOff = "ON"
            elif deltaMarkOnOff == "0":
                deltaMarkOnOff = "OFF"

            osnrMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:DELTa:STATe?" %itrac)).rstrip()
            if osnrMarkOnOff == "1":
                osnrMarkOnOff = "ON"
            elif osnrMarkOnOff == "0":
                osnrMarkOnOff = "OFF"

            mkrTrc = str(my_instrument.query("CALCulate:MARKer%s:TRACe?" %itrac)).rstrip()

            if itrac == '1':
                mkr_1_param[3] = markerBWOnOff
                mkr_1_param[4] = noiseMarkOnOff
                mkr_1_param[5] = deltaMarkOnOff
                mkr_1_param[6] = osnrMarkOnOff
                mkr_1_param[7] = mkrTrc
            if itrac == '2':
                mkr_2_param[3] = markerBWOnOff
                mkr_2_param[4] = noiseMarkOnOff
                mkr_2_param[5] = deltaMarkOnOff
                mkr_2_param[6] = osnrMarkOnOff
                mkr_2_param[7] = mkrTrc
            if itrac == '3':
                mkr_3_param[3] = markerBWOnOff
                mkr_3_param[4] = noiseMarkOnOff
                mkr_3_param[5] = deltaMarkOnOff
                mkr_3_param[6] = osnrMarkOnOff
                mkr_3_param[7] = mkrTrc
            if itrac == '4':
                mkr_4_param[3] = markerBWOnOff
                mkr_4_param[4] = noiseMarkOnOff
                mkr_4_param[5] = deltaMarkOnOff
                mkr_4_param[6] = osnrMarkOnOff
                mkr_4_param[7] = mkrTrc

            if itrac == '1':
                mkr_1_param[0] = mkrOnOff
                self.mkr1Display()
            if itrac == '2':
                mkr_2_param[0] = mkrOnOff
                self.mkr2Display()
            if itrac == '3':
                mkr_3_param[0] = mkrOnOff
                self.mkr3Display()
            if itrac == '4':
                mkr_4_param[0] = mkrOnOff
                self.mkr4Display()

        global active_mkr_param
        active_mkr_param = [0, 0, 0, '0', '0', '0', '0', '0']

        if mkr_1_param[0] == '1':
            active_marker = '1'
        if mkr_2_param[0] == '1':
            active_marker = '2'
        if mkr_3_param[0] == '1':
            active_marker = '3'
        if mkr_4_param[0] == '1':
            active_marker = '4'
        print("Active Mkr: %s" %active_marker)

        if active_marker == '1':
            active_mkr_param = mkr_1_param
        if active_marker == '2':
            active_mkr_param = mkr_2_param
        if active_marker == '3':
            active_mkr_param = mkr_3_param
        if active_marker == '4':
            active_mkr_param = mkr_4_param

        self.mkrCompDisplay()

## ------------------------------------------
##              TRACE PARAMETERS
## ------------------------------------------

        global updateTraceOnOff
        global viewTraceOnOff
        global holdTraceNoneMinMax
        global averagingOnOff
        global trace_a_param
        global trace_b_param
        global trace_c_param
        global trace_d_param
        global trace_e_param
        global trace_f_param
        global trace_a_data
        global trace_b_data
        global trace_c_data
        global trace_d_data
        global trace_e_data
        global trace_f_data

        for i in range(1,7):
            if i == 1:
                itrac = "TRA"
            if i == 2:
                itrac = "TRB"
            if i == 3:
                itrac = "TRC"
            if i == 4:
                itrac = "TRD"
            if i == 5:
                itrac = "TRE"
            if i == 6:
                itrac = "TRF"
                
            updateTraceOnOff = str(my_instrument.query("TRACe:FEED:CONTrol? %s" %itrac)).rstrip()
            if updateTraceOnOff == "ALW":
                updateTraceOnOff = "ON"
            elif updateTraceOnOff == "NEV":
                updateTraceOnOff = "OFF"

            viewTraceOnOff = str(my_instrument.query("DISPlay:WINDow:TRACe:STATe? %s" %itrac)).rstrip()
            if viewTraceOnOff == "1":
                viewTraceOnOff = "ON"
            elif viewTraceOnOff == "0":
                viewTraceOnOff = "OFF"

            holdTraceMax = str(my_instrument.query("CALCulate%s:MAXimum:STATe?" %i)).rstrip()
            holdTraceMin = str(my_instrument.query("CALCulate%s:MINimum:STATe?" %i)).rstrip()
            if holdTraceMax == "1" and holdTraceMin == "0":
                holdTraceNoneMinMax = "MAX"
            elif holdTraceMax == "0" and holdTraceMin == "1":
                holdTraceNoneMinMax = "MIN"
            else:
                holdTraceNoneMinMax = "NONE"

            averagingOnOff = str(my_instrument.query("CALCulate%s:AVERage:STATe?" %i)).rstrip()
            if averagingOnOff == "1":
                averagingOnOff = "ON"
            elif averagingOnOff == "0":
                averagingOnOff = "OFF"

            if i == 1:
                trace_a_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_a_param)
            if i == 2:
                trace_b_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_b_param)
            if i == 3:
                trace_c_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_c_param)
            if i == 4:
                trace_d_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_d_param)
            if i == 5:
                trace_e_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_e_param)
            if i == 6:
                trace_f_param = [updateTraceOnOff,viewTraceOnOff,holdTraceNoneMinMax,averagingOnOff]
                print(trace_f_param)

        global active_trace_param
        if active_trace_num == '1':
            active_trace_param = trace_a_param
        if active_trace_num == '2':
            active_trace_param = trace_b_param
        if active_trace_num == '3':
            active_trace_param = trace_c_param
        if active_trace_num == '4':
            active_trace_param = trace_d_param
        if active_trace_num == '5':
            active_trace_param = trace_e_param
        if active_trace_num == '6':
            active_trace_param = trace_f_param

## ------------------------------------------
##              OTHER PARAMETERS
## ------------------------------------------

        global resBwManAuto
        resBwManAuto = str(my_instrument.query("SENSe:BANDwidth:RESolution:AUTO?")).rstrip()
        if resBwManAuto == "1":
            resBwManAuto = "AUTO"
        elif resBwManAuto == "0":
            resBwManAuto = "MAN"

        global vidBwManAuto
        vidBwManAuto = str(my_instrument.query("SENSe:BANDwidth:VIDeo:AUTO?")).rstrip()
        if vidBwManAuto == "1":
            vidBwManAuto = "AUTO"
        elif vidBwManAuto == "0":
            vidBwManAuto = "MAN"

        global sweepTimeManAuto
        sweepTimeManAuto = str(my_instrument.query("SENSe:SWEep:TIME:AUTO?")).rstrip()
        if sweepTimeManAuto == "1":
            sweepTimeManAuto = "AUTO"
        elif sweepTimeManAuto == "0":
            sweepTimeManAuto = "MAN"

        global repeatSweepOnOff
        repeatSweepOnOff = str(my_instrument.query("INITiate:CONTinuous?")).rstrip()
        if repeatSweepOnOff == "1":
            repeatSweepOnOff = "ON"
        elif repeatSweepOnOff == "0":
            repeatSweepOnOff = "OFF"

        global trigSyncLowHighPulse
        trigSyncLowHighPulse = str(my_instrument.query("TRIGger:OUTPut?")).rstrip()
        if trigSyncLowHighPulse == "ON":
            trigSyncLowHighPulse = "HIGH"
        elif trigSyncLowHighPulse == "OFF":
            trigSyncLowHighPulse = "LOW"
        elif trigSyncLowHighPulse == "AUTO":
            trigSyncLowHighPulse = "PULSE"

        global syncOutOnOff
        syncOutOnOff = str(my_instrument.query("TRIGger:OUTPut:PULSe:STATe?")).rstrip()
        if syncOutOnOff == "1":
            syncOutOnOff = "ON"
        elif syncOutOnOff == "0":
            syncOutOnOff = "OFF"

        global wavelengthOffset
        wavelengthOffset = str(ast.literal_eval(my_instrument.query("SENSe:WAVelength:OFFSet?")))
        wavelengthOffset = str(conversions.str2float(wavelengthOffset, '%s' %wavelength_units))
        
        global wavelengthStepSize
        wavelengthStepSize = str(my_instrument.query("SENse:WAVelength:CENTer:STEP:INCRement?"))
        wavelengthStepSize = str(conversions.str2float(wavelengthStepSize, "%s" %wavelength_units))

        global wavelengthRefIn
        wavelengthRefIn = str(my_instrument.query("SENSe:CORRection:RVELocity:MEDium?")).rstrip()

        global num_points
        num_points = str(my_instrument.query("SENSe:SWEep:POINts?")).rstrip()

        global Trigger_Mode
        Trigger_Mode = str(my_instrument.query("TRIGger:SOURce?")).rstrip()
        if Trigger_Mode == "INT":
            Trigger_Mode = str(my_instrument.query("TRIGger:SLOPe?")).rstrip()
            if Trigger_Mode == "POS":
                Trigger_Mode = "ADC+"
            elif Trigger_Mode == "NEG":
                Trigger_Mode = "ADC-"
            else:
                Trigger_Mode = "Internal"
        else:
            Trigger_Mode = "External"

        global Power_Calibration
        Power_Calibration = str(my_instrument.query("CALibration:POWer:STATe?")).rstrip()

        global auto_ranging
        auto_ranging = str(ast.literal_eval(my_instrument.query("SENSe:POWer:DC:RANGe:AUTO?")))

        global auto_zero
        auto_zero = str(ast.literal_eval(my_instrument.query("CALibration:ZERO:AUTO?")))

        global amplitude_correction
        amplitude_correction = str(ast.literal_eval(my_instrument.query("SENSe:CORRection:CSET?")))

        global amplitude_correction_mode
        amplitude_correction_mode = str(ast.literal_eval(my_instrument.query("SENSe:CORRection:STATe?")))

        global auto_chop
        auto_chop = str(ast.literal_eval(my_instrument.query("SENSe:CHOP:STATe?")))

    def mkr1Display(self):
        global mkr_1_param
        if mkr_1_param[0] == "1":
            markerX = conversions.str2float(str(my_instrument.query("CALCulate:MARKer1:X?").rstrip()), wavelength_units)
            markerY = float(my_instrument.query("CALCulate:MARKer1:Y?"))
            trc = mkr_1_param[7]
            self.topLabel11.setText("Mkr 1 (%s)" %trc[2])
            self.topLabel12.setText("%.2f %s" %(markerX, wavelength_units))
            self.topLabel13.setText("%.2f %s" %(markerY,amplitude_units))
        else:
            markerX = 0
            markerY = 0
            self.topLabel11.setText("")
            self.topLabel12.setText("")
            self.topLabel13.setText("")
        mkr_1_param[1] = markerX
        mkr_1_param[2] = markerY
        print(mkr_1_param)

    def mkr2Display(self):
        global mkr_2_param
        if mkr_2_param[0] == "1":
            markerX = conversions.str2float(str(my_instrument.query("CALCulate:MARKer2:X?").rstrip()), wavelength_units)
            markerY = float(my_instrument.query("CALCulate:MARKer2:Y?"))
            trc = mkr_2_param[7]
            self.topLabel21.setText("Mkr 2 (%s)" %trc[2])
            self.topLabel22.setText("%.2f %s" %(markerX, wavelength_units))
            self.topLabel23.setText("%.2f %s" %(markerY,amplitude_units))
        else:
            markerX = 0
            markerY = 0
            self.topLabel21.setText("")
            self.topLabel22.setText("")
            self.topLabel23.setText("")
        mkr_2_param[1] = markerX
        mkr_2_param[2] = markerY
        print(mkr_2_param)

    def mkr3Display(self):
        global mkr_3_param
        if mkr_3_param[0] == "1":
            markerX = conversions.str2float(str(my_instrument.query("CALCulate:MARKer3:X?").rstrip()), wavelength_units)
            markerY = float(my_instrument.query("CALCulate:MARKer3:Y?"))
            trc = mkr_3_param[7]
            self.topLabel41.setText("Mkr 3 (%s)" %trc[2])
            self.topLabel42.setText("%.2f %s" %(markerX, wavelength_units))
            self.topLabel43.setText("%.2f %s" %(markerY,amplitude_units))
        else:
            markerX = 0
            markerY = 0
            self.topLabel41.setText("")
            self.topLabel42.setText("")
            self.topLabel43.setText("")
        mkr_3_param[1] = markerX
        mkr_3_param[2] = markerY
        print(mkr_3_param)

    def mkr4Display(self):
        global mkr_4_param
        if mkr_4_param[0] == "1":
            markerX = conversions.str2float(str(my_instrument.query("CALCulate:MARKer4:X?").rstrip()), wavelength_units)
            markerY = float(my_instrument.query("CALCulate:MARKer4:Y?"))
            trc = mkr_2_param[7]
            self.topLabel51.setText("Mkr 4 (%s)" %trc[2])
            self.topLabel52.setText("%.2f %s" %(markerX, wavelength_units))
            self.topLabel53.setText("%.2f %s" %(markerY,amplitude_units))
        else:
            markerX = 0
            markerY = 0
            self.topLabel51.setText("")
            self.topLabel52.setText("")
            self.topLabel53.setText("")
        mkr_4_param[1] = markerX
        mkr_4_param[2] = markerY
        print(mkr_4_param)

    def mkrCompDisplay(self):
        global mkr_1_param
        global mkr_2_param
        global mkr_3_param
        global mkr_4_param

        if mkr_1_param[0] == "1":
            if mkr_2_param[0] == "1":
                self.topLabel31.setText("Mkr 2-1")
                markerDiffWL = mkr_2_param[1]-mkr_1_param[1]
                markerDiffAmp = mkr_2_param[2]-mkr_1_param[2]
                self.topLabel32.setText("%.2f %s" %(markerDiffWL,wavelength_units))
                self.topLabel33.setText("%.2f %s" %(markerDiffAmp,amplitude_units))
            else:
                self.topLabel31.setText("")
                self.topLabel32.setText("")
                self.topLabel33.setText("")
        else:
            self.topLabel31.setText("")
            self.topLabel32.setText("")
            self.topLabel33.setText("")

        if mkr_3_param[0] == "1":
            if mkr_4_param[0] == "1":
                self.topLabel61.setText("Mkr 4-3")
                markerDiffWL = mkr_4_param[1]-mkr_3_param[1]
                markerDiffAmp = mkr_4_param[2]-mkr_3_param[2]
                self.topLabel62.setText("%.2f %s" %(markerDiffWL,wavelength_units))
                self.topLabel63.setText("%.2f %s" %(markerDiffAmp,amplitude_units))
            else:
                self.topLabel61.setText("")
                self.topLabel62.setText("")
                self.topLabel63.setText("")
        else:
            self.topLabel61.setText("")
            self.topLabel62.setText("")
            self.topLabel63.setText("")

    def infoDisplay(self):
        global resBw
        value = my_instrument.query("SENSe:BANDwidth:RESolution?")
        resBw = conversions.str2float(value,"%s" %wavelength_units)
        self.btmLabel21.setText("%.2f %s" %(resBw, wavelength_units))

        global vidBw
        value = my_instrument.query("SENSe:BANDwidth:VIDeo?")
        vidBw = conversions.str2float(value,"%s" %frequency_units)
        self.btmLabel22.setText("%.2f %s" %(vidBw, frequency_units))

        global sensitivity
        value = str(my_instrument.query("SENSe:POWer:DC:RANGe:LOWer?"))
        sensitivity = float(value)
        self.btmLabel41.setText("%.2f dBm" %sensitivity)

        global sweepTime
        value = my_instrument.query("SENSe:SWEep:TIME?")
        sweepTime = float(value)
        self.btmLabel42.setText("%.3f s" %sweepTime)

        self.btmLabel61.setText("%s" %wavelengthRefIn)

        self.btmLabel62.setText("%s" %active_trace_param[3])

   
    ## Function to clear sub-menu ready to add next menu
    def clearLayout(self, layout):
        if layout != None:
            while layout.count():
                child = layout.takeAt(0)
                if child.widget() is not None:
                    child.widget().deleteLater()
                elif child.layout() is not None:
                    clearLayout(child.layout())

    ## Wavelength sub-menu
    ## The wavelength menu buttons are defined here. On click the
    ## buttons will load the associated function from below
    def wavelengthMenu(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonCenterWL = QtWidgets.QPushButton("Center WL", self)
        self.subButtonLayout.addWidget(self.buttonCenterWL)
        self.buttonSpan = QtWidgets.QPushButton("Span", self)
        self.subButtonLayout.addWidget(self.buttonSpan)
        self.buttonStartWL = QtWidgets.QPushButton("Start WL", self)
        self.subButtonLayout.addWidget(self.buttonStartWL)
        self.buttonStopWL = QtWidgets.QPushButton("Stop WL", self)
        self.subButtonLayout.addWidget(self.buttonStopWL)
        self.buttonPeakToCenter = QtWidgets.QPushButton("Peak To Center", self)
        self.subButtonLayout.addWidget(self.buttonPeakToCenter)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonWavelengthSetup = QtWidgets.QPushButton("Wavelength Setup", self)
        self.subButtonLayout.addWidget(self.buttonWavelengthSetup)

        self.buttonCenterWL.clicked.connect(self.centerWL)
        self.buttonSpan.clicked.connect(self.span)
        self.buttonStartWL.clicked.connect(self.startWL)
        self.buttonStopWL.clicked.connect(self.stopWL)
        self.buttonPeakToCenter.clicked.connect(self.peakToCenter)
        self.buttonWavelengthSetup.clicked.connect(self.wavelengthSetupWindow)

    def centerWL(self): ## works
        value = my_instrument.query("SENSe:WAVelength:CENTer?")
        wav = str(wavelength_units)
        current_value = str(conversions.str2float(value,"%s"%wav))
        widget = InputDialog("Center WL", "%s" %wavelength_units, current_value) 
        widget.exec_()
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:CENTer " + "%s%s" %(widget.userInput,wavelength_units)
            my_instrument.write(wavelength)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        
    def span(self): ## works
        value = my_instrument.query("SENSe:WAVelength:SPAN?")
        current_value = str(conversions.str2float(value,"%s"%wavelength_units))
        widget = InputDialog("Span", "%s" %wavelength_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:SPAN " + "%s%s" %(widget.userInput,wavelength_units)
            my_instrument.write(wavelength)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def startWL(self): ## works
        value = my_instrument.query("SENSe:WAVelength:STARt?")
        current_value = str(conversions.str2float(value,"%s" %wavelength_units))
        widget = InputDialog("Start WL", "%s" %wavelength_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:STARt " + "%s%s" %(widget.userInput,wavelength_units)
            my_instrument.write(wavelength)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def stopWL(self): ## works
        value = my_instrument.query("SENSe:WAVelength:STOP?")
        current_value = str(conversions.str2float(value,"%s" %wavelength_units))
        widget = InputDialog("Stop WL", "%s" %wavelength_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            wavelength = "SENSe:WAVelength:STOP " + "%s%s" %(widget.userInput,wavelength_units)
            my_instrument.write(wavelength)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def peakToCenter(self): ## works
        my_instrument.write("CALCulate:MARK:SCENter")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def wavelengthSetupWindow(self): ## works
        widget = WavelengthSetup(parent=self)
        widget.exec_()

    # Amplitude sub-menu
    def amplitudeMenu(self): ## TODO: fix amplitude units when log/lin
        self.clearLayout(self.subButtonLayout)
        global logLin    
        global autoMan
        global traceIntOnOff
        self.buttonRefLvl = QtWidgets.QPushButton("Reference Level", self)
        self.subButtonLayout.addWidget(self.buttonRefLvl)
        self.buttonScaleDiv = QtWidgets.QPushButton("Scale/Div", self)
        self.subButtonLayout.addWidget(self.buttonScaleDiv)
        self.buttonDispMode = QtWidgets.QPushButton("Display Mode [%s]" %logLin, self)
        self.menuDispMode = QtWidgets.QMenu()
        self.menuDispMode.addAction("LOG", self.DispModeAction1)
        self.menuDispMode.addAction("LIN", self.DispModeAction2)
        self.buttonDispMode.setMenu(self.menuDispMode)
        self.subButtonLayout.addWidget(self.buttonDispMode)
        self.buttonSensitivity = QtWidgets.QPushButton("Sensitivity [%s]" %autoMan, self)
        self.menuSensitivity = QtWidgets.QMenu()
        self.menuSensitivity.addAction("AUTO", self.SensitivityAction1)
        self.menuSensitivity.addAction("MAN", self.SensitivityAction2)
        self.buttonSensitivity.setMenu(self.menuSensitivity)
        self.subButtonLayout.addWidget(self.buttonSensitivity)
        self.buttonPeakToRefLvl = QtWidgets.QPushButton("Peak To Ref Level", self)
        self.subButtonLayout.addWidget(self.buttonPeakToRefLvl)
        self.buttonTraceInteg = QtWidgets.QPushButton("Trace Integ [%s]" %traceIntOnOff, self)
        self.menuTraceInteg = QtWidgets.QMenu()
        self.menuTraceInteg.addAction("On", self.TraceIntegAction1)
        self.menuTraceInteg.addAction("Off", self.TraceIntegAction2)
        self.buttonTraceInteg.setMenu(self.menuTraceInteg)
        self.subButtonLayout.addWidget(self.buttonTraceInteg)
        self.buttonAmplitudeSetup = QtWidgets.QPushButton("Amplitude Setup", self)
        self.subButtonLayout.addWidget(self.buttonAmplitudeSetup)

        self.buttonRefLvl.clicked.connect(self.refLVL)
        self.buttonScaleDiv.clicked.connect(self.scaleDiv)
        self.buttonPeakToRefLvl.clicked.connect(self.peakToRefLvl)
        self.buttonAmplitudeSetup.clicked.connect(self.amplitudeSetupWindow)

    def refLVL(self): ## works, TODO: this may need to be input as dBm, not dB
        value = my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:RLEVel?")
        current_value = str(conversions.str2float(value,"%s" %amplitude_units))
        widget = InputDialog("Reference Level", "%s" %amplitude_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            level = "DISPlay:WINDow:TRACe:Y:SCALe:RLEVel " + "%s%s" %(widget.userInput,amplitude_units)
            my_instrument.write(level)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def scaleDiv(self): ## works
        global amplitude_units
        value = my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:PDIVision?")
        current_value = str(conversions.str2float(value,"%s" %amplitude_units))
        widget = InputDialog("Scale/Div", "%s" %amplitude_units, current_value)
        widget.exec_()
        if widget.userInput != 0:
            scale = "DISPlay:WINDow:TRACe:Y:SCALe:PDIVision " + "%s%s" %(widget.userInput,amplitude_units)
            my_instrument.write(scale)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

        ## TODO: not sure why this loop is in this function
        if amplitude_units == 'AUTO':
            if logLin == 'LOG':
                amplitude_units = 'dB'
            elif logLin == 'LIN':
                amplitude_units = 'W'

    def DispModeAction1(self): ## works
        self.buttonDispMode.setText("Display Mode [LOG]")
        my_instrument.write("DISPlay:WINDow:TRACe:Y:SCALe:SPACing LOG")
        amplitude_units = str(my_instrument.query("UNIT:POW?")).rstrip()
        if amplitude_units == 'AUTO':
            amplitude_units = 'W'
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
            trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        logLin = "LOG"

    def DispModeAction2(self): ## works
        self.buttonDispMode.setText("Display Mode [LIN]")
        my_instrument.write("DISPlay:WINDow:TRACe:Y:SCALe:SPACing LIN")
        amplitude_units = str(my_instrument.query("UNIT:POW?")).rstrip()
        if amplitude_units == 'AUTO':
            amplitude_units = 'dB'
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
            trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        logLin = "LIN"    
            
    def SensitivityAction1(self): ## works
        self.buttonSensitivity.setText("Sensitivity [AUTO]")
        my_instrument.write("SENSe:POWer:DC:RANGe:LOWer:AUTO ON")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
            trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        autoMan = 'AUTO'
                
    def SensitivityAction2(self): ## TODO: check manual input
        global sensitivity
        sensitivity = str(my_instrument.query("SENSe:POWer:DC:RANGe:LOWer?"))
        widget = InputDialog("Sensitivity", "%s" %amplitude_units, sensitivity)
        widget.exec_()
        if widget.userInput != 0:
            my_instrument.write("SENSe:POWer:DC:RANGe:LOWer:AUTO OFF")
            sensitivityStr = "SENSe:POWer:DC:RANGe:LOWer " + "%s%s" %(widget.userInput,amplitude_units) #may be wavelength units)
            my_instrument.write(sensitivityStr)
            self.buttonSensitivity.setText("Sensitivity [MAN]")
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
            autoMan = 'MAN'     

    def peakToRefLvl(self): ## works
        my_instrument.write("CALCulate:MARKer:SRLevel")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def TraceIntegAction1(self):
        self.buttonTraceInteg.setText("Trace Integ [ON]")
        my_instrument.write("CALCulate%s:TPOWer:STATe ON" %active_trace_num)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
            trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        traceIntOnOff = 'ON'

    def TraceIntegAction2(self): ## works
        self.buttonTraceInteg.setText("Trace Integ [OFF]")
        my_instrument.write("CALCulate%s:TPOWer:STATe OFF" %active_trace_num)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
            trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        traceIntOnOff = 'OFF'

    def amplitudeSetupWindow(self): ## works
        widget = AmplitudeSetup()
        widget.exec_()

    # Markers sub-menu
    def markersMenu(self):
        global menuFlag
        menuFlag = 1

        self.clearLayout(self.subButtonLayout)    

        self.buttonActMrks = QtWidgets.QPushButton("Displayed Markers", self)
        self.subButtonLayout.addWidget(self.buttonActMrks)
        self.buttonPeakSrch = QtWidgets.QPushButton("Peak Search", self)
        self.subButtonLayout.addWidget(self.buttonPeakSrch)
        self.buttonMkrToCen = QtWidgets.QPushButton("Marker %s to Center" %active_marker, self)
        self.subButtonLayout.addWidget(self.buttonMkrToCen)
        self.buttonMkrToRefLvl = QtWidgets.QPushButton("Marker %s To Ref Level" %active_marker, self)
        self.subButtonLayout.addWidget(self.buttonMkrToRefLvl)
        self.buttonMkrSetup = QtWidgets.QPushButton("Marker %s Setup" %active_marker, self)
        self.subButtonLayout.addWidget(self.buttonMkrSetup)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonMoreMkrFunc = QtWidgets.QPushButton("More Marker Functons", self)
        self.subButtonLayout.addWidget(self.buttonMoreMkrFunc)

        self.buttonActMrks.clicked.connect(self.actMrks)
        self.buttonPeakSrch.clicked.connect(self.peakSrch)
        self.buttonMkrToCen.clicked.connect(self.mrkToCen)
        self.buttonMkrToRefLvl.clicked.connect(self.mkrToRefLvl)
        self.buttonMkrSetup.clicked.connect(self.mkrSetup)
        self.buttonMoreMkrFunc.clicked.connect(self.moreMkrFunc)

    def actMrks(self):
        widget = ActiveMarkersWindow()
        widget.exec_()
        if widget.markerReturn == 1:
            self.mkr1Display()
            self.mkr2Display()
            self.mkr3Display()
            self.mkr4Display()
            self.mkrCompDisplay()
            self.buttonActMkrGbl.setText("Mkr %s" %active_marker)

    def peakSrch(self):  ## works
        my_instrument.write("CALCulate:MARKer%s:MAXimum" %active_marker)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def mrkToCen(self): ## works
        my_instrument.write("CALCulate:MARKer%s:SCENter" %active_marker)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def mkrToRefLvl(self): ## works
        my_instrument.write("CALCulate:MARKer%s:SRLevel" %active_marker)
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def mkrSetup(self):
        widget = MarkerSetup("%s" %active_marker)
        widget.exec_()

    def moreMkrFunc(self):
        global menuFlag
        menuFlag = 2

        self.clearLayout(self.subButtonLayout)    

        self.buttonMkrSrchMenu = QtWidgets.QPushButton("Marker Search Menu", self)
        self.subButtonLayout.addWidget(self.buttonMkrSrchMenu)
        self.buttonMkrBW = QtWidgets.QPushButton("Marker %s Bandwidth [%s]" %(active_marker, active_mkr_param[3]), self)
        self.buttonMkrBW.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonMkrBW)
        self.buttonNoiseMkr = QtWidgets.QPushButton("Noise Marker %s [%s]" %(active_marker, active_mkr_param[4]), self)
        self.buttonNoiseMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonNoiseMkr)
        self.buttonDeltaMkr = QtWidgets.QPushButton("Delta Marker %s [%s]" %(active_marker, active_mkr_param[5]), self)
        self.buttonDeltaMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonDeltaMkr)
        self.buttonOSNRMkr = QtWidgets.QPushButton("OSNR Marker %s [%s]" %(active_marker, active_mkr_param[6]), self)
        self.buttonOSNRMkr.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonOSNRMkr)
        self.buttonLineMkrMenu = QtWidgets.QPushButton("Line Marker Menu", self)
        self.subButtonLayout.addWidget(self.buttonLineMkrMenu)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonMkrSrchMenu.clicked.connect(self.mkrSrchMenu)
        self.buttonMkrBW.clicked.connect(self.mkrBWOnOff)
        self.buttonNoiseMkr.clicked.connect(self.noiseMkr)
        self.buttonDeltaMkr.clicked.connect(self.deltaMkr)
        self.buttonOSNRMkr.clicked.connect(self.OSNRMkr)
        self.buttonLineMkrMenu.clicked.connect(self.lineMkrMenu)
        self.buttonPrevMenu.clicked.connect(self.markersMenu)

    def mkrSrchMenu(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonSrchMode = QtWidgets.QPushButton("Search Mode [%s]" %peakPit, self)
        self.buttonSrchMode.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonSrchMode)
        self.buttonPeakSrch = QtWidgets.QPushButton("%s Search" %peakPit, self)
        self.subButtonLayout.addWidget(self.buttonPeakSrch)
        self.buttonNextPeakDown = QtWidgets.QPushButton("Next %s %s" %(peakPit,upDown), self)
        self.subButtonLayout.addWidget(self.buttonNextPeakDown)
        self.buttonNextPeakLeft = QtWidgets.QPushButton("Next %s Left" %peakPit, self)
        self.subButtonLayout.addWidget(self.buttonNextPeakLeft)
        self.buttonNextPeakRight = QtWidgets.QPushButton("Next %s Right" %peakPit, self)
        self.subButtonLayout.addWidget(self.buttonNextPeakRight)
        self.buttonActMrks = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonActMrks)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonSrchMode.clicked.connect(self.srchMode)
        self.buttonPeakSrch.clicked.connect(self.peakSrch)
        self.buttonNextPeakDown.clicked.connect(self.nextDown)
        self.buttonNextPeakLeft.clicked.connect(self.nextLeft)
        self.buttonNextPeakRight.clicked.connect(self.nextRight)
        self.buttonPrevMenu.clicked.connect(self.moreMkrFunc)

    def srchMode(self): ## works
        global peakPit
        global upDown
        if peakPit == "PEAK":
            upDown = "Up"
            self.buttonSrchMode.setText("Search Mode [PIT]")
            self.buttonPeakSrch.setText("Pit Search")
            self.buttonNextPeakDown.setText("Next Pit Up")
            self.buttonNextPeakLeft.setText("Next Pit Left")
            self.buttonNextPeakRight.setText("Next Pit Right")
            peakPit = "PIT"
        elif peakPit == "PIT":
            upDown = "Down"
            self.buttonSrchMode.setText("Search Mode [PEAK]")
            self.buttonPeakSrch.setText("Peak Search")
            self.buttonNextPeakDown.setText("Next Peak Down")
            self.buttonNextPeakLeft.setText("Next Peak Left")
            self.buttonNextPeakRight.setText("Next Peak Right")
            peakPit = "PEAK"

    def peakSrch(self): ## works
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def nextDown(self): ## works
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX:NEXT" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN:NEXT" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
            
    def nextLeft(self): ## works
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX:LEFT" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN:LEFT" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def nextRight(self): ## works
        if peakPit == "PEAK":
            my_instrument.write("CALCulate:MARKer%s:MAX:RIGH" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        elif peakPit == "PIT":
            my_instrument.write("CALCulate:MARKer%s:MIN:RIGH" %active_marker)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        
    def mkrBWOnOff(self): ## works
        markerBWOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe?" %active_marker)).rstrip()
        if markerBWOnOff == "1":
            self.buttonMkrBW.setText("Marker %s Bandwidth [OFF]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe OFF" %active_marker)
            active_mkr_param[3] = 'OFF'
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        elif markerBWOnOff == "0":
            self.buttonMkrBW.setText("Marker %s Bandwidth [ON]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:BANDwidth:STATe ON" %active_marker)
            current_value = ''
            widget = InputDialog("Marker BW", "dB", current_value)
            widget.exec_()
            if widget.userInput != 0:
                bw = "CALC:MARK%s:FUNC:BAND:NDB " %active_marker + "%sdB" %widget.userInput
                active_mkr_param[3] = 'ON'
                my_instrument.write(bw)
                display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateMkrParam()
                
    def noiseMkr(self): ## works
        noiseMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:NOISe:STATe?" %active_marker)).rstrip()
        if noiseMarkOnOff == "1":
            self.buttonNoiseMkr.setText("Noise Marker %s [OFF]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:NOISe:STATe OFF" %active_marker)
            active_mkr_param[4] = 'OFF'
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        elif noiseMarkOnOff == "0":
            self.buttonNoiseMkr.setText("Noise Marker %s [ON]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:NOISe:STATe ON" %active_marker)
            active_mkr_param[4] = 'ON'
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateMkrParam()

    def deltaMkr(self): ## works
        deltaMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:DELTa:STATe?" %active_marker)).rstrip()
        if deltaMarkOnOff == "1":
            self.buttonDeltaMkr.setText("Delta Marker %s [OFF]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:DELTa:STATe OFF" %active_marker)
            active_mkr_param[5] = 'OFF'
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        elif deltaMarkOnOff == "0":
            self.buttonDeltaMkr.setText("Delta Marker %s [ON]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:DELTa:STATe ON" %active_marker)
            active_mkr_param[5] = 'ON'
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateMkrParam()

    def OSNRMkr(self): ## works
        osnrMarkOnOff = str(my_instrument.query("CALCulate:MARKer%s:FUNCtion:OSNR:STATe?" %active_marker)).rstrip()
        if osnrMarkOnOff == "1":
            self.buttonOSNRMkr.setText("OSNR Marker %s [OFF]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:OSNR:STATe OFF" %active_marker)
            active_mkr_param[6] = 'OFF'
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        elif osnrMarkOnOff == "0":
            self.buttonOSNRMkr.setText("OSNR Marker %s [ON]" %active_marker)
            my_instrument.write("CALCulate:MARKer%s:FUNCtion:OSNR:STATe ON" %active_marker)
            active_mkr_param[6] = 'ON'
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateMkrParam()

    ## TODO: CHECK LINE MARKER MENU
    def lineMkrMenu(self):
        self.clearLayout(self.subButtonLayout)

        self.buttonWLLineMkr1 = QtWidgets.QPushButton("Wavelength Line Mkr 1", self)
        self.subButtonLayout.addWidget(self.buttonWLLineMkr1)
        self.buttonWLLineMkr2 = QtWidgets.QPushButton("Wavelength Line Mkr 2", self)
        self.subButtonLayout.addWidget(self.buttonWLLineMkr2)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonLineMkrsOff = QtWidgets.QPushButton("Line Markers Off", self)
        self.subButtonLayout.addWidget(self.buttonLineMkrsOff)
        self.buttonAdvLineMkrFunc = QtWidgets.QPushButton("Advanved Line Marker Functions", self)
        self.subButtonLayout.addWidget(self.buttonAdvLineMkrFunc)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonWLLineMkr1.clicked.connect(self.WLLineMkr1)
        self.buttonWLLineMkr2.clicked.connect(self.WLLineMkr2)
        self.buttonLineMkrsOff.clicked.connect(self.lineMkrsOff)
        self.buttonAdvLineMkrFunc.clicked.connect(self.advLineMkrFunc)
        self.buttonPrevMenu.clicked.connect(self.moreMkrFunc)

    ## TODO: will probably need to change the units here to be dynamic
    def WLLineMkr1(self):
        Integration_Limit_1 = str(my_instrument.query("CALCulate:TPOWer:IRANge:LOWer?")).rstrip()
        widget = InputDialog("Wavelenth Line Mkr 1", "%s" %wavelenth_units, Integration_Limit_1)
        widget.exec_()
        if widget.userInput != 0:
            Integration_Limit_1 = str(widget.userInput).rstrip()
            my_instrument.write("CALCulate:TPOWer:IRANge:LOWer %s" %Integration_Limit_1)

    def WLLineMkr2(self):
        Integration_Limit_2 = str(my_instrument.query("CALCulate:TPOWer:IRANge:UPPer?")).rstrip()
        widget = InputDialog("Wavelenth Line Mkr 2", "%s" %wavelength_units, Integration_Limit_2)
        widget.exec_()
        if widget.userInput != 0:
            Integration_Limit_2 = str(widget.userInput).rstrip()
            my_instrument.write("CALCulate:TPOWer:IRANge:UPPer %s" %Integration_Limit_2)

    def lineMkrsOff(self):
        my_instrument.write("CALCulate:MARKer:SRANge OFF")

    def advLineMkrFunc(self): ## works
        widget = AdvancedLineMarkerWindow()
        widget.exec_()

    # Trace sub-menu
    def tracesMenu(self):
        global menuFlag
        menuFlag = 3

        self.clearLayout(self.subButtonLayout)
        
        self.buttonUpdtTrce = QtWidgets.QPushButton("Update Trace %s [%s]" %(active_trace[2], active_trace_param[0]), self)
        self.menuUpdtTrce = QtWidgets.QMenu()
        self.menuUpdtTrce.addAction("On", self.UpdtTrceAction1)
        self.menuUpdtTrce.addAction("Off", self.UpdtTrceAction2)
        self.buttonUpdtTrce.setMenu(self.menuUpdtTrce)
        self.subButtonLayout.addWidget(self.buttonUpdtTrce)
        self.buttonViewTrce = QtWidgets.QPushButton("View Trace %s [%s]" %(active_trace[2],active_trace_param[1]), self)
        self.menuViewTrce = QtWidgets.QMenu()
        self.menuViewTrce.addAction("On", self.ViewTrceAction1)
        self.menuViewTrce.addAction("Off", self.ViewTrceAction2)
        self.buttonViewTrce.setMenu(self.menuViewTrce)
        self.subButtonLayout.addWidget(self.buttonViewTrce)
        self.buttonHoldTrce = QtWidgets.QPushButton("Hold Trace %s [%s]" %(active_trace[2],active_trace_param[2]), self)
        self.menuHoldTrce = QtWidgets.QMenu()
        self.menuHoldTrce.addAction("None", self.HoldTrceAction1)
        self.menuHoldTrce.addAction("Min", self.HoldTrceAction2)
        self.menuHoldTrce.addAction("Max", self.HoldTrceAction3)
        self.buttonHoldTrce.setMenu(self.menuHoldTrce)
        self.subButtonLayout.addWidget(self.buttonHoldTrce)
        self.buttonTrceMath = QtWidgets.QPushButton("Trace Math", self)
        self.subButtonLayout.addWidget(self.buttonTrceMath)
        self.buttonAveraging = QtWidgets.QPushButton("Averaging %s [%s]" %(active_trace[2],active_trace_param[3]), self)
        self.menuAveraging = QtWidgets.QMenu()
        self.menuAveraging.addAction("On", self.AveragingAction1)
        self.menuAveraging.addAction("Off", self.AveragingAction2)
        self.buttonAveraging.setMenu(self.menuAveraging)
        self.subButtonLayout.addWidget(self.buttonAveraging)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonTrceSetup = QtWidgets.QPushButton("Trace Setup", self)
        self.subButtonLayout.addWidget(self.buttonTrceSetup)

        self.buttonTrceMath.clicked.connect(self.trceMath)
        self.buttonTrceSetup.clicked.connect(self.trceSetup)

    def UpdtTrceAction1(self): ## works
        self.buttonUpdtTrce.setText("Update Trace %s [ON]" %active_trace[2])
        my_instrument.write("TRACe:FEED:CONTrol %s,ALW" %active_trace)
        active_trace_param[0] == 'ON'
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
            trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateTrcParam()

    def UpdtTrceAction2(self): ## works
        self.buttonUpdtTrce.setText("Update Trace %s [OFF]" %active_trace[2])
        my_instrument.write("TRACe:FEED:CONTrol %s,NEV" %active_trace)
        active_trace_param[0] = 'OFF'
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
            trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateTrcParam()

    def ViewTrceAction1(self): ## works
        self.buttonViewTrce.setText("View Trace %s [ON]" %active_trace[2])
        my_instrument.write("DISPlay:WINDow:TRACe:STATe %s,ON" %active_trace)
        active_trace_param[1] = "ON"
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
            trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateTrcParam()

    def ViewTrceAction2(self): ## works
        self.buttonViewTrce.setText("View Trace %s [OFF]" %active_trace[2])
        my_instrument.write("DISPlay:WINDow:TRACe:STATe %s,OFF" %active_trace)
        active_trace_param[1] = "OFF"
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
            trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateTrcParam()
            
    def HoldTrceAction1(self): ## works
        self.buttonHoldTrce.setText("Hold Trace %s [NONE]" %active_trace[2])
        my_instrument.write("CALCulate%s:MAXimum:STATe OFF" %active_trace_num)
        my_instrument.write("CALCulate%s:MINimum:STATe OFF" %active_trace_num)
        active_trace_param[2] = 'NONE'
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateTrcParam()

    def HoldTrceAction2(self): ## works
        self.buttonHoldTrce.setText("Hold Trace %s [MIN]" %active_trace[2])
        my_instrument.write("CALCulate%s:MINimum:STATe ON" %active_trace_num)
        active_trace_param[2] = 'MIN'
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateTrcParam()

    def HoldTrceAction3(self): ## works
        self.buttonHoldTrce.setText("Hold Trace %s [MAX]" %active_trace[2])
        my_instrument.write("CALCulate%s:MAXimum:STATe ON" %active_trace_num)
        active_trace_param[2] = 'MAX'
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateTrcParam()


    ## TODO: CHECK TRACE MATH
    def trceMath(self):
        self.clearLayout(self.subButtonLayout)

        self.buttonDefMathTrcC = QtWidgets.QPushButton("Default Math Trace C", self)
        self.menuTrcMathC = QtWidgets.QMenu()
        self.menuTrcMathC.addAction("Log: C = A-B", self.TrcMathCAction1)
        self.menuTrcMathC.addAction("Log: C = A+B", self.TrcMathCAction2)
        self.menuTrcMathC.addAction("Lin: C = A-B", self.TrcMathCAction3)
        self.menuTrcMathC.addAction("Lin: C = A+B", self.TrcMathCAction4)
        self.menuTrcMathC.addAction("Trace C Math Off", self.TrcMathCAction5)
        self.buttonDefMathTrcC.setMenu(self.menuTrcMathC)
        self.subButtonLayout.addWidget(self.buttonDefMathTrcC)
        self.buttonDefMathTrcF = QtWidgets.QPushButton("Default Math Trace F", self)
        self.menuTrcMathF = QtWidgets.QMenu()
        self.menuTrcMathF.addAction("Log: F = C-D", self.TrcMathFAction1)
        self.menuTrcMathF.addAction("Trace F Math Off", self.TrcMathFAction2)
        self.buttonDefMathTrcF.setMenu(self.menuTrcMathF)
        self.subButtonLayout.addWidget(self.buttonDefMathTrcF)
        self.buttonExchMenu = QtWidgets.QPushButton("Exchange Menu", self)
        self.menuExchange = QtWidgets.QMenu()
        self.menuExchange.addAction("A Exchange B", self.ExchangeAction1)
        self.menuExchange.addAction("B Exchange C", self.ExchangeAction2)
        self.menuExchange.addAction("C Exchange A", self.ExchangeAction3)
        self.menuExchange.addAction("D Exchange A", self.ExchangeAction4)
        self.menuExchange.addAction("E Exchange A", self.ExchangeAction5)
        self.menuExchange.addAction("F Exchange A", self.ExchangeAction6)
        self.buttonExchMenu.setMenu(self.menuExchange)
        self.subButtonLayout.addWidget(self.buttonExchMenu)
        self.buttonTrceOffset = QtWidgets.QPushButton("Trace Offset", self)
        self.subButtonLayout.addWidget(self.buttonTrceOffset)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonAllMathOff = QtWidgets.QPushButton("All Math Off", self)
        self.subButtonLayout.addWidget(self.buttonAllMathOff)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonTrceOffset.clicked.connect(self.trceOffset)
        self.buttonAllMathOff.clicked.connect(self.allMathOff)
        self.buttonPrevMenu.clicked.connect(self.tracesMenu)
        self.buttonPrevMenu.clicked.connect(self.tracesMenu)

    def TrcMathCAction1(self):
        my_instrument.write("CALCulate3:MATH:STATe ON")
        my_instrument.write("CALCulate3:MATH:EXPRession (TRA / TRB)")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def TrcMathCAction2(self):
        my_instrument.write("CALCulate3:MATH:STATe ON")
        my_instrument.write("CALCulate3:MATH:EXPRession (TRA * TRB)")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def TrcMathCAction3(self):
        my_instrument.write("CALCulate3:MATH:STATe ON")
        my_instrument.write("CALCulate3:MATH:EXPRession (TRA - TRB)")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def TrcMathCAction4(self):
        my_instrument.write("CALCulate3:MATH:STATe ON")
        my_instrument.write("CALCulate3:MATH:EXPRession (TRA + TRB)")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def TrcMathCAction5(self):
        my_instrument.write("CALCulate3:MATH:STATe OFF")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def TrcMathFAction1(self):
        my_instrument.write("CALCulate6:MATH:STATe ON")
        my_instrument.write("CALCulate6:MATH:EXPRession (TRC / TRD)")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def TrcMathFAction2(self):
        my_instrument.write("CALCulate6:MATH:STATe OFF")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ExchangeAction1(self):
        my_instrument.write("TRACe:EXCHange TRA,TRB")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ExchangeAction2(self):
        my_instrument.write("TRACe:EXCHange TRB,TRC")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ExchangeAction3(self):
        my_instrument.write("TRACe:EXCHange TRC,TRA")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ExchangeAction4(self):
        my_instrument.write("TRACe:EXCHange TRD,TRA")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ExchangeAction5(self):
        my_instrument.write("TRACe:EXCHange TRE,TRA")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ExchangeAction6(self):
        my_instrument.write("TRACe:EXCHange TRF,TRA")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def trceOffset(self):
        Trace_Offset = str(my_instrument.query("CALCulate%s:OFFSet?" %active_trace_num)).rstrip()
        Trace_Offset = str(conversions.str2float(Trace_Offset, amplitude_units))
        widget = InputDialog("Trace %s Offset" %active_trace_num, "%s" %amplitude_units, Trace_Offset)
        widget.exec_()
        if widget.userInput != 0:
            Trace_Offset = str(widget.userInput).rstrip()
            my_instrument.write("CALCulate%s:OFFSet %s" %(Integration_Limit_2,Trace_Offset))

    def allMathOff(self):
        my_instrument.write("CALCulate:MATH:STATe OFF")

    def AveragingAction1(self): ## works
        self.buttonAveraging.setText("Averaging [ON]")
        my_instrument.write("CALCulate:AVERage:STATe ON")
        active_trace_param[3] = "ON"
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
            trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateTrcParam()

    def AveragingAction2(self): ## works
        self.buttonAveraging.setText("Averaging [OFF]")
        my_instrument.write("CALCulate:AVERage:STATe OFF")
        active_trace_param[3] = "OFF"
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
            trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        self.updateTrcParam()

    def trceSetup(self): ## works
        num_points = str(my_instrument.query("SENSe:SWEep:POINts?")).rstrip()
        widget = InputDialog("Trace Setup", "Sweep Points", num_points[1:5])
        widget.exec_()
        if widget.userInput != 0:
            num_points = "SENSe:SWEep:POINts " + "%s" %widget.userInput
            my_instrument.write(num_points)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    # Bandwidth/Sweep sub-menu
    def bwMenu(self):
        global resBwManAuto
        global repeatSweepOnOff
        self.clearLayout(self.subButtonLayout)    

        self.buttonResBW = QtWidgets.QPushButton("Res BW [%s]" %resBwManAuto, self)
        self.menuResBw = QtWidgets.QMenu()
        self.menuResBw.addAction("Auto", self.ResBWAction1)
        self.menuResBw.addAction("Manual", self.ResBWAction2)
        self.buttonResBW.setMenu(self.menuResBw)
        self.subButtonLayout.addWidget(self.buttonResBW)
        self.buttonVidBW = QtWidgets.QPushButton("Video BW [%s]" %vidBwManAuto, self)
        self.menuVidBW = QtWidgets.QMenu()
        self.menuVidBW.addAction("Auto", self.VidBWAction1)
        self.menuVidBW.addAction("Manual", self.VidBWAction2)
        self.buttonVidBW.setMenu(self.menuVidBW)
        self.subButtonLayout.addWidget(self.buttonVidBW)
        self.buttonSweepTime = QtWidgets.QPushButton("Sweep Time [%s]" %sweepTimeManAuto, self)
        self.menuSweepTime = QtWidgets.QMenu()
        self.menuSweepTime.addAction("Auto", self.SweepTimeAction1)
        self.menuSweepTime.addAction("Manual", self.SweepTimeAction2)
        self.buttonSweepTime.setMenu(self.menuSweepTime)
        self.subButtonLayout.addWidget(self.buttonSweepTime)
        self.buttonRptSweep = QtWidgets.QPushButton("Repeat Sweep [%s]" %repeatSweepOnOff, self)
        self.menuRptSweep = QtWidgets.QMenu()
        self.menuRptSweep.addAction("On", self.RptSweepAction1)
        self.menuRptSweep.addAction("Off", self.RptSweepAction2)
        self.buttonRptSweep.setMenu(self.menuRptSweep)
        self.subButtonLayout.addWidget(self.buttonRptSweep)
        self.buttonSnglSweep = QtWidgets.QPushButton("Single Sweep", self)
        self.subButtonLayout.addWidget(self.buttonSnglSweep)
        self.buttonBlank = QtWidgets.QPushButton("", self)
        self.subButtonLayout.addWidget(self.buttonBlank)
        self.buttonMoreBWFunc = QtWidgets.QPushButton("More BW/Sweep Functions", self)
        self.subButtonLayout.addWidget(self.buttonMoreBWFunc)

        self.buttonSnglSweep.clicked.connect(self.snglSweep)
        self.buttonMoreBWFunc.clicked.connect(self.moreBWFunc)

    def ResBWAction1(self):
        self.buttonResBW.setText("Res BW [AUTO]")
        my_instrument.write("SENSe:BANDwidth:RESolution:AUTO 1")
        resBwManAuto = "1"
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                    trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ResBWAction2(self):
        global resBwManAuto
        resBwManAuto = str(my_instrument.query("SENSe:BANDwidth:RESolution:AUTO?")).rstrip()
        widget = InputDialog("Res BW", "%s" %wavelength_units, str(resBw))
        widget.exec_()
        if widget.userInput != 0:
            self.buttonResBW.setText("Res BW [MAN]")
            bandwidth = "SENSe:BANDwidth:RESolution " + "%s%s" %(widget.userInput,wavelength_units) #may be wrong unit
            my_instrument.write(bandwidth)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                    trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def VidBWAction1(self):
        self.buttonVidBW.setText("Video BW [AUTO]")
        my_instrument.write("SENSe:BANDwidth:VIDeo:AUTO 1")
        global vidBwManAuto
        vidBwManAuto = "1"
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                    trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def VidBWAction2(self):
        global vidBwManAuto
        vidBwManAuto = str(my_instrument.query("SENSe:BANDwidth:VIDeo:AUTO?")).rstrip()
        widget = InputDialog("Video BW", "%s" %frequency_units, str(vidBw))
        widget.exec_()
        if widget.userInput != 0:
            self.buttonVidBW.setText("Video BW [MAN]")
            bandwidth = "SENSe:BANDwidth:VIDeo " + "%s%s" %(widget.userInput,frequency_units) #may be wrong unit
            my_instrument.write(bandwidth)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                    trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def SweepTimeAction1(self):
        self.buttonSweepTime.setText("Sweep Time [AUTO]")
        my_instrument.write("SENSe:SWEep:TIME:AUTO 1")
        global sweepTimeManAuto
        sweepTimeManAuto = "1"

    def SweepTimeAction2(self):
        global sweepTimeManAuto
        sweepTimeManAuto = str(my_instrument.query("SENSe:SWEep:TIME:AUTO?")).rstrip()
        widget = InputDialog("Sweep Time", "s", str(sweepTime))
        widget.exec_()
        if widget.userInput != 0:
            self.buttonSweepTime.setText("Sweep Time [MAN]")
            stime = "SENSe:SWEep:TIME " + "%ss" %widget.userInput
            my_instrument.write(stime)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                    trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def RptSweepAction1(self): ## works
        self.buttonRptSweep.setText("Repeat Sweep [ON]")
        my_instrument.write("INITiate:CONTinuous 1")
        repeatSweepOnOff = "ON"

    def RptSweepAction2(self): ## works
        self.buttonRptSweep.setText("Repeat Sweep [OFF]")
        my_instrument.write("INITiate:CONTinuous 0")
        repeatSweepOnOff = "OFF"

    def snglSweep(self):
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points)

    ## TODO: CHECK TRIG MODES
    def moreBWFunc(self):
        self.clearLayout(self.subButtonLayout)    

        self.buttonTrigMode = QtWidgets.QPushButton("Trigger Mode [%s]" %Trigger_Mode, self)
        self.menuTrigMode = QtWidgets.QMenu()
        self.menuTrigMode.addAction("Internal", self.TrigModeAction1)
        self.menuTrigMode.addAction("Gated", self.TrigModeAction2)
        self.menuTrigMode.addAction("External", self.TrigModeAction3)
        self.menuTrigMode.addAction("ADC+", self.TrigModeAction4)
        self.menuTrigMode.addAction("ADC-", self.TrigModeAction5)
        self.buttonTrigMode.setMenu(self.menuTrigMode)
        self.subButtonLayout.addWidget(self.buttonTrigMode)
        self.buttonTrigDelay = QtWidgets.QPushButton("Trigger Delay", self)
        self.subButtonLayout.addWidget(self.buttonTrigDelay)
        self.buttonADCTrigSync = QtWidgets.QPushButton("ADC Trig Sync [%s]" %trigSyncLowHighPulse, self)
        self.menuADCTrig = QtWidgets.QMenu()
        self.menuADCTrig.addAction("Low", self.ADCTrigAction1)
        self.menuADCTrig.addAction("High", self.ADCTrigAction2)
        self.menuADCTrig.addAction("Pulse", self.ADCTrigAction3)
        self.buttonADCTrigSync.setMenu(self.menuADCTrig)
        self.subButtonLayout.addWidget(self.buttonADCTrigSync)
        self.buttonADCSyncOut = QtWidgets.QPushButton("ADC Sync Out [%s]" %syncOutOnOff, self)
        self.buttonADCSyncOut.setCheckable(1)
        self.subButtonLayout.addWidget(self.buttonADCSyncOut)
        self.buttonADCSyncOutDuty = QtWidgets.QPushButton("ADC Sync Out Duty Cycle", self)
        self.subButtonLayout.addWidget(self.buttonADCSyncOutDuty)
        self.buttonADCSyncOutPulse = QtWidgets.QPushButton("ADC Sync Out Pulse Width", self)
        self.subButtonLayout.addWidget(self.buttonADCSyncOutPulse)
        self.buttonPrevMenu = QtWidgets.QPushButton("Previous Menu", self)
        self.subButtonLayout.addWidget(self.buttonPrevMenu)

        self.buttonTrigDelay.clicked.connect(self.trigDelay)
        self.buttonADCSyncOut.clicked.connect(self.ADCSyncOut)
        self.buttonADCSyncOutDuty.clicked.connect(self.ADCSyncOutDuty)
        self.buttonADCSyncOutPulse.clicked.connect(self.ADCSyncOutPulse)
        self.buttonPrevMenu.clicked.connect(self.bwMenu)

    def TrigModeAction1(self):
        self.buttonTrigMode.setText("Trigger Mode [Internal]")
        Trigger_Mode = "Internal"
        my_instrument.write("TRIGger:SOURce INT")

    def TrigModeAction2(self):
        self.buttonTrigMode.setText("Trigger Mode [Gated]")

    def TrigModeAction3(self):
        self.buttonTrigMode.setText("Trigger Mode [External]")
        Trigger_Mode = "External"
        my_instrument.write("TRIGger:SOURce EXT")

    def TrigModeAction4(self):
        self.buttonTrigMode.setText("Trigger Mode [ADC+]")
        Trigger_Mode = "ADC+"
        my_instrument.write("TRIGger:SLOPe POS")

    def TrigModeAction5(self):
        self.buttonTrigMode.setText("Trigger Mode [ADC-]")
        Trigger_Mode = "ADC-"
        my_instrument.write("TRIGger:SLOPe NEG")

    ## TODO: does time change at all? may need to make us dynamic
    def trigDelay(self): ## works
        value = my_instrument.query("TRIGger:DELay?")
        current_value = str(conversions.str2float(value,"us")) 
        widget = InputDialog("Trigger Delay", "us", current_value)
        widget.exec_()
        if widget.userInput != 0:
            delay = "TRIGger:DELay " + "%sus" %widget.userInput
            my_instrument.write(delay)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ADCTrigAction1(self): ## works, TODO: may need to remove display
        self.buttonADCTrigSync.setText("ADC Trig Sync [LOW]")
        my_instrument.write("TRIGger:OUTPut OFF")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
    def ADCTrigAction2(self): ## works, TODO: may need to remove display
        self.buttonADCTrigSync.setText("ADC Trig Sync [HIGH]")
        my_instrument.write("TRIGger:OUTPut ON")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ADCTrigAction3(self): ## works, TODO: may need to remove display
        self.buttonADCTrigSync.setText("ADC Trig Sync [PULSE]")
        my_instrument.write("TRIGger:OUTPut AUTO")
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ADCSyncOut(self): ## works, TODO: may need to remove display
        syncOutOnOff = str(my_instrument.query("TRIGger:OUTPut:PULSe:STATe?")).rstrip()
        if syncOutOnOff == "0":
            self.buttonADCSyncOut.setText("ADC Sync Out [ON]")
            my_instrument.write("TRIGger:OUTPut:PULSe:STATe 1")
            syncOutOnOff = "1"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)
        elif syncOutOnOff == "1":
            self.buttonADCSyncOut.setText("ADC Sync Out [OFF]")
            my_instrument.write("TRIGger:OUTPut:PULSe:STATe 0")
            syncOutOnOff = "0"
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ADCSyncOutDuty(self): ## works, TODO: may need to remove display
        value = my_instrument.query("TRIGger:OUTPut:PULSe:DCYCle?")
        current_value = str(conversions.str2float(value,"%")) ##TODO: no value here?
        widget = InputDialog("ADC Sync Out Duty Cycle", "%", current_value)
        widget.exec_()
        if widget.userInput != 0:
            duty_cycle = "TRIGger:OUTPut:PULSe:DCYCle " + "%s" %widget.userInput
            my_instrument.write(duty_cycle)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)

    def ADCSyncOutPulse(self): ## works, TODO: may need to remove display
        value = my_instrument.query("TRIGger:OUTPut:PULSe:WIDTh?")
        current_value = str(conversions.str2float(value,"us")) 
        widget = InputDialog("ADC Sync Out Pulse Width", "us", current_value)
        widget.exec_()
        if widget.userInput != 0:
            pulse_width = "TRIGger:OUTPut:PULSe:WIDTh " + "%sus" %widget.userInput
            my_instrument.write(pulse_width)
            display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units_display,amplitude_units,num_points,trace_a_data,trace_b_data,
                trace_c_data,trace_d_data,trace_e_data,trace_f_data)


## The input dialog class is used throught the agilent class to allow the
## user to input values into menu options
class InputDialog(QtWidgets.QDialog, Ui_inputDialog):
    def __init__(self, title, unit, value, parent=None):
        super(InputDialog, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle(title)
        self.label.setText(unit)
        self.lineEdit.setText(value)
        validator = QtGui.QDoubleValidator()
        self.lineEdit.setValidator(validator)
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)
        global flag
        flag = 0

    def onAccept(self):
        self.userInput = self.lineEdit.text()
        global flag
        flag = 1
        return self.userInput
        
    def onReject(self):
        self.userInput = 0
        global flag
        flag = 1
        return self.userInput
    

class ActiveMarkersWindow(QtWidgets.QDialog, Ui_activeMarkersWindow):
    def __init__(self, parent=None):
        super(ActiveMarkersWindow, self).__init__(parent)
        self.setupUi(self)
        if float(my_instrument.query("CALCulate:MARKer1:STATe?")) == 1:
            self.checkMkr1.setChecked(True)
        if float(my_instrument.query("CALCulate:MARKer2:STATe?")) == 1:
            self.checkMkr2.setChecked(True)
        if float(my_instrument.query("CALCulate:MARKer3:STATe?")) == 1:
            self.checkMkr3.setChecked(True)
        if float(my_instrument.query("CALCulate:MARKer4:STATe?")) == 1:
            self.checkMkr4.setChecked(True)

        self.buttonAllOff.clicked.connect(self.allMkrsOff)
        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def allMkrsOff(self):
        self.checkMkr1.setChecked(False)
        self.checkMkr2.setChecked(False)
        self.checkMkr3.setChecked(False)
        self.checkMkr4.setChecked(False)

    def onAccept(self):
        global mkr_1_param
        global mkr_2_param
        global mkr_3_param
        global mkr_4_param
        if self.checkMkr1.isChecked() == True:
            my_instrument.write("CALCulate:MARKer1:STATe ON")
            mkr_1_param[0] = "1"
        if self.checkMkr1.isChecked() == False:
            my_instrument.write("CALCulate:MARKer1:STATe OFF")
            mkr_1_param[0] = "0"
        if self.checkMkr2.isChecked() == True:
            my_instrument.write("CALCulate:MARKer2:STATe ON")
            mkr_2_param[0] = "1"
        if self.checkMkr2.isChecked() == False:
            my_instrument.write("CALCulate:MARKer2:STATe OFF")
            mkr_2_param[0] = "0"
        if self.checkMkr3.isChecked() == True:
            my_instrument.write("CALCulate:MARKer3:STATe ON")
            mkr_3_param[0] = "1"
        if self.checkMkr3.isChecked() == False:
            my_instrument.write("CALCulate:MARKer3:STATe OFF")
            mkr_3_param[0] = "0"
        if self.checkMkr4.isChecked() == True:
            my_instrument.write("CALCulate:MARKer4:STATe ON")
            mkr_4_param[0] = "1"
        if self.checkMkr4.isChecked() == False:
            my_instrument.write("CALCulate:MARKer4:STATe OFF")
            mkr_4_param[0] = "0"

        global active_marker
        if mkr_1_param[0] == '1':
            active_marker = '1'
        if mkr_2_param[0] == '1':
            active_marker = '2'
        if mkr_3_param[0] == '1':
            active_marker = '3'
        if mkr_4_param[0] == '1':
            active_marker = '4'

        self.markerReturn = 1
        return self.markerReturn

    def onReject(self):
        self.markerReturn = 0
        return self.markerReturn


##class ActiveTraceWindow(QtWidgets.QDialog, Ui_activeTraceWindow):
##    def __init__(self, title, parent=None):
##        super(ActiveTraceWindow, self).__init__(parent)
##        self.setupUi(self)
##        self.setWindowTitle(title)
##
##        self.buttonAllOff.clicked.connect(self.allTrcOff)
##        self.accepted.connect(self.onAccept)
##        self.rejected.connect(self.onReject)
##
##        traceQuery = "CALCulate:MARKer%s:TRACe?" %active_marker
##        global active_trace
##        active_trace = str(my_instrument.query(traceQuery))
##        if my_instrument.query(traceQuery) == 'TRA':
##            self.checkTRCA.setChecked(True)
##        if my_instrument.query(traceQuery) == 'TRB':
##            self.checkTRCB.setChecked(True)
##        if my_instrument.query(traceQuery) == 'TRC':
##            self.checkTRCC.setChecked(True)
##        if my_instrument.query(traceQuery) == 'TRD':
##            self.checkTRCD.setChecked(True)
##        if my_instrument.query(traceQuery) == 'TRE':
##            self.checkTRCE.setChecked(True)
##        if my_instrument.query(traceQuery) == 'TRF':
##            self.checkTRCF.setChecked(True)
##
##    def allTrcOff(self):
##        self.checkTRCA.setChecked(False)
##        self.checkTRCB.setChecked(False)
##        self.checkTRCC.setChecked(False)
##        self.checkTRCD.setChecked(False)
##        self.checkTRCE.setChecked(False)
##        self.checkTRCF.setChecked(False)
##
##    def onAccept(self):
##        global active_trace
##        if self.checkTRCA.isChecked() == True:
##            my_instrument.write("CALCulate:MARKer%s:TRACe TRA" %active_marker)
##            active_trace = "TRA"
##        if self.checkTRCB.isChecked() == True:
##            my_instrument.write("CALCulate:MARKer%s:TRACe TRB" %active_marker)
##            active_trace = "TRB"
##        if self.checkTRCC.isChecked() == True:
##            my_instrument.write("CALCulate:MARKer%s:TRACe TRC" %active_marker)
##            active_trace = "TRC"
##        if self.checkTRCD.isChecked() == True:
##            my_instrument.write("CALCulate:MARKer%s:TRACe TRD" %active_marker)
##            active_trace = "TRD"
##        if self.checkTRCE.isChecked() == True:
##            my_instrument.write("CALCulate:MARKer%s:TRACe TRE" %active_marker)
##            active_trace = "TRE"
##        if self.checkTRCF.isChecked() == True:
##            my_instrument.write("CALCulate:MARKer%s:TRACe TRF" %active_marker)
##            active_trace = "TRF"
##
##        return
##
##    def onReject(self):
##        return
##
##

## TODO: Factory/User power cal selection #TODO: check variable placement in load up
class AmplitudeSetup(QtWidgets.QDialog, Ui_amplitudeSetupWindow):
    def __init__(self, parent=None):
        super(AmplitudeSetup, self).__init__(parent)
        self.setupUi(self)
        global auto_ranging
        global auto_zero
        global auto_chop
        global amplitude_correction_mode
        if amplitude_units == 'dB':
            amp_units_display = 'Auto'
        else:
            amp_units_display = 'W'
        self.buttonAmpUnits.setText("%s" %amp_units_display)
        self.menuAmpUnits = QtWidgets.QMenu()
        self.menuAmpUnits.addAction("Auto", self.AmpUnitsAction1)
        self.menuAmpUnits.addAction("W", self.AmpUnitsAction2)
        self.buttonAmpUnits.setMenu(self.menuAmpUnits)
        if auto_ranging == '1':
            auto_range_display = 'On'
        elif auto_ranging == '0':
            auto_range_display = 'Off'
        self.buttonAutoRang.setText("%s" %auto_range_display)
        self.menuAutoRang = QtWidgets.QMenu()
        self.menuAutoRang.addAction("On", self.AutoRangAction1)
        self.menuAutoRang.addAction("Off", self.AutoRangAction2)
        self.buttonAutoRang.setMenu(self.menuAutoRang)
        if auto_zero == '1':
            auto_zero_display = 'On'
        elif auto_zero == '0':
            auto_zero_display = 'Off'
        self.buttonAutoZero.setText("%s" %auto_zero_display)
        self.menuAutoZero = QtWidgets.QMenu()
        self.menuAutoZero.addAction("On", self.AutoZeroAction1)
        self.menuAutoZero.addAction("Off", self.AutoZeroAction2)
        if auto_chop == '1':
            auto_chop_display = 'On'
        elif auto_chop == '0':
            auto_chop_display = 'Off'
        self.buttonAutoZero.setMenu(self.menuAutoZero)
        self.buttonAutoChop.setText("%s" %auto_chop_display)
        self.menuAutoChop = QtWidgets.QMenu()
        self.menuAutoChop.addAction("On", self.AutoChopAction1)
        self.menuAutoChop.addAction("Off", self.AutoChopAction2)
        self.buttonAutoChop.setMenu(self.menuAutoChop)
        self.buttonPowCal.setText("Factory")
        self.menuPowCal = QtWidgets.QMenu()
        self.menuPowCal.addAction("User", self.PowCalAction1)
        self.menuPowCal.addAction("Factory", self.PowCalAction2)
        self.buttonPowCal.setMenu(self.menuPowCal)
        self.buttonAmpCorr.setText("%s" %amplitude_correction)
        self.menuAmpCorr = QtWidgets.QMenu()
        self.menuAmpCorr.addAction("1", self.AmpCorrAction1)
        self.menuAmpCorr.addAction("2", self.AmpCorrAction2)
        self.menuAmpCorr.addAction("3", self.AmpCorrAction3)
        self.menuAmpCorr.addAction("4", self.AmpCorrAction4)
        if amplitude_correction_mode == '1':
            amplitude_correction_mode = 'On'
        elif amplitude_correction_mode == '0':
            amplitude_correction_mode = 'Off'
        self.buttonAmpCorr.setMenu(self.menuAmpCorr)
        self.buttonAmpCorrMode.setText("%s" %amplitude_correction_mode)
        self.menuAmpCorrMode = QtWidgets.QMenu()
        self.menuAmpCorrMode.addAction("On", self.AmpCorrModeAction1)
        self.menuAmpCorrMode.addAction("Off", self.AmpCorrModeAction2)
        self.buttonAmpCorrMode.setMenu(self.menuAmpCorrMode)

        # Populate text fields
        self.labelUserPowCal.setText(str(my_instrument.query("CALibration:POWer:DATE?")).rstrip())

        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def AmpUnitsAction1(self):
        self.buttonAmpUnits.setText("Auto")

    def AmpUnitsAction2(self):
        self.buttonAmpUnits.setText("W")

    def AutoRangAction1(self):
        self.buttonAutoRang.setText("On")

    def AutoRangAction2(self):
        self.buttonAutoRang.setText("Off")

    def AutoZeroAction1(self):
        self.buttonAutoZero.setText("On")

    def AutoZeroAction2(self):
        self.buttonAutoZero.setText("Off")

    def AutoChopAction1(self):
        self.buttonAutoChop.setText("On")

    def AutoChopAction2(self):
        self.buttonAutoChop.setText("Off")

    def PowCalAction1(self):
        self.buttonPowCal.setText("User")

    def PowCalAction2(self):
        self.buttonPowCal.setText("Factory")

    def AmpCorrAction1(self):
        self.buttonAmpCorr.setText("1")

    def AmpCorrAction2(self):
        self.buttonAmpCorr.setText("2")

    def AmpCorrAction3(self):
        self.buttonAmpCorr.setText("3")

    def AmpCorrAction4(self):
        self.buttonAmpCorr.setText("4")

    def AmpCorrModeAction1(self):
        self.buttonAmpCorrMode.setText("On")

    def AmpCorrModeAction2(self):
        self.buttonAmpCorrMode.setText("Off")

    def onAccept(self):
        global logLin
        global amplitude_units

        if self.buttonAmpUnits.text() == "Auto":
            amplitude_units = 'dB'
        else:
            amplitude_units = 'W'

        if self.buttonAutoRang.text() == "On":
            my_instrument.write("SENSe:POWer:DC:RANGe:AUTO ON")
        else:
            my_instrument.write("SENSe:POWer:DC:RANGe:AUTO OFF")

        if self.buttonAutoZero.text() == 'On':
            my_instrument.write("CALibration:ZERO:AUTO 1")
        else:
            my_instrument.write("CALibration:ZERO:AUTO 0")

        if self.buttonAutoChop.text() == 'On':
            my_instrument.write("SENSe:CHOP:STATe 1")
        else:
            my_instrument.write("SENSe:CHOP:STATe 0")

        amplitude_correction = str(self.buttonAmpCorr.text())
        my_instrument.write("SENSe:CORRection:CSET %s" %amplitude_correction)

        amplitude_correction_mode = str(self.buttonAmpCorrMode.text())
        my_instrument.write("SENSe:CORRection:STATe %s" %amplitude_correction_mode)

        return 
        
    def onReject(self):
        return


class WavelengthSetup(QtWidgets.QDialog, Ui_wavelengthSetupWindow): ## Complete
    def __init__(self, parent=None):
        super(WavelengthSetup, self).__init__(parent)
        self.setupUi(self)
        
        wavelengthOffset = str(ast.literal_eval(my_instrument.query("SENSe:WAVelength:OFFSet?")))
        wavelengthStepSize = str(ast.literal_eval(my_instrument.query("SENse:WAVelength:CENTer:STEP:INCRement?")))
        wavelengthOffset = str(conversions.str2float(wavelengthOffset, '%s' %wavelength_units))
        wavelengthStepSize = str(conversions.str2float(wavelengthStepSize, '%s' %wavelength_units))
        self.buttonWLUnits.setText("%s" %wavelength_units)
        self.menuWLUnits = QtWidgets.QMenu()
        self.menuWLUnits.addAction("nm", self.WLUnitsAction1)
        self.menuWLUnits.addAction("um", self.WLUnitsAction2)
        self.menuWLUnits.addAction("Ang", self.WLUnitsAction3)
        self.buttonWLUnits.setMenu(self.menuWLUnits)
        self.lineWLOffset.setText("%s" %wavelengthOffset)
        self.label_3.setText("%s" %wavelength_units)
        self.label_5.setText("%s" %wavelength_units)
        self.lineWLStep.setText("%s" %wavelengthStepSize)
        self.buttonWLRef.setText("%s" %wavelengthRefIn)
        self.menuWLRef = QtWidgets.QMenu()
        self.menuWLRef.addAction("AIR", self.WLRefAction1)
        self.menuWLRef.addAction("VAC", self.WLRefAction2)
        self.buttonWLRef.setMenu(self.menuWLRef)

        # Prevent user input of non doubles
        validator = QtGui.QDoubleValidator()
        self.lineWLOffset.setValidator(validator)
        self.lineWLStep.setValidator(validator)

        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def WLUnitsAction1(self):
        self.buttonWLUnits.setText("nm")
        global wavelength_units
        wavelength_units = "nm"
        wavelength_units_display = 'm'

    def WLUnitsAction2(self):
        self.buttonWLUnits.setText("um")
        global wavelength_units
        wavelength_units = "um"
        wavelength_units_display = 'm'

    def WLUnitsAction3(self):
        self.buttonWLUnits.setText("Ang")
        global wavelength_units
        wavelength_units = "Ang"
        wavelength_units_display = 'Ang'

    def WLRefAction1(self):
        self.buttonWLRef.setText("AIR")

    def WLRefAction2(self):
        self.buttonWLRef.setText("VAC")

    def onAccept(self):
        if self.buttonWLUnits.text() == "nm":
            wavelength_units = "nm"
            wavelength_units_display = 'm'
        elif self.buttonWLUnits.text() == "um":
            wavelength_units = "um"
            wavelength_units_display = 'm'
        else:
            wavelength_units = "Ang"
            wavelength_units_display = 'Ang'

        wavelengthOffset = str(self.lineWLOffset.text())
        wavelengthStepSize = str(self.lineWLStep.text())
        wavOff = "SENSe:WAVelength:OFFSet " + "%s%s" %(wavelengthOffset,wavelength_units)
        wavStep = "SENse:WAVelength:CENTer:STEP:INCRement " + "%s%s" %(wavelengthStepSize,wavelength_units)
        my_instrument.write(wavOff)
        my_instrument.write(wavStep)
        global wavelengthRefIn
        
        if self.buttonWLRef.text() == "AIR":
            my_instrument.write("SENSe:CORRection:RVELocity:MEDium AIR")

            wavelengthRefIn = "AIR"
        else:
            my_instrument.write("SENSe:CORRection:RVELocity:MEDium VAC")
            wavelengthRefIn = "VAC" 
        return

    def onReject(self):
        return


class MarkerSetup(QtWidgets.QDialog, Ui_markerSetupWindow):
    def __init__(self, MkrNo, parent=None):
        super(MarkerSetup, self).__init__(parent)
        self.setupUi(self)

        self.labelMkrNo.setText("Mkr %s" %MkrNo)
        self.buttonNormMkrUnits.setText("nm")
        self.menuNormMkrUnits = QtWidgets.QMenu()
        self.menuNormMkrUnits.addAction("nm", self.NormMkrUnitsAction1)
        self.menuNormMkrUnits.addAction("um", self.NormMkrUnitsAction2)
        self.menuNormMkrUnits.addAction("Ang", self.NormMkrUnitsAction3)
        self.menuNormMkrUnits.addAction("GHz", self.NormMkrUnitsAction4)
        self.menuNormMkrUnits.addAction("THz", self.NormMkrUnitsAction5)
        self.buttonNormMkrUnits.setMenu(self.menuNormMkrUnits)
        self.buttonBWMkrUnits.setText("nm")
        self.menuBWMkrUnits = QtWidgets.QMenu()
        self.menuBWMkrUnits.addAction("nm", self.BWMkrUnitsAction1)
        self.menuBWMkrUnits.addAction("um", self.BWMkrUnitsAction2)
        self.menuBWMkrUnits.addAction("Ang", self.BWMkrUnitsAction3)
        self.menuBWMkrUnits.addAction("GHz", self.BWMkrUnitsAction4)
        self.menuBWMkrUnits.addAction("THz", self.BWMkrUnitsAction5)
        self.buttonBWMkrUnits.setMenu(self.menuBWMkrUnits)
        self.buttonDeltaMkrUnits.setText("nm")
        self.menuDeltaMkrUnits = QtWidgets.QMenu()
        self.menuDeltaMkrUnits.addAction("nm", self.DeltaMkrUnitsAction1)
        self.menuDeltaMkrUnits.addAction("um", self.DeltaMkrUnitsAction2)
        self.menuDeltaMkrUnits.addAction("Ang", self.DeltaMkrUnitsAction3)
        self.menuDeltaMkrUnits.addAction("GHz", self.DeltaMkrUnitsAction4)
        self.menuDeltaMkrUnits.addAction("THz", self.DeltaMkrUnitsAction5)
        self.buttonDeltaMkrUnits.setMenu(self.menuDeltaMkrUnits)
        self.buttonMkrInterp.setText("On")
        self.menuMkrInterp = QtWidgets.QMenu()
        self.menuMkrInterp.addAction("On", self.MkrInterpAction1)
        self.menuMkrInterp.addAction("Off", self.MkrInterpAction2)
        self.buttonMkrInterp.setMenu(self.menuMkrInterp)
        self.buttonBWMkrInterp.setText("On")
        self.menuBWMkrInterp = QtWidgets.QMenu()
        self.menuBWMkrInterp.addAction("On", self.BWMkrInterpAction1)
        self.menuBWMkrInterp.addAction("Off", self.BWMkrInterpAction2)
        self.buttonBWMkrInterp.setMenu(self.menuBWMkrInterp)
        self.buttonUserMkrThresh.setText("On")
        self.menuUserMkrThresh = QtWidgets.QMenu()
        self.menuUserMkrThresh.addAction("On", self.UserMkrThreshAction1)
        self.menuUserMkrThresh.addAction("Off", self.UserMkrThreshAction2)
        self.buttonUserMkrThresh.setMenu(self.menuUserMkrThresh)
        self.buttonNoiseMkrBW.setText("0.1 nm")
        self.menuNoiseMkrBW = QtWidgets.QMenu()
        self.menuNoiseMkrBW.addAction("0.1 nm", self.NoiseMkrBWAction1)
        self.menuNoiseMkrBW.addAction("1.0 nm", self.NoiseMkrBWAction2)
        self.buttonNoiseMkrBW.setMenu(self.menuNoiseMkrBW)
        self.buttonOSNR.setText("PM")
        self.menuOSNR = QtWidgets.QMenu()
        self.menuOSNR.addAction("PM", self.OSNRAction1)
        self.menuOSNR.addAction("Auto", self.OSNRAction2)
        self.menuOSNR.addAction("Manual", self.OSNRAction3)
        self.buttonOSNR.setMenu(self.menuOSNR)

        # Prevent user input of non doubles
        validator = QtGui.QDoubleValidator()
        self.linePeakExcur.setValidator(validator)
        self.linePitExcur.setValidator(validator)
        self.lineOSNR.setValidator(validator)
        self.lineSrchThresh.setValidator(validator)

        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def NormMkrUnitsAction1(self):
        self.buttonNormMkrUnits.setText("nm")

    def NormMkrUnitsAction2(self):
        self.buttonNormMkrUnits.setText("um")

    def NormMkrUnitsAction3(self):
        self.buttonNormMkrUnits.setText("Ang")

    def NormMkrUnitsAction4(self):
        self.buttonNormMkrUnits.setText("GHz")

    def NormMkrUnitsAction5(self):
        self.buttonNormMkrUnits.setText("THz")

    def BWMkrUnitsAction1(self):
        self.buttonBWMkrUnits.setText("nm")

    def BWMkrUnitsAction2(self):
        self.buttonBWMkrUnits.setText("um")

    def BWMkrUnitsAction3(self):
        self.buttonBWMkrUnits.setText("Ang")

    def BWMkrUnitsAction4(self):
        self.buttonBWMkrUnits.setText("GHz")

    def BWMkrUnitsAction5(self):
        self.buttonBWMkrUnits.setText("THz")

    def DeltaMkrUnitsAction1(self):
        self.buttonDeltaMkrUnits.setText("nm")

    def DeltaMkrUnitsAction2(self):
        self.buttonDeltaMkrUnits.setText("um")

    def DeltaMkrUnitsAction3(self):
        self.buttonDeltaMkrUnits.setText("Ang")

    def DeltaMkrUnitsAction4(self):
        self.buttonDeltaMkrUnits.setText("GHz")

    def DeltaMkrUnitsAction5(self):
        self.buttonDeltaMkrUnits.setText("THz")

    def MkrInterpAction1(self):
        self.buttonMkrInterp.setText("On")

    def MkrInterpAction2(self):
        self.buttonMkrInterp.setText("Off")

    def BWMkrInterpAction1(self):
        self.buttonBWMkrInterp.setText("On")

    def BWMkrInterpAction2(self):
        self.buttonBWMkrInterp.setText("Off")

    def UserMkrThreshAction1(self):
        self.buttonUserMkrThresh.setText("On")

    def UserMkrThreshAction2(self):
        self.buttonUserMkrThresh.setText("Off")

    def NoiseMkrBWAction1(self):
        self.buttonNoiseMkrBW.setText("0.1 nm")

    def NoiseMkrBWAction2(self):
        self.buttonNoiseMkrBW.setText("1.0 nm")

    def OSNRAction1(self):
        self.buttonOSNR.setText("PM")

    def OSNRAction2(self):
        self.buttonOSNR.setText("Auto")

    def OSNRAction3(self):
        self.buttonOSNR.setText("Manual")

    def onAccept(self):
        return

    def onReject(self):
        return


class AdvancedLineMarkerWindow(QtWidgets.QDialog, Ui_advancedLineMarkerWindow):
    def __init__(self, parent=None):
        super(AdvancedLineMarkerWindow, self).__init__(parent)
        self.setupUi(self)

        self.buttonSweepLimit.setText("On")
        self.menuSweepLimit = QtWidgets.QMenu()
        self.menuSweepLimit.addAction("On", self.SweepLimitAction1)
        self.menuSweepLimit.addAction("Off", self.SweepLimitAction2)
        self.buttonSweepLimit.setMenu(self.menuSweepLimit)
        self.buttonSrchLimit.setText("On")
        self.menuSrchLimit = QtWidgets.QMenu()
        self.menuSrchLimit.addAction("On", self.SrchLimitAction1)
        self.menuSrchLimit.addAction("Off", self.SrchLimitAction2)
        self.buttonSrchLimit.setMenu(self.menuSrchLimit)
        self.buttonIntegLimit.setText("On")
        self.menuIntegLimit = QtWidgets.QMenu()
        self.menuIntegLimit.addAction("On", self.IntegLimitAction1)
        self.menuIntegLimit.addAction("Off", self.IntegLimitAction2)
        self.buttonIntegLimit.setMenu(self.menuIntegLimit)
        self.buttonTraceInteg.setText("On")
        self.menuTraceInteg = QtWidgets.QMenu()
        self.menuTraceInteg.addAction("On", self.TraceIntegAction1)
        self.menuTraceInteg.addAction("Off", self.TraceIntegAction2)
        self.buttonTraceInteg.setMenu(self.menuTraceInteg)

        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)

    def SweepLimitAction1(self):
        self.buttonSweepLimit.setText("On")

    def SweepLimitAction2(self):
        self.buttonSweepLimit.setText("Off")

    def SrchLimitAction1(self):
        self.buttonSrchLimit.setText("On")

    def SrchLimitAction2(self):
        self.buttonSrchLimit.setText("Off")

    def IntegLimitAction1(self):
        self.buttonIntegLimit.setText("On")

    def IntegLimitAction2(self):
        self.buttonIntegLimit.setText("Off")

    def TraceIntegAction1(self):
        self.buttonTraceInteg.setText("On")

    def TraceIntegAction2(self):
        self.buttonTraceInteg.setText("Off")

    def onAccept(self):
        return

    def onReject(self):
        return


class SystemWindow(QtWidgets.QDialog, Ui_systemWindow):
    def __init__(self, parent=None):
        super(SystemWindow, self).__init__(parent)
        self.setupUi(self)
        
        self.buttonSigSource.setText("External")
        self.menuSigSource = QtWidgets.QMenu()
        self.menuSigSource.addAction("External", self.SigSourceAction1)
        self.menuSigSource.addAction("Calibrator", self.SigSourceAction2)
        self.buttonSigSource.setMenu(self.menuSigSource)
        self.buttonWLRef.setText("%s" %wavelengthRefIn)
        self.menuWLRef = QtWidgets.QMenu()
        self.menuWLRef.addAction("Air", self.WLRefAction1)
        self.menuWLRef.addAction("Vacuum", self.WLRefAction2)
        self.buttonWLRef.setMenu(self.menuWLRef)

        # Populate text fields
        self.labelFacPowCal.setText(str(my_instrument.query("CALibration:DATE?")).rstrip())
        self.labelUserPowCal.setText(str(my_instrument.query("CALibration:POWer:DATE?")).rstrip())
        self.lineCalPower.setText("%s" %Power_Calibration)
        self.lineCalWL.setText("%s" %Power_Calibration)

        self.labelFacWLCal.setText(str(my_instrument.query("CALibration:DATE?")).rstrip()) 
        self.labelUserWLCal.setText(str(my_instrument.query("CALibration:WAVelength:DATE?")).rstrip())

        self.firmwareLabel.setText(str(my_instrument.query("*IDN?")).rstrip())

        # Prevent user input of non doubles
        validator = QtGui.QDoubleValidator()
        self.lineCalWL.setValidator(validator)
        self.lineCalPower.setValidator(validator)  
        self.lineSetCalWL.setValidator(validator) 

        self.accepted.connect(self.onAccept)
        self.rejected.connect(self.onReject)   

    def SigSourceAction1(self):
        self.buttonSigSource.setText("External")

    def SigSourceAction2(self):
        self.buttonSigSource.setText("Calibrator")

    def WLRefAction1(self):
        self.buttonWLRef.setText("Air")

    def WLRefAction2(self):
        self.buttonWLRef.setText("Vacuum")

    def onAccept(self):
        if self.buttonWLRef.text() == "AIR":
            my_instrument.write("SENSe:CORRection:RVELocity:MEDium AIR")
            wavelengthRefIn = "AIR"
            self.buttonWLRef.setText("AIR")
        else:
            my_instrument.write("SENSe:CORRection:RVELocity:MEDium VAC")
            wavelengthRefIn = "VAC"
            self.buttonWLRef.setText("VAC")
        return

    def onReject(self):
        return


# Main window
class MainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)
        self.actionNew_Instrument.triggered.connect(self.instrumentSelectWindow)
        self.actionClose_Instrument.triggered.connect(self.closeTab)
        self.tabWidget.tabCloseRequested.connect(self.closeTab)

    def instrumentSelectWindow(self):
        widget = InstrumentSelect(parent=self)
        widget.exec_()
        if widget.selection != 0:
        	self.openInstrument(widget.selection)

    def openInstrument(self, device):
        if device == "AGILENT 86142B":
            indice = [i for i, s in enumerate(devices_info) if 'AGILENT 86142B' in s]
            indice = indice[0]
            instrument_address = address[indice]
            global my_instrument
            my_instrument = rm.open_resource('%s' %instrument_address)
            self.tab = Agilent86142B()
            global flag
            flag = 1
        elif device == "HEWLETT PACKARD 8157A":
            indice = [i for i, s in enumerate(devices_info) if 'HEWLETT PACKARD 8157A' in s]
            indice = indice[0]
            instrument_address = address[indice]
            global my_insturment2
            my_instrument2 = rm.open_resource('%s' %instrument_address)
            self.tab = hp8157A()
        elif device == "ANDO AQ-4303":
            indice = [i for i, s in enumerate(devices_info) if 'ANDO AQ-4303' in s]
            print(indice)
            indice = indice[0]
            print(indice)
            instrument_address = address[indice]
            global my_instrument3
            my_instrument3 = rm.open_resource('%s' %instrument_address)
            self.tab = AQ4303B()
        elif device == "":
            return
        self.tabWidget.addTab(self.tab, "%s" %device)

    def closeTab(self, currentIndex):
        currentQWidget = self.tabWidget.widget(currentIndex)
        currentQWidget.deleteLater()
        self.tabWidget.removeTab(currentIndex)


def main():
    app = QtWidgets.QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())
    

if __name__ == '__main__':
    main()
