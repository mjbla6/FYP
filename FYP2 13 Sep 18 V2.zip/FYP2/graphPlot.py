import visa
import math
import ast
import pyqtgraph as pg
import numpy
import gui_agilent86142b
import conversions

##TODO what if there are more than one active traces?
## - will need to make a check to see how many active traces there are and
## - loop through some code for each one

##TODO need to add in active markers and obtain those
## - will need to do something similar as for traces when there
## - is more than one active marker

##TODO add in reference level trigger to turn on and off

def display(self,my_instrument, active_trace, xLabel, yLabel, xUnits, yUnits, num_points, trace_a_data, trace_b_data, trace_c_data,
            trace_d_data, trace_e_data, trace_f_data):
    self.p1.clear()
    self.p1.setLabel('left', '%s' %yLabel, units='%s' %yUnits)
    self.p1.setLabel('bottom', '%s' %xLabel, units='%s' %xUnits)
    print('1')
    my_instrument.write("INIT:CONT OFF")
    my_instrument.write("INIT:IMM;*OPC?") ## take sweep and wait for finish
    print('2')
    print('Active Trace = %s' %active_trace)
    trace_start = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STARt? %s" %active_trace)) ## finds start of trace in right format
    trace_stop = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STOP? %s" %active_trace)) ## finds end of trace in right format
    print('3')
    trace_y_values = ast.literal_eval(my_instrument.query("TRAC? %s" %active_trace)) ## obtains trace data for y values (power)
    trace_x_values = numpy.linspace(trace_start,trace_stop,num_points) ## runs linspace function to create the equating x data points (wavelength)
    trace_data = numpy.array([trace_x_values,trace_y_values]).T ## combines the x and y trace data and formats it correctly
    print('4')
    frame_start = ast.literal_eval(my_instrument.query("SENSe:WAVelength:STARt?")) ## finds left hand side of display
    frame_stop = ast.literal_eval(my_instrument.query("SENSe:WAVelength:STOP?")) ## finds right hand side of display

    print('5')
    if active_trace == "TRA":
        trace_a_data = trace_data
    if active_trace == "TRB":
        trace_b_data = trace_data
    if active_trace == "TRC":
        trace_c_data = trace_data
    if active_trace == "TRD":
        trace_d_data = trace_data
    if active_trace == "TRE":
        trace_e_data = trace_data
    if active_trace == "TRF":
        trace_f_data = trace_data

    print('6')
    
    self.p1.plot(trace_a_data, pen='y')
    self.p1.plot(trace_b_data, pen='g')
    self.p1.plot(trace_c_data, pen='c')
    self.p1.plot(trace_d_data, pen='r')
    self.p1.plot(trace_e_data, pen='b')
    self.p1.plot(trace_f_data, pen='m')

    print('7')
    self.graphLayout.addWidget(self.p1)
    self.p1.setXRange(frame_start,frame_stop)
    ref_level = my_instrument.query("DISPlay:WINDow:TRACe:Y:SCALe:RLEVel?")
    ref_level = str(conversions.str2float(ref_level,"dBm"))
    line = pg.InfiniteLine(pos=ref_level, angle=180, pen='g')
    self.p1.addItem(line)
    return trace_a_data,trace_b_data,trace_c_data,trace_d_data,trace_e_data,trace_f_data





