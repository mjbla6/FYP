i = 0
e = 9

if i==0 and e ==9:
    print('yes')
