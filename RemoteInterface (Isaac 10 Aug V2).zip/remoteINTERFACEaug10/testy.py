from threading import Thread, Event

class MyThread(Thread):
    def __init__(self, event):
        Thread.__init__(self)
        self.stopped = event

    def run(self):
        while not self.stopped.wait(1):
            print("Thread is running..")

class MyThread2(Thread):
    def __init__(self, event):
        Thread.__init__(self)
        self.stopped = event

    def run(self):
        while not self.stopped.wait(0.7):
            print("Thread2 is running..")

my_event = Event()
thread = MyThread(my_event)
thread.start()
thread = MyThread2(my_event)
thread.start()
print('doing other stuff')
