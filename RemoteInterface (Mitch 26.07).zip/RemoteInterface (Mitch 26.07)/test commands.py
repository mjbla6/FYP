import sys
import visa
import math
import ast
import pyqtgraph as pg
import numpy as np

rm = visa.ResourceManager()
my_instrument = rm.open_resource('GPIB1::23::INSTR')

##test1 = my_instrument.query("INIT:IMM;*OPC?")
active_trace = 'TRA'
start_wl = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STARt? TRA"))
stop_wl = ast.literal_eval(my_instrument.query("TRACe:DATA:X:STOP? TRA"))
sense_start = ast.literal_eval(my_instrument.query("SENSe:WAVelength:STARt?"))
sense_stop = ast.literal_eval(my_instrument.query("SENSe:WAVelength:STOP?"))
axis_range = [sense_start,sense_stop]
x_values = ast.literal_eval(my_instrument.query("TRAC? %s" %active_trace)) ##TODO what if there are more than one active traces?
ranges = np.linspace(start_wl,stop_wl,1001)


trace = np.array([ranges,x_values]).T


##print('x_values = ')
##print(x_values)
##print('y_values = ')
##print(y_values)
##y_values = ast.literal_eval(my_instrument.query("TRACe:DATA:Y? %s" %active_trace)) ##TODO what if there are more than one active traces?
pg.plot(trace)
##my_instrument.write("CALCulate:MARK:SCENter")
##test = my_instrument.query("TRAC:DATA:X:STOP? TRA")
##
##my_instrument.write("FORM:DATA REAL")
##test = my_instrument.query("FORM?")
##
##print(test)


