from PyQt5 import QtCore, QtGui, QtWidgets
import sys
from gui_mainwindow import Ui_MainWindow
from gui_instrumentselect import Ui_instrumentSelect
from gui_inputdialog import Ui_inputDialog
from gui_checkdialog import Ui_checkDialog
from gui_checkdialog2 import Ui_checkDialog2
from gui_agilent86142b import Ui_Agilent86142B
from gui_amplitudesetupwindow import Ui_amplitudeSetupWindow
from gui_wavelengthsetupwindow import Ui_wavelengthSetupWindow
from gui_activemarkerswindow import Ui_activeMarkersWindow
from gui_activetracewindow import Ui_activeTraceWindow
from gui_markersetupwindow import Ui_markerSetupWindow
from gui_advancedlinemarkerwindow import Ui_advancedLineMarkerWindow
from gui_triggermode import Ui_triggerMode
from gui_systemwindow import Ui_systemWindow
from gui_hp8157a import Ui_HP8157A
import visa
import math
import numpy
import visa_manager
import conversions
import pyqtgraph as pg
import ast
from graphPlot import display

rm = visa.ResourceManager()
resources =  rm.list_resources()
devices_info = visa_manager.devices()
address = visa_manager.GPIB_address()
num_devices = visa_manager.num_devices()
my_instrument = rm.open_resource("GPIB1::23::INSTR")
amplitude_units = str(my_instrument.query("UNIT:POW?")).rstrip()
print(amplitude_units)
