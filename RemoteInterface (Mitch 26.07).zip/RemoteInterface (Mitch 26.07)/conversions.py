def str2float(string,unit):
    value = float(string)
    ## add more units in here when needed
    if unit == "nm":
        value = value * 1000000000
    elif unit == "um":
        value = value * 1000000
    elif unit == "dBm":
        value = value * 1 ##TODO redefine 1 to whatever it needs to be
    elif unit == "dB":
        value = value * 1 ##TODO redefine 1 to whatever it needs to be
    elif unit == "us":
        value = value * 1000000
    elif unit == "%":
        value = value * 1
    else:
        raise ValueError("Incorrect unit entered")
    return value




