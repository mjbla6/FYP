# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'checkdialog.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_checkDialog(object):
    def setupUi(self, checkDialog):
        checkDialog.setObjectName("checkDialog")
        checkDialog.resize(400, 100)
        self.verticalLayout = QtWidgets.QVBoxLayout(checkDialog)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.checkBoxL = QtWidgets.QCheckBox(checkDialog)
        self.checkBoxL.setObjectName("checkBoxL")
        self.horizontalLayout.addWidget(self.checkBoxL)
        self.checkBoxR = QtWidgets.QCheckBox(checkDialog)
        self.checkBoxR.setObjectName("checkBoxR")
        self.horizontalLayout.addWidget(self.checkBoxR)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.buttonBox = QtWidgets.QDialogButtonBox(checkDialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(checkDialog)
        self.buttonBox.accepted.connect(checkDialog.accept)
        self.buttonBox.rejected.connect(checkDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(checkDialog)

    def retranslateUi(self, checkDialog):
        _translate = QtCore.QCoreApplication.translate
        checkDialog.setWindowTitle(_translate("checkDialog", "Dialog"))
        self.checkBoxL.setText(_translate("checkDialog", "CheckBox"))
        self.checkBoxR.setText(_translate("checkDialog", "CheckBox"))

