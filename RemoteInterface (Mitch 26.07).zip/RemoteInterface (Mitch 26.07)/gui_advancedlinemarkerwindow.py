# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'advancedlinemarkerwindow.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_advancedLineMarkerWindow(object):
    def setupUi(self, advancedLineMarkerWindow):
        advancedLineMarkerWindow.setObjectName("advancedLineMarkerWindow")
        advancedLineMarkerWindow.resize(400, 300)
        self.verticalLayout = QtWidgets.QVBoxLayout(advancedLineMarkerWindow)
        self.verticalLayout.setObjectName("verticalLayout")
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.labelIntegLimit = QtWidgets.QLabel(advancedLineMarkerWindow)
        self.labelIntegLimit.setObjectName("labelIntegLimit")
        self.gridLayout.addWidget(self.labelIntegLimit, 2, 0, 1, 1)
        self.labelSweepLimit = QtWidgets.QLabel(advancedLineMarkerWindow)
        self.labelSweepLimit.setObjectName("labelSweepLimit")
        self.gridLayout.addWidget(self.labelSweepLimit, 0, 0, 1, 1)
        self.checkBoxSrchLimitOff = QtWidgets.QCheckBox(advancedLineMarkerWindow)
        self.checkBoxSrchLimitOff.setObjectName("checkBoxSrchLimitOff")
        self.gridLayout.addWidget(self.checkBoxSrchLimitOff, 1, 2, 1, 1)
        self.checkBoxSweepLimitOff = QtWidgets.QCheckBox(advancedLineMarkerWindow)
        self.checkBoxSweepLimitOff.setObjectName("checkBoxSweepLimitOff")
        self.gridLayout.addWidget(self.checkBoxSweepLimitOff, 0, 2, 1, 1)
        self.labelSearchLimit = QtWidgets.QLabel(advancedLineMarkerWindow)
        self.labelSearchLimit.setObjectName("labelSearchLimit")
        self.gridLayout.addWidget(self.labelSearchLimit, 1, 0, 1, 1)
        self.checkBoxSweepLimitOn = QtWidgets.QCheckBox(advancedLineMarkerWindow)
        self.checkBoxSweepLimitOn.setObjectName("checkBoxSweepLimitOn")
        self.gridLayout.addWidget(self.checkBoxSweepLimitOn, 0, 1, 1, 1)
        self.checkBoxSrchLimitOn = QtWidgets.QCheckBox(advancedLineMarkerWindow)
        self.checkBoxSrchLimitOn.setObjectName("checkBoxSrchLimitOn")
        self.gridLayout.addWidget(self.checkBoxSrchLimitOn, 1, 1, 1, 1)
        self.labelTraceInteg = QtWidgets.QLabel(advancedLineMarkerWindow)
        self.labelTraceInteg.setObjectName("labelTraceInteg")
        self.gridLayout.addWidget(self.labelTraceInteg, 3, 0, 1, 1)
        self.checkBoxIntegLimitOn = QtWidgets.QCheckBox(advancedLineMarkerWindow)
        self.checkBoxIntegLimitOn.setObjectName("checkBoxIntegLimitOn")
        self.gridLayout.addWidget(self.checkBoxIntegLimitOn, 2, 1, 1, 1)
        self.checkBoxTrceIntegOn = QtWidgets.QCheckBox(advancedLineMarkerWindow)
        self.checkBoxTrceIntegOn.setObjectName("checkBoxTrceIntegOn")
        self.gridLayout.addWidget(self.checkBoxTrceIntegOn, 3, 1, 1, 1)
        self.checkBoxIntegLimitOff = QtWidgets.QCheckBox(advancedLineMarkerWindow)
        self.checkBoxIntegLimitOff.setObjectName("checkBoxIntegLimitOff")
        self.gridLayout.addWidget(self.checkBoxIntegLimitOff, 2, 2, 1, 1)
        self.checkBoxTrceIntegOff = QtWidgets.QCheckBox(advancedLineMarkerWindow)
        self.checkBoxTrceIntegOff.setObjectName("checkBoxTrceIntegOff")
        self.gridLayout.addWidget(self.checkBoxTrceIntegOff, 3, 2, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.buttonBox = QtWidgets.QDialogButtonBox(advancedLineMarkerWindow)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(advancedLineMarkerWindow)
        self.buttonBox.accepted.connect(advancedLineMarkerWindow.accept)
        self.buttonBox.rejected.connect(advancedLineMarkerWindow.reject)
        QtCore.QMetaObject.connectSlotsByName(advancedLineMarkerWindow)

    def retranslateUi(self, advancedLineMarkerWindow):
        _translate = QtCore.QCoreApplication.translate
        advancedLineMarkerWindow.setWindowTitle(_translate("advancedLineMarkerWindow", "Advanced Line Markers"))
        self.labelIntegLimit.setText(_translate("advancedLineMarkerWindow", "Integrate Limit"))
        self.labelSweepLimit.setText(_translate("advancedLineMarkerWindow", "Sweep Limit"))
        self.checkBoxSrchLimitOff.setText(_translate("advancedLineMarkerWindow", "Off"))
        self.checkBoxSweepLimitOff.setText(_translate("advancedLineMarkerWindow", "Off"))
        self.labelSearchLimit.setText(_translate("advancedLineMarkerWindow", "Search Limit"))
        self.checkBoxSweepLimitOn.setText(_translate("advancedLineMarkerWindow", "On"))
        self.checkBoxSrchLimitOn.setText(_translate("advancedLineMarkerWindow", "On"))
        self.labelTraceInteg.setText(_translate("advancedLineMarkerWindow", "Trace Integration"))
        self.checkBoxIntegLimitOn.setText(_translate("advancedLineMarkerWindow", "On"))
        self.checkBoxTrceIntegOn.setText(_translate("advancedLineMarkerWindow", "On"))
        self.checkBoxIntegLimitOff.setText(_translate("advancedLineMarkerWindow", "Off"))
        self.checkBoxTrceIntegOff.setText(_translate("advancedLineMarkerWindow", "Off"))

