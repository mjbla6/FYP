import time
import threading
from graphPlot import display
def continuousDisplay(self,interval,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units,amplitude_units):
        print('made it in')
        display(self,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units,amplitude_units)
        print('past display')
        ##threading.Timer(interval, continuousDisplay(self,interval,my_instrument,active_trace,wavelength_name,amplitude_name,wavelength_units,amplitude_units)).start()
        print('running')
