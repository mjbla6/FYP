import visa_manager

devices_info = visa_manager.devices()
address = visa_manager.GPIB_address()
num_devices = visa_manager.num_devices()
print(devices_info)
print(address)
print(num_devices)

indices = [i for i, s in enumerate(devices_info) if 'AGILENT 86142B' in s]
print(indices[0])

