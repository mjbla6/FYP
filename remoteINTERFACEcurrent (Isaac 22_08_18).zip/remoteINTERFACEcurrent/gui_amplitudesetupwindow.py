# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'amplitudesetupwindow.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_amplitudeSetupWindow(object):
    def setupUi(self, amplitudeSetupWindow):
        amplitudeSetupWindow.setObjectName("amplitudeSetupWindow")
        amplitudeSetupWindow.resize(400, 200)
        self.verticalLayout = QtWidgets.QVBoxLayout(amplitudeSetupWindow)
        self.verticalLayout.setContentsMargins(14, -1, -1, -1)
        self.verticalLayout.setObjectName("verticalLayout")
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.buttonAutoRang = QtWidgets.QPushButton(amplitudeSetupWindow)
        self.buttonAutoRang.setCheckable(False)
        self.buttonAutoRang.setObjectName("buttonAutoRang")
        self.gridLayout.addWidget(self.buttonAutoRang, 2, 4, 1, 1)
        self.lineRefLevel = QtWidgets.QLineEdit(amplitudeSetupWindow)
        self.lineRefLevel.setObjectName("lineRefLevel")
        self.gridLayout.addWidget(self.lineRefLevel, 0, 2, 1, 2)
        self.label = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 2)
        self.buttonAmpUnits = QtWidgets.QPushButton(amplitudeSetupWindow)
        self.buttonAmpUnits.setCheckable(False)
        self.buttonAmpUnits.setChecked(False)
        self.buttonAmpUnits.setObjectName("buttonAmpUnits")
        self.gridLayout.addWidget(self.buttonAmpUnits, 1, 4, 1, 1)
        self.label_2 = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 4, 1, 1)
        self.buttonAmpCorr = QtWidgets.QPushButton(amplitudeSetupWindow)
        self.buttonAmpCorr.setCheckable(False)
        self.buttonAmpCorr.setObjectName("buttonAmpCorr")
        self.gridLayout.addWidget(self.buttonAmpCorr, 3, 4, 1, 1)
        self.label_5 = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label_5.setObjectName("label_5")
        self.gridLayout.addWidget(self.label_5, 3, 0, 1, 4)
        self.label_4 = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 2, 0, 1, 4)
        self.label_3 = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 1, 0, 1, 4)
        self.buttonAmpCorrMode = QtWidgets.QPushButton(amplitudeSetupWindow)
        self.buttonAmpCorrMode.setCheckable(False)
        self.buttonAmpCorrMode.setObjectName("buttonAmpCorrMode")
        self.gridLayout.addWidget(self.buttonAmpCorrMode, 4, 4, 1, 1)
        self.label_6 = QtWidgets.QLabel(amplitudeSetupWindow)
        self.label_6.setObjectName("label_6")
        self.gridLayout.addWidget(self.label_6, 4, 0, 1, 4)
        self.verticalLayout.addLayout(self.gridLayout)
        self.buttonBox = QtWidgets.QDialogButtonBox(amplitudeSetupWindow)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(amplitudeSetupWindow)
        self.buttonBox.accepted.connect(amplitudeSetupWindow.accept)
        self.buttonBox.rejected.connect(amplitudeSetupWindow.reject)
        QtCore.QMetaObject.connectSlotsByName(amplitudeSetupWindow)

    def retranslateUi(self, amplitudeSetupWindow):
        _translate = QtCore.QCoreApplication.translate
        amplitudeSetupWindow.setWindowTitle(_translate("amplitudeSetupWindow", "Amplitude Setup"))
        self.buttonAutoRang.setText(_translate("amplitudeSetupWindow", "PushButton"))
        self.label.setText(_translate("amplitudeSetupWindow", "Reference Level Position:"))
        self.buttonAmpUnits.setText(_translate("amplitudeSetupWindow", "PushButton"))
        self.label_2.setText(_translate("amplitudeSetupWindow", "Divisions"))
        self.buttonAmpCorr.setText(_translate("amplitudeSetupWindow", "PushButton"))
        self.label_5.setText(_translate("amplitudeSetupWindow", "Amplitude Correction:"))
        self.label_4.setText(_translate("amplitudeSetupWindow", "Auto Ranging:"))
        self.label_3.setText(_translate("amplitudeSetupWindow", "Amplitude Units:"))
        self.buttonAmpCorrMode.setText(_translate("amplitudeSetupWindow", "PushButton"))
        self.label_6.setText(_translate("amplitudeSetupWindow", "Amplitude Correction Mode:"))

