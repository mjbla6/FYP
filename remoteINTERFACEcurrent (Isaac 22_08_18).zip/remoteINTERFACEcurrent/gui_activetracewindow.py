# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'activetracewindow.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_activeTraceWindow(object):
    def setupUi(self, activeTraceWindow):
        activeTraceWindow.setObjectName("activeTraceWindow")
        activeTraceWindow.resize(176, 350)
        self.verticalLayout = QtWidgets.QVBoxLayout(activeTraceWindow)
        self.verticalLayout.setObjectName("verticalLayout")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.checkTRCA = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkTRCA.setObjectName("checkTRCA")
        self.verticalLayout_2.addWidget(self.checkTRCA)
        self.checkTRCB = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkTRCB.setObjectName("checkTRCB")
        self.verticalLayout_2.addWidget(self.checkTRCB)
        self.checkTRCC = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkTRCC.setObjectName("checkTRCC")
        self.verticalLayout_2.addWidget(self.checkTRCC)
        self.checkTRCD = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkTRCD.setObjectName("checkTRCD")
        self.verticalLayout_2.addWidget(self.checkTRCD)
        self.checkTRCE = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkTRCE.setObjectName("checkTRCE")
        self.verticalLayout_2.addWidget(self.checkTRCE)
        self.checkTRCF = QtWidgets.QCheckBox(activeTraceWindow)
        self.checkTRCF.setObjectName("checkTRCF")
        self.verticalLayout_2.addWidget(self.checkTRCF)
        self.buttonAllOff = QtWidgets.QPushButton(activeTraceWindow)
        self.buttonAllOff.setObjectName("buttonAllOff")
        self.verticalLayout_2.addWidget(self.buttonAllOff)
        self.verticalLayout.addLayout(self.verticalLayout_2)
        self.buttonBox = QtWidgets.QDialogButtonBox(activeTraceWindow)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(activeTraceWindow)
        self.buttonBox.accepted.connect(activeTraceWindow.accept)
        self.buttonBox.rejected.connect(activeTraceWindow.reject)
        QtCore.QMetaObject.connectSlotsByName(activeTraceWindow)

    def retranslateUi(self, activeTraceWindow):
        _translate = QtCore.QCoreApplication.translate
        activeTraceWindow.setWindowTitle(_translate("activeTraceWindow", "Dialog"))
        self.checkTRCA.setText(_translate("activeTraceWindow", "Trace A"))
        self.checkTRCB.setText(_translate("activeTraceWindow", "Trace B"))
        self.checkTRCC.setText(_translate("activeTraceWindow", "Trace C"))
        self.checkTRCD.setText(_translate("activeTraceWindow", "Trace D"))
        self.checkTRCE.setText(_translate("activeTraceWindow", "Trace E"))
        self.checkTRCF.setText(_translate("activeTraceWindow", "Trace F"))
        self.buttonAllOff.setText(_translate("activeTraceWindow", "All Off"))

