# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'appselect.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_appSelect(object):
    def setupUi(self, appSelect):
        appSelect.setObjectName("appSelect")
        appSelect.resize(400, 300)
        self.gridLayout = QtWidgets.QGridLayout(appSelect)
        self.gridLayout.setObjectName("gridLayout")
        self.buttonBox = QtWidgets.QDialogButtonBox(appSelect)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.gridLayout.addWidget(self.buttonBox, 2, 1, 1, 1)
        self.listWidget = QtWidgets.QListWidget(appSelect)
        self.listWidget.setObjectName("listWidget")
        self.gridLayout.addWidget(self.listWidget, 1, 0, 1, 2)
        self.label = QtWidgets.QLabel(appSelect)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 2)

        self.retranslateUi(appSelect)
        self.buttonBox.accepted.connect(appSelect.accept)
        self.buttonBox.rejected.connect(appSelect.reject)
        QtCore.QMetaObject.connectSlotsByName(appSelect)

    def retranslateUi(self, appSelect):
        _translate = QtCore.QCoreApplication.translate
        appSelect.setWindowTitle(_translate("appSelect", "Application Select"))
        self.label.setText(_translate("appSelect", "Installed Applications:"))

